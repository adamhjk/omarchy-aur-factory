# Contributing Code to Swamp

Only employees of Elder Swamp Club, Inc. are allowed to contribute code to
Swamp.

There are no exceptions. All pull requests to this repository not made by
employees of Elder Swamp Club will be closed immediately.

# Contributing Bug Reports and Feature Requests

We are thrilled to receive your bug reports and feature requests, which we will
implement for you (and maintain over time) at our discretion. By including any
source code in a bug report or feature request, you grant a full copyright
license to Elder Swamp Club, Inc.

# Why?

AI Agents can produce working, reliable source code at a rate that is difficult
for a human to understand or review. Because we cannot discern between a large
human change or a large change made by an AI Agent, the only way we can maintain
supply chain security and quality control is to tightly control the inputs to
the software development process.

This means we are very open to your bug reports and feature requests, which we
will vet thoroughly for prompt injection and malicious intent. If we agree to
fix the issue or implement the feature, we will do so only with AI Agents and
Software Developers under our direct control.

# Attribution

When you submit a bug report or file an issue, we are happy to include you as a
co-author on the pull request we generate at your request.

# Copyright

This does _not_ imply that we share the copyright ownership of the work - the
resulting software will be the exclusive copyright of Elder Swamp Club, Inc.

# No Exceptions

There are no exceptions.
