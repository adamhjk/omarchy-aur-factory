---
audience: maintainer, operator
enables: [serve]
last-verified: 2026-08-28 @ 3d5955a9
---

# Remote Execution

Remote execution lets a single **orchestrator** fan a workflow or method run out
across many **workers** — disposable swamp processes that carry no repository,
datastore, vault, or extension state of their own. A worker is just a swamp
binary plus a token and a URL. It dials home, enrolls, and runs whatever the
orchestrator dispatches; the extension code it needs is shipped with the
dispatch, and every side-effecting capability the running method touches —
reading data, writing data, resolving a secret, loading a definition — is
proxied back to the orchestrator, which owns the durable world.

Remote execution **replaces** execution drivers (removed; see [No execution drivers](#no-execution-drivers))
entirely. There is no `raw` / `docker` driver selection and no driver
abstraction: every method runs in-process inside whichever executor holds it.
Isolation and environment become a *deployment property of the worker* — if you
want a container, you run a containerized worker — not a per-step configuration
field.

## Why this shape

Three properties drove the design:

- **Workers dial the orchestrator, never the reverse.** Workers live in CI,
  ephemeral cloud instances, containers, behind NAT — places that cannot accept
  inbound connections but can always open an outbound one. Every worker
  connection is worker-initiated and outbound, so they traverse firewalls for
  free and make provisioning a one-liner (`swamp worker connect <url> --token
  <token>`), with no service discovery and no inbound ports. The control socket
  *is* the liveness signal: connected ⇒ enrolled; disconnect ⇒ deregistered.

- **The orchestrator is the world; the worker is pure compute.** Every durable
  capability — datastore reads and writes, vault secrets, definition loads,
  catalog lookups — and every piece of extension *code* originates at the
  orchestrator. A worker holds no credentials, no repository, no datastore
  config, and no pre-installed extensions, and can touch nothing it was not
  handed. This makes the orchestrator a natural authorization and audit
  chokepoint, and gives read-your-own-writes and cross-worker data visibility
  for free, because there is a single durable authority.

- **The injection seam already exists.** libswamp operations are pure functions
  over injected `*Deps` structs, and a method receives its world through
  `MethodContext` (`src/domain/models/model.ts`). Remote execution swaps the
  *leaves* of that dependency tree — repositories, vault service, data writers —
  for remote proxy adapters that RPC home. Method code and libswamp operation
  code do not change at all. This is the repository/ports-and-adapters
  abstraction paying off: a remote adapter is just another implementation of the
  same port.

## Ubiquitous language

| Term                 | Meaning                                                                                                                       |
| -------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| **Orchestrator**     | The control-plane websocket server and data-plane HTTP/2 endpoint. Owns DAG and run state, the datastore, vaults, the catalog, definitions, extension bundles, locks, the scheduler, token issuance, and audit. |
| **Worker**           | A disposable swamp process that dials the orchestrator, enrolls, and executes dispatched steps with a remote `MethodContext`. |
| **Executor**         | What a dispatch actually runs on: the **local loopback** (in-process on the orchestrator, no socket) or a **remote worker**. Either way, methods run in-process. |
| **Enrollment**       | The first-connect handshake: redeem the token, bind it to the worker instance UUID, exchange version/labels, issue a session credential, admit the worker into the pool. |
| **Enrollment token** | A named, time-boxed credential that enrolls one or more workers (controlled by `maxEnrollments`), then re-authenticates each bound instance for the rest of its lifetime. A built-in model. |
| **Session credential** | The short-lived credential issued at enrollment that authenticates the worker's HTTP/2 data-plane requests.                |
| **Dispatch**         | The orchestrator → worker request to run one `ExecutionRequest`. The unit of fan-out.                                       |
| **Capability**       | A side-effecting function a running method reaches through its context, proxied back to the orchestrator. A finite, closed set. |
| **Step lease**       | The orchestrator's record that a given step is in flight on a given worker. A built-in model.                               |
| **Environment snapshot** | The orchestrator's full process environment, shipped with each dispatch and held in worker memory only for the step's duration. |
| **Spool file**       | The worker-local file backing `getFilePath()` on a remote executor; uploaded to the orchestrator as one streamed `POST` on `finalize()`. |
| **Fleet probe**      | A built-in model (`swamp/fleet-probe`) whose single `verify` method exercises every seam between worker and orchestrator: dispatch metadata (`probeMarker`), capability RPC (`queryData`), and the HTTP data plane (`writeResource`/`readResource`). Used by `swamp worker verify` and `--verify-on-enroll`. |
| **Probe marker**     | A dispatch-level string (`probeMarker` on `DispatchParams`) that the worker merges into the method's args. Confirms dispatch-level metadata arrives intact. Travels via `DispatchParams`, not the environment snapshot (which denylists `SWAMP_*` variables). |
| **Verify-on-enroll** | Opt-in orchestrator flag (`--verify-on-enroll`) that dispatches the fleet probe to each enrolling worker before it becomes schedulable. Workers that fail enter `unverified` status and are excluded from scheduling. |
| **Unverified**       | A worker status indicating the enrollment verification probe failed. Unverified workers are visible in `swamp worker list` (the failure reason is in the `--json` record only, `src/presentation/output/worker_output.ts`) and are excluded from label/platform scheduling; a step that pins a `target:` by name bypasses that filter (`eligibleWorkers` in `src/domain/remote/scheduler.ts`). |

The orchestrator's own bookkeeping — the worker pool, token lifecycle, and step
leases — is **persisted as swamp data** by first-class built-in models, written
exactly as a model method writes its output (see
[Worker state is swamp data](#worker-state-is-swamp-data)). "Executor" here is the
deployment target of a dispatch, distinct from the in-process services
(`DefaultMethodExecutionService`, `WorkflowExecutionService`) that run *inside* an
executor. The two domain roles remain **orchestrator** and **worker**.

## Topology

A worker opens both connections outbound. The control socket is bidirectional —
the orchestrator dispatches work down it, the worker proxies metadata capabilities
back up it — and the data plane is a separate worker-initiated HTTP/2 channel for
bulk bytes.

```
        ┌──────────────────────────────────────────────┐
        │                ORCHESTRATOR                    │
        │  control: websocket server                     │
        │  data:    HTTP/2 endpoint                      │
        │                                                │
        │  DAG + run state · datastore · vaults ·        │
        │  catalog · definitions · extension bundles ·   │
        │  locks · scheduler · tokens · audit            │
        └───▲───────────────▲───────────────▲────────────┘
            │ ws (control)   │               │
            │ + h2 (data),   │               │
            │ both worker-   │               │
            │ initiated      │               │
       ┌────┴────┐      ┌────┴────┐     ┌────┴────┐
       │ WORKER  │      │ WORKER  │     │ WORKER  │
       │ compute │      │ compute │     │ compute │
       │ no state│      │ no state │    │ no state│
       └─────────┘      └─────────┘     └─────────┘
```

A worker is provisioned by minting a token and running one command (cloud-init,
a k8s Job, an ssh one-liner):

```bash
swamp worker token create ci-runner-3 --duration 1h    # on/near the orchestrator
swamp worker connect wss://orchestrator.internal:4000 --token <token>   # on the worker
```

When the orchestrator runs with `--auth-mode token`, the worker must also
provide a server access token to authenticate the WebSocket upgrade. The
`--server-token` flag (or `SWAMP_SERVER_TOKEN` env var) passes this separately
from the enrollment token — the server token authenticates the transport
connection, while the enrollment token authenticates the worker's identity
inside the RPC handshake:

```bash
swamp worker connect wss://orch:9090 \
  --server-token admin.secret \
  --token worker-pool.enrollment-secret \
  --label tier=ci
```

The CLI sends the server token via the `Authorization: Bearer` header on the
WebSocket upgrade request. This avoids leaking the token in URL query
parameters, which would appear in reverse proxy and load balancer access logs.

### A symmetric control protocol, two handler registries

`src/serve/` serves two roles over one listener: the websocket *server* that
receives client requests such as `model.method.run` / `workflow.run`
(`src/serve/connection.ts`, `src/serve/protocol.ts`), and the *orchestrator*
that decides where each step runs. Remote execution keeps those apart:

- The **orchestrator** is the server but *dispatches* work.
- The **worker** is the client but *executes* work.

Two protocol modules cover this. `src/serve/protocol.ts` is the client
protocol (below). `src/domain/remote/protocol.ts` is the worker control
protocol: a generic `rpc.request` / `rpc.response` / `rpc.error` /
`rpc.stream` / `rpc.cancel` frame set carried by `RpcChannel`
(`src/domain/remote/rpc_channel.ts`), with a **handler registry on each side**:

| Direction               | Methods the receiver handles                                                  |
| ----------------------- | ----------------------------------------------------------------------------- |
| orchestrator → worker   | `WorkerMethod.dispatch` (`worker.dispatch`); cancellation is the `rpc.cancel` frame |
| worker → orchestrator   | `RemoteMethod`: `worker.enroll`, `worker.session.refresh`, `worker.drain`, and the nine `capability.*` verbs; run events ride `rpc.stream` |

Both sides share the framing, error envelope, and `serializeEvent()`
machinery. Byte-heavy transfers do *not* go over this socket — they ride the
HTTP/2 data plane (see [Data plane](#data-plane-two-transports)).

The serve endpoint keeps its client protocol side by side with the worker
messages: worker verbs are new message types gated on enrollment, so an
ordinary client and an enrolling worker share one listener without ambiguity.

The client protocol supports two interaction patterns:

- **Streaming operations** (`workflow.run`, `model.method.run`,
  `workflow.resume`, and `run.attach`, which replays and follows a live run's
  buffer) send an event stream followed by a terminal `done` frame, so clients
  can distinguish "run ended" from "stream stalled".
- **Request-response operations** (everything else) send a single response
  frame with a `payload` field, matching the request's `type`.

The authoritative list of client request types is the `ServerRequest` union
in `src/serve/protocol.ts` (107 members at last verification); this table
lists only the families and the authorization verb each handler asks
`authorizeOrReject` for:

| Family (`type` prefix)                           | Typical auth verb                                                                              |
| ------------------------------------------------ | ---------------------------------------------------------------------------------------------- |
| `data.*`                                         | `read` for lookups; `write` for `delete` / `rename`                                            |
| `model.*` (incl. `model.output.*`, `model.method.history.*`) | `read`; `write` for create/delete; `run` for `model.method.run`; conditional `admin` on some handlers |
| `workflow.*` (incl. history, approvals)          | `read` for lookups and `workflow.approvals`; `run` for run/resume/approve/reject                |
| `vault.*`                                        | `read` / `write`; conditional `admin` on some handlers                                          |
| `access.*`                                       | `read` for `grant.list` / `group.list`; `access.can-i` requires an authenticated principal but no verb; the rest `admin` |
| `audit.*`, `summarise`, `report.*`               | `read`                                                                                         |
| `extension.*`, `doctor.*`, `worker.*`, `datastore.*`, `cluster.*`, `serve.*` | `read` for listings (`cluster.instances`, `serve.config`); `admin` for mutations and `serve.reload` |
| `run.*` (`history`, `doctor`, `gc`, `attach`)    | `admin` for history/doctor; `write` for `run.gc`; `run` on the attached resource for `run.attach` |
| `cancel`                                         | `run` on the active run's resource (`src/serve/connection.ts`)                                 |

Any type named in `--restricted-commands` is escalated to `admin` regardless
of its handler's own verb (`isRestrictedCommand` in `src/serve/connection.ts`).

The CLI consumes this protocol via `--server <url>` on each command:
repo-less, streaming the run's events through the same renderers as a local
run (the wire codec is lossless for run events; `deserializeEvent` in
`src/serve/serializer.ts` is the anti-corruption seam). The `--server` flag
on all remote commands falls back to the `SWAMP_SERVE_URL` env var (or
`SWAMP_SERVER_URL` as a secondary fallback) when not provided, so
`export SWAMP_SERVE_URL=wss://demo.swamp-club.ai` avoids repeating the URL
on every invocation. Precedence: `--server` flag > `SWAMP_SERVE_URL` >
`SWAMP_SERVER_URL`. When a command dispatches to a remote server, a
`Remote   <url>` indicator line is written to stderr before the first
network I/O, so the user always knows the command is targeting a server
rather than the local repository.

When `--auth-mode token` is active, the server validates the token presented at
WebSocket upgrade time via the `swamp/server-token` model's `redeem` method
(timing-safe, vault-backed). The server accepts the token via `Authorization:
Bearer`, the `Sec-WebSocket-Protocol` subprotocol, or a `?token=` query
parameter (in that priority order). The CLI sends it via the `Authorization`
header. Unauthenticated connections receive HTTP 401. The client resolves the
token from (in precedence order) the `--token` flag, the `SWAMP_SERVER_TOKEN` +
`SWAMP_SERVER_URL` env vars, or stored credentials in
`~/.config/swamp/servers.json` (managed by `swamp auth server-login`). Token
management is through `swamp access token mint/list/revoke`.

When `--auth-mode oauth` is active, users authenticate via the OAuth device
grant flow (RFC 8628) against swamp-club. The server acts as an OAuth client
relay — it holds client credentials (auto-registered on first start or
supplied via `--oauth-client-id` or via headless API key bootstrap) and
proxies the device authorization flow. The flow:

1. User runs `swamp auth server-login --server <url>`
   (`src/cli/commands/auth_server_login.ts`; `swamp auth login --server` is
   the swamp-club registry login, a different command)
2. CLI calls `GET /auth/info` on the serve instance to discover auth mode
3. CLI calls `POST /auth/device` — serve starts a device grant against
   swamp-club, returns a user code and verification URL
4. User visits the URL, signs in to swamp-club, enters the code, approves
5. CLI polls `POST /auth/device/token` — serve polls swamp-club's token
   endpoint, gets an access token, calls the userinfo endpoint to retrieve
   `sub`, `email`, `name`, and `collectives`
6. Serve applies the admission policy: the user must be in
   `--allowed-collectives` or `--allowed-users`; otherwise admission is
   rejected
7. On admission, serve mints a `swamp/server-token` with the user's
   collectives snapshotted on the token record and returns
   `<name>.<secret>` to the CLI
8. CLI stores the server token via `ServerCredentialRepository` — subsequent
   commands authenticate with it automatically

After the device flow, OAuth-minted tokens are indistinguishable from
manually-minted tokens. The WebSocket upgrade, cancel endpoint, and all
handler authorization use the same `<name>.<secret>` token +
`authenticateServerToken` path for both modes. The only difference is
collectives: the `authorizeOrReject` function reads collectives from the
token record (via a per-connection WeakMap set at upgrade time), enabling
`idp-group:` grants to match for OAuth-authenticated users.

Auto-registration: on first start with `--auth-mode oauth`, if no client
credentials are stored, the serve instance registers an OAuth client via
`POST /api/auth/oauth2/register` and stores the returned `client_id` and
`client_secret` in the vault (keys: `oauth-client-id`,
`oauth-client-secret`). Subsequent starts read from the vault. Two
registration paths exist:

- **Headless (SWAMP_API_KEY)**: when the `SWAMP_API_KEY` env var is set
  (a collective API token with `oauth:manage` scope), the server validates
  the key against `/api/whoami`, uses it as a bearer token for client
  registration and admin/allowed-user username resolution. The API key
  is never persisted in the vault — it is read fresh from the environment
  on each boot, so key rotation is transparent.
- **Interactive (device grant)**: when `SWAMP_API_KEY` is not set, the
  server initiates a device grant flow (RFC 8628) and waits for the
  admin to approve in a browser. The device grant access token is
  stored in the vault for subsequent admin resolution.

Collectives are snapshotted at login time. The `CollectiveRefreshService`
(`src/serve/collective_refresh_service.ts`) re-resolves them for active tokens
on a timer — `--group-refresh-interval`, default 4 h, `0` to disable
(`src/cli/commands/serve.ts`) — so membership changes in swamp-club converge
within one interval.

v1 is swamp-club-specific: the OAuth client endpoint paths
(`/api/auth/device/code`, `/api/auth/device/token`,
`/api/auth/oauth2/userinfo`, `/api/auth/oauth2/register`) are hardcoded.
The `--oauth-provider` flag accepts a custom URL but only swamp-club is
tested.

The CLI sends the token via the `Authorization: Bearer` header on the WebSocket
upgrade request. The server also accepts the `Sec-WebSocket-Protocol`
subprotocol and `?token=` query parameter (for backward compatibility with older
clients), but the header transport is preferred because it keeps credentials out
of URL paths that reverse proxies and CDNs log. Use TLS (`wss://`) for
non-loopback deployments.

### Extra headers for reverse proxies and tunnels

When a `swamp serve` instance sits behind a reverse proxy or tunnel that
requires custom HTTP headers (e.g. `Tunnel-Token`, provider-specific access
headers), clients can inject arbitrary pass-through headers via the
`SWAMP_SERVE_EXTRA_HEADERS` environment variable. The format is
newline-separated `Name: value` entries:

```
export SWAMP_SERVE_EXTRA_HEADERS=$'Tunnel-Token: abc123\nX-Proxy-Auth: def456'
```

These headers are applied to the WebSocket upgrade request (using Deno 2.x's
non-standard `WebSocket({ headers })` extension) and, for workers, to all HTTP
data-plane requests. They are pure pass-through — `swamp serve` itself does not
read or require them. Header values may contain secrets and are never logged.

Reserved header names (`Authorization`, `Host`, `Upgrade`, `Connection`) are
rejected to prevent conflicts with swamp's internal protocol headers. Values
containing control characters are also rejected to prevent header injection.

## No execution drivers

There is no driver abstraction. The `ExecutionDriver` interface,
`raw`/`docker`/custom selection, the driver type registry, and the docker
bundle-mounting machinery were all removed. The `driver:`/`driverConfig:`
fields that lived in the workflow, job, step, and definition schemas, plus
`defaultDriver`/`defaultDriverConfig` in `.swamp.yaml`, the `--driver` CLI
flags, the serve protocol payloads, and `driver` fields on run events are gone
(`ExecutionRequest` never carried them). Old YAML that still names those
fields fails loudly with an actionable message
(`src/domain/removed_driver_fields.ts`) rather than being silently stripped.
Execution reduces to two code paths:

- **Execute in-process** on the orchestrator's loopback executor — the
  single-host case, no socket, no websockets forced. This is the old `raw` path,
  now simply "the execution path."
- **Dispatch to a worker**, which also runs the method in-process in its own
  swamp process.

Isolation and environment, which `docker` and custom drivers used to provide, are
now expressed by **how a worker is deployed**: run a worker in a container for
container isolation, on a GPU host for GPU access, in a locked-down VM for a
strong sandbox — and describe it with labels the scheduler matches against. The
only behavior genuinely removed is "isolate locally on a single host without a
worker"; it is recovered by running a local containerized worker alongside the
orchestrator.

## Enrollment

On first connect, the worker redeems its token, binds it to this machine's
durable id, receives a session credential, and the orchestrator admits it into
the pool:

```
worker → orchestrator   enroll {
  token,                       // enrolls one machine; then re-auths that machine for its lifetime
  instanceUuid,                // per-instance UUID generated at worker startup (in-memory only)
  machineId,                   // durable machine id persisted in the worker's cache directory
  protocolVersion,             // reuse the version on ExecutionRequest
  swampVersion,
  platform, arch,              // e.g. linux/x86_64
  labels: { region: "us-east", gpu: "true" },   // scheduling selectors
  resourceLimits: { ... },
}

orchestrator → worker   enrolled { workerId, sessionCredential, sessionExpiresAtMs, protocolVersion }   |   error { ... }
```

(`EnrollParamsSchema` / `EnrollResult` in `src/domain/remote/protocol.ts`; the
session credential TTL is 15 min, `DEFAULT_SESSION_TTL_MS` in
`src/domain/remote/session_credential.ts`, refreshed at 2/3 of the TTL.)

A worker advertises **labels** and platform/arch, not runtimes — there is no
runtime axis to negotiate. Shipping the swamp binary keeps the orchestrator and
worker in version lockstep, so the capability interfaces match; `protocolVersion`
(already present on `ExecutionRequest`) rejects an incompatible worker at
enrollment rather than mid-run. The `sessionCredential` is a short-lived bearer
token that authenticates the worker's data-plane HTTP/2 requests. The worker is
addressable in the pool by its token name (the positional `<name>` given to
`swamp worker token create`) and its `instanceUuid`; a step may target it
directly by either (see [Scheduling](#scheduling-fan-out-and-provisioning)).

### Enrollment tokens

Tokens are the unit of *logical provisioning* — admitting a worker into the
system. Each token is:

- **Named** — for audit and identification, and as the worker's addressable handle
  in the pool (`ci-runner-3`).
- **Time-boxed** — a `--duration` lifetime that is a *hard deadline*: it bounds
  enrollment and reconnection, and when it elapses the orchestrator actively
  disconnects a connected worker. Continuing past it means minting a new token.
- **Controlled enrollment** — `maxEnrollments` (default `1`) controls how many
  distinct machines a token can bind. A single-enrollment token behaves as
  before: first connect binds it to a `machineId`; a different machine is
  rejected. A fleet token (`maxEnrollments > 1` or `"unlimited"`) accepts
  multiple machines, each appended to a `bindings` list until the allowance is
  exhausted. Each fleet member gets a distinct pool name
  (`<tokenName>-<suffix>`) derived from a stable hash of its `machineId`.
- **Reconnect-for-lifetime** — after enrollment, any *bound machine* may
  re-authenticate by presenting `{token, machineId}` as many times as needed
  until the lifetime expires. This is what survives a broken control socket
  *and* a process restart or reboot: the worker comes back as the same pool
  member without a freshly minted token.

The token is a built-in **enrollment-token** model whose instances are swamp data,
with states `unused → enrolled → expired` (plus `revoked` reachable from any
non-terminal state via `swamp worker token revoke`); the `unused → enrolled`
transition
appends a binding (`machineId` + `enrolledAt`) to the token's `bindings` list,
and concurrent enrollment attempts are serialized by the orchestrator. The datastore itself provides no compare-and-swap — concurrent saves to
one data item simply land as successive versions — so atomicity comes from the
**orchestrator process serializing all token and lease transitions in memory**:
it is the sole writer of these models, and enrollment for a given token is a
critical section. (A conditional save — rejecting unless `latest` matches an
expected version — is the future primitive if orchestrators ever scale out.)
The CLI surface:

```bash
swamp worker token create <name> --duration <dur>   # mint; prints the credential once
swamp worker token list                             # NAME, STATE, EXPIRES, ENROLLMENTS
swamp worker token revoke <name>                    # invalidate before expiry
```

The printed credential has the form **`<name>.<secret>`**: the name half
addresses the token aggregate at enrollment (no scan over the pool), the
secret half is compared — constant-time — against the vault-stored plaintext.

The `instanceUuid` is in-memory only and distinguishes a *socket blip* (process
alive, UUID stable, same pool member) from a *process restart* (new UUID, fresh
enrollment of the same machine). The `machineId` is what the token binds to: it
lives in a `machine-id` file in the worker's cache directory, so a worker
started with a stable `--cache-dir` survives restarts and reboots on its
original token for as long as the token lives, while the default fresh temp
cache directory yields a new machine identity per process. When the lifetime
expires the token is dead for everyone — the orchestrator disconnects the
worker and rejects re-enrollment. Replacing a machine or outliving a token
means minting a new one — machines are the unit of trust; processes come and
go.

## Worker state is swamp data

The orchestrator does not keep the worker pool, token lifecycle, or step leases
in a private in-memory registry. It persists them as **swamp data**, written by
first-class **built-in models** through the same datastore and catalog as any
model method's output:

- a **worker** model — one artifact per enrolled worker: name, `instanceUuid`,
  labels, platform/arch, resource limits, connection status, current load.
  (Definition instances are prefixed `worker-<name>` because tokens and
  workers share one definition-name namespace; the pool-addressable `name`
  inside the data stays bare.);
- an **enrollment-token** model — the token lifecycle aggregate above;
- a **step-lease** model — which step is in flight on which worker;
- a **pending-dispatch** model (`swamp/pending-dispatch`) — queued demand
  records for steps awaiting a matching worker, with states
  `waiting → dispatched | timed_out | cancelled | orphaned`;
- a **fleet-probe** model (`swamp/fleet-probe`) — a lightweight model whose
  single `verify` method exercises every seam between worker and orchestrator
  (dispatch metadata, capability RPC, and data plane); used by
  `swamp worker verify` and `--verify-on-enroll`.

These ship with swamp and are registered at startup like its other built-ins.
This is not incidental — it is *why* the rest of the design composes:

- **Provisioning and autoscaling become workflows.** A workflow can
  `data.query('modelType == "swamp/worker" && attributes.status == "idle"')`
  (definition names are `worker-<name>`, so filter on `modelType`; content
  fields live under `attributes` and load on demand; or count busy workers, or
  filter by label) to decide whether to mint a token and launch another host.
  The control plane is introspectable through the exact primitive workflows
  already use.
- **Lifecycle history is free.** Because data is versioned-immutable
  (see [Data semantics](#data-semantics)), every status change is a new version,
  so the full enroll → busy → idle → expire history of a worker is queryable for
  audit and debugging with no extra machinery.
- **Reports and the CLI come for free.** `swamp data query`, reports, and any
  CEL helper see worker state the same way they see model output — no bespoke
  "pool status" surface to build.

The scheduler reads and writes this data as its source of truth; it is not a
parallel store that can drift from it.

Versioned-immutable state has a churn cost: every busy/idle flip and lease
change is a new version, and garbage collection is an explicit operation
(`swamp data gc`), not automatic. The built-in models **declare retention up
front** — bounded `garbageCollection` version counts (worker 20; token, lease,
pending-dispatch 10; fleet-probe 1) with `lifetime: "infinite"` on all but the
fleet probe (`src/domain/models/worker/*_model.ts`).

**Known limit:** the orchestrator does **not** run periodic data GC over its
bookkeeping models; the only automatic sweep is the boot reconciliation below.
Until an operator runs `swamp data gc`, the record *count* for workers, tokens,
leases, and pending dispatches grows without bound (each record's version
history is what the declared counts cap).

### Boot reconciliation

When `swamp serve` starts, it sweeps the three bookkeeping models for records
left stale by a prior crash or unclean shutdown:

- **Step leases** in `active` state → transitioned to `expired` (the worker is
  gone; no step is executing).
- **Pending dispatches** in `waiting` state → transitioned to `orphaned` (no
  in-memory queue episode exists to fulfill them).
- **Workers** not in `disconnected` status → transitioned to `disconnected`
  (no live WebSocket session backs them).

The sweep runs through the model-method runner (`createWorkerModelRunDeps` +
`modelMethodRun` with `skipAllReports`), preserving the sole-writer invariant —
state transitions are serialized through the transition tail, not applied by
direct datastore writes. Individual transition failures warn but do not abort
startup; a single corrupted record cannot prevent the orchestrator from serving.

The sweep completes before `Deno.serve` accepts traffic. Workers that reconnect
during the sweep re-enroll normally after it finishes — the sweep transitions
their stale record, and re-enrollment creates a fresh one. On a clean boot (no
stale records match the predicates) the sweep transitions nothing; the
`"Boot: sweeping stale records"` line is logged either way
(`src/cli/commands/serve.ts`).

## The remote `MethodContext`

The heart of the design: on a worker, the injected `MethodContext` (interface
in `src/domain/models/model.ts`) is built from **proxy adapters**
(`createRemoteMethodContext` in `src/worker/remote_method_context.ts`). Each
capability call serializes to a request to the orchestrator, which runs it
against the real repository and returns the result.

```
WORKER                                  ORCHESTRATOR
──────                                   ────────────

method code (unchanged)
  ├─ context.queryData(expr) ──ws────▶   dataQueryService.query(expr)
  │                          ◀──────────  records
  ├─ context.writeResource(...) ─h2──▶   dataRepository.save(...)   (durable now)
  │                          ◀──────────  DataHandle
  ├─ vault secret resolution ──ws────▶   vaultService.resolve(...)
  │                          ◀──────────  secret (scoped to this step)
  └─ emits run events ─────────ws────▶   persisted + streamed to client
```

The method author API (`context.writeResource`, `context.createFileWriter`,
`context.queryData`) is unchanged. Only the implementations behind those handles
differ: local in-process repositories on the loopback executor, remote proxies on
a worker — control-plane RPCs for metadata, the HTTP/2 data plane for bytes.

Not every injected dependency is a flat RPC stub. `createCelEnvironment` is a
*factory*: on a worker it is the plain local `createExtensionCelEnvironment`
(`src/infrastructure/cel/cel_evaluator.ts`), which registers arithmetic
overloads only — it has no data-access leaves, so nothing in it proxies home.
A method that wants data inside a CEL expression fetches it through
`context.queryData` / `readResource` first.

## The capability protocol

"Everything proxies back" must become a **closed, named set of verbs**, because
any capability that is *not* proxied is a method that silently fails on a worker.
The inventory below is generated by walking the actual `MethodContext`
(`src/domain/models/model.ts`), the `DataWriter` interface, and the injected
service ports (`UnifiedDataRepository`, `VaultService`, `DefinitionRepository`,
`OutputRepository`, `DataQueryService`); every context member gets an explicit
disposition — a proxy verb, a data-plane route, worker-local, or shipped
state. Nine control-plane verbs (`RemoteMethod.capability.*` in
`src/domain/remote/protocol.ts`, served by `src/serve/capability_service.ts`)
plus the data-plane routes (`src/serve/data_plane.ts`):

| Operation          | Backed by                                                                  | Transport | Notes                                  |
| ------------------ | -------------------------------------------------------------------------- | --------- | -------------------------------------- |
| `getData`          | repo reads (`findByName`/`findById`/`getContent`/`stream`), `context.readResource`, `readModelData` | ws + h2   | ws resolves `latest`→version; `GET /data/{type}/{modelId}/{dataName}/{version}` streams bytes |
| `queryData`        | `dataQueryService` / `context.queryData`, attribute loading (`select` projection rejected — bypasses denylist) | ws        | CEL predicate over the catalog; always live |
| `listVersions`     | `repo.listVersions`                                                        | ws        | Version history for one data item. The only verb without a dispatch-scope assertion |
| `deleteData`       | `repo.delete`, `repo.removeLatestMarker`                                   | ws        | Lifecycle/GC-aware methods use these   |
| `resolveSecret`    | `vaultService.get` / `getAnnotation`                                       | ws        | Authorized per step: infrastructure denylist + expression-based allowlist from the dispatched step's args (allowlist disabled when the step has dynamic vault references) |
| `putSecret`        | `vaultService.put` / `putAnnotation` / `deleteAnnotation`                  | ws        | Infrastructure denylist; no expression-based allowlist (write targets are not declared in vault expressions) |
| `readDefinition`   | `definitionRepository.findByName`                                          | ws        | Lazy-load; no cache                    |
| `readOutput`       | `outputRepository` execution-history reads                                 | ws        | Optional context member                |
| `resolveModel`     | `findDefinitionByIdOrName` over the definition repository                  | ws        | Workflow step model resolution         |
| resource write     | `POST /data/resource` → `writeResource`                                    | h2        | Durable immediately                    |
| resource delete    | `DELETE /data/resource`                                                    | h2        |                                        |
| file write         | `POST /data/writers` (open) → `/content` (stream + finalize) or `/line` + `/finalize` | h2 | `writeLine` is durable per request (live logs) |
| extension assets   | `GET /bundle/{fingerprint}`, `GET /bundle/{fingerprint}/file/{relPath}`    | h2        | Cacheable by fingerprint               |
| `log` / `event`    | run-event stream                                                           | ws        | `rpc.stream` frames; flows to client   |

The infrastructure denylist (`src/serve/capability_service.ts`) covers the
`server-token-*` and `worker-token-*` key prefixes, `oauth-client-secret`,
`oauth-access-token-*`, `oauth-bootstrap-access-token`,
`oauth-resolved-admins`, and the control-plane token-secrets vault by name.

Completeness of this inventory is the correctness-critical task; it must be
re-walked against `MethodContext` whenever a context member is added, and it is
pinned behind the negotiated `protocolVersion`. Workers still hold no datastore:
artifact *bytes* ride the HTTP data plane, which also terminates at the
orchestrator; everything else is control-plane metadata.

Implementation note: the data-repository port also has synchronous members
(`listVersionsSync`, `findAllGlobalSync`, ...) that cannot make a network
round-trip, plus whole-store enumeration (`findAllGlobal`, `findAllForModel`)
and raw write/maintenance members (`save`, `allocateVersion`, `rename`,
`collectGarbage`, path accessors) that the verbs deliberately do not cover —
writes flow exclusively through the remote writers. On a worker, every one of
these fails loudly with an `UnsupportedOnRemoteWorkerError` naming the member
and pointing at the loopback executor, never silently.

The remaining context members deliberately do **not** proxy:

- **`repoDir`** points at a per-dispatch scratch directory on the worker.
  Workers carry no repository checkout, so reading repo *contents* through it is
  unsupported on a remote executor; a method that needs repo files runs on the
  loopback executor, or on a worker deployed with a checkout and labeled
  accordingly.
- **Local compute stays local.** Subprocess spawning (`Deno.Command` — the shell
  model) and outbound network calls execute on the worker. That is the point
  of remote execution: the compute — including the processes it spawns and the
  APIs it calls — runs where the worker runs. The credentials and environment
  such calls need arrive via the shipped environment (below) or vault-resolved
  inputs. `cloudControlClientFactory` is `undefined` on a worker
  (`src/worker/remote_method_context.ts`); a method that needs it runs on the
  orchestrator.
- **`createCelEnvironment`** is the local extension environment (see above);
  it has no data-access leaves.
- **Not available on a worker.** `context.runModel()`,
  `context.approveWorkflowGate()`, and `context.rejectWorkflowGate()` resolve
  to `{ ok: false }` with an error naming the call
  (`src/worker/remote_method_context.ts`); nested runs and gate control stay
  on the orchestrator.
- **Provider code never ships.** Vault and datastore providers execute
  orchestrator-side *behind* `resolveSecret`/`putSecret` and the data verbs — a
  worker speaks verbs, never providers. Report providers do not ship either:
  checks are skipped for remote steps and reports run at the orchestrator (see
  [Checks and reports](#pre-flight-checks-are-skipped-for-remote-steps-reports-run-at-the-orchestrator)).
- **`followUpActions`** returned by a method ride back serialized on the
  dispatch result (`methodName`/`delayMs`/`maxRetries` only,
  `serializeFollowUpActions` in `src/worker/exec_dispatch.ts`), and the
  orchestrator performs them. **Known divergence:** the `continueCondition`
  function cannot cross the wire and is **dropped**, so the orchestrator's
  follow-up loop (`src/domain/models/method_execution_service.ts`) never sees
  it — a remote step's follow-ups always run, where the same method run
  locally would stop when its condition returned false.

## The execution environment

Methods read ambient environment variables (`Deno.env`), and the processes they
spawn inherit them. On a single host that environment is the orchestrator's; a
worker host's own environment is an accident of deployment. To keep
local-equals-remote semantics, **the orchestrator snapshots its full environment
and ships it with every dispatch**. The worker holds the snapshot in memory for
the duration of the step, applies it to the method's execution context and to
any subprocesses the method spawns, and drops it when the step ends. Nothing is
persisted on the worker, and an idle worker holds no environment at all.

The snapshot **overlays** the worker's base environment rather than replacing
it, and a small fixed denylist of process-identity and host-runtime variables is
never shipped — the worker host's own values win for `HOME`, `USER`,
`USERNAME`, `USERPROFILE`, `LOGNAME`, `SHELL`, `PATH`, `PWD`,
`TMPDIR`/`TEMP`/`TMP`, `HOSTNAME`, `TERM`, `XDG_*`, `DENO_*`, and swamp's own
`SWAMP_*` runtime variables (matched case-insensitively;
`src/domain/remote/environment_snapshot.ts`). Shipping the
orchestrator's `HOME` or `PATH` would silently corrupt the worker's own runtime
(tool resolution, cache and config locations, subprocess lookup); these
variables describe *where the process is running*, which is precisely the thing
remote execution changes. The denylist is pinned in code and versioned with the
`protocolVersion`, so both sides agree on it.

This is also the secret-injection path for ambient credentials: cloud SDKs
constructed by extension code, CLIs invoked by the shell model, and anything
else that authenticates from the environment works on a worker exactly as it
does on the orchestrator host. `env.*` runtime expressions are unaffected — they
already resolve orchestrator-side at dispatch time, consistently with
`vault.get(...)`; the shipped snapshot covers the *ambient* reads inside method
code and its subprocesses.

The deliberate trade-off: every dispatched step sees the orchestrator's whole
environment, so dispatching to a worker grants the same ambient access that
running on the orchestrator host would. Scoping the snapshot (allowlists per
token or per label) is a later refinement; v1 chooses single-host fidelity over
introducing a new partial-environment failure mode.

Workers accept up to `capacity` concurrent dispatches (configured via
`--concurrency N` on `worker connect`, default 1). When all slots are full, an
overlapping dispatch is rejected with `worker_busy` and re-queued by the
orchestrator.

### Dispatch runners (phase 4a)

Each dispatch spawns a **dispatch runner** — a child process of the same swamp
binary (`swamp worker exec-dispatch`, a hidden subcommand). The environment
snapshot is overlaid onto the worker's own environment to form the child's
spawn environment via `overlayEnvironment` (no global mutation of `Deno.env`;
`src/worker/dispatch_handler.ts`). W3C trace context headers are overlaid on
top of the snapshot at spawn time. Worker control-plane credentials
(`SWAMP_WORKER_TOKEN`, `SWAMP_SERVER_TOKEN`, `SWAMP_ORCHESTRATOR_URL`) are
stripped by `stripWorkerCredentials` before the child is started — the runner
receives its data-plane credential via `RunnerBootstrapParams` over stdio and
has no need for worker enrollment or server authentication tokens.

The supervisor (worker process) communicates with the runner over
length-prefixed stdio frames (`StdioTransport`), using the same `RpcChannel`
that the orchestrator–worker control socket uses. A capability bridge forwards
the 9 metadata-RPC capability verbs (`getData`, `queryData`, `listVersions`,
`deleteData`, `resolveSecret`, `putSecret`, `readDefinition`, `readOutput`,
`resolveModel`) from the runner to the orchestrator. Data-plane HTTP operations
go directly from the runner to the orchestrator using a per-dispatch credential.

The runner receives bootstrap parameters as its first stdin frame:
`RunnerBootstrapParams` carrying a per-dispatch session credential, data-plane
URL, cache directory path, and the full `DispatchParams`. Each dispatch gets its
own credential (issued by `SessionCredentialService.issueForDispatch`) that
encodes the `dispatchId`; session refreshes on the control channel do not
invalidate dispatch credentials. The data plane cross-checks
`credential.dispatchId` against the authenticated dispatch to prevent spoofing.

**Cancel propagation** is nested: the RPC channel's `CANCEL_GRACE_MS` (30 s,
`src/domain/remote/rpc_channel.ts` — shared by the control socket and the
stdio channel) bounds the supervisor, which forwards `rpc.cancel` to the runner
immediately and kills the child process after `RUNNER_CANCEL_GRACE_MS` (~10 s)
if it does not respond. This leaves ~20 s for cleanup and the response frame.
(The identically named `CANCEL_GRACE_MS` in `src/cli/commands/serve.ts` is a
different constant — 5 s — governing the serve run-cancel endpoint.)

**Crash isolation**: a runner crash (non-zero exit or stdio channel close) fails
only that dispatch — the worker stays enrolled and accepts the next dispatch.

Phase 4a shipped at capacity 1 — identical behavior to the prior in-process
path, plus crash isolation and clean environment handling.

### Concurrent dispatch (phase 4b)

Phase 4b adds `--concurrency N` (or `"auto"` for CPU count) to `worker connect`.
The worker advertises its capacity via `resourceLimits.capacity` at enrollment
(protocol version 4). The scheduler picks the worker with the most free slots,
then name for determinism (`scheduleStep` in `src/domain/remote/scheduler.ts`).
The `DispatchRegistry` tracks N active dispatches per worker keyed by
`(workerName, dispatchId)`.

**Per-dispatch credentials**: each runner receives its own credential from
`SessionCredentialService.issueForDispatch(workerId, dispatchId)`. This
credential is independent of the control-channel credential — session refreshes
do not invalidate in-flight runners. The service auto-refreshes dispatch
credentials internally: a periodic timer slides the credential's expiry forward
every 2/3 TTL, so the credential remains valid for the entire lifetime of the
dispatch regardless of duration. The credential string stays the same (the
runner does not need to be notified of the refresh). Credentials are revoked
when the dispatch completes. The capability bridge overrides `dispatchId` in
every RPC verb so the `CapabilityService` can resolve the correct dispatch for
model-type scope isolation.

**Idle semantics**: a worker is "idle" when `activeDispatchIds.length === 0`.
The idle timeout starts only when all slots are empty. `maxDispatches` counts
total completed dispatches, not concurrent ones. Drain waits for all active
runners to finish (`activeRunners === 0`).

## Shipping extension code

A worker resolves no extensions of its own. The dispatch references the extension
bundle by fingerprint; on a cache miss the worker fetches it from the
orchestrator's HTTP/2 data plane (`GET /bundle/{fingerprint}`) and loads it
**in-process** in its own swamp runtime. The bundle is the same
`bundleSourceFactory` swamp already builds (see
the removed execution-drivers design); the
worker needs nothing pre-installed.

The fingerprint is computed inline as `sha256Hex(js)` over the bundled source at
dispatch time (see `DispatchService.#ensureBundle`), and a worker caches what it
has already fetched — so a bundle is shipped at most once per worker per version.
This mirrors the versioned-handle data cache — code and data both cache by
content/version identity and travel over the same h2 data plane.

Built-in models ship **no bundle at all**: the dispatch carries a
`builtin:<type>` sentinel and the worker resolves the model from its own
binary's registry — enrollment already guaranteed version lockstep, and a
sentinel for a type the worker does not know is a loud
binaries-disagree error. Co-located extension assets — files resolved through
`context.extensionFile(relPath)` — are *not* inlined into the single-file JS
bundle; the worker prefetches only the files declared in the manifest's
`additionalFiles` via `GET /bundle/{fingerprint}/files` +
`GET /bundle/{fingerprint}/file/{relPath}` before executing, because
`extensionFile()` is synchronous and must resolve a local path. Both routes
are gated to the declared set — undeclared files under the extension's
`filesRoot` are never listed or served, preventing accidental exposure of
unrelated repository content to remote workers. Assets cache under the
fingerprint like the bundle itself.

### Pre-flight checks are skipped for remote steps; reports run at the orchestrator

Pre-flight checks are **skipped** for remotely-placed steps. Checks run on the
orchestrator, which cannot access worker-local filesystem state — a check like
`@swamp/git`'s `repo-initialized` that runs `git rev-parse` against a
worker-local path would always fail on the orchestrator where that path does not
exist. For remotely-placed steps, the method body runs on the worker where
filesystem preconditions fail naturally if unmet.

Post-run **reports** keep their existing pipeline position **after the execution
seam at the orchestrator** — this is where they have always run relative to
out-of-process execution, and report-provider bundles never need to ship. (The
dispatch protocol reserves `reportBundleFingerprints` should that ever change.)
Output records, deletion markers, and follow-up actions also run at the
orchestrator with local repositories, unchanged. Control-plane bookkeeping runs
(worker/token/lease transitions) skip per-run report artifacts so pool churn
stays bounded.

## Data semantics

Two facts about swamp's data model shape the contract, both verified against the
current code.

### Writes are immediately durable, not staged

`context.writeResource` / `createFileWriter` call `repo.save()`
(`src/domain/models/data_writer.ts`, `unified_data_repository.ts`), which writes
the version directory, metadata, content, `latest` marker, and catalog entry
*before the `await` resolves*. There is no buffer-and-commit-at-end model — and
the system depends on this: `method_execution_service.ts` deliberately collects
handles for data written **before a throw**, so a write-then-throw method (e.g.
a code-review `verdict=FAIL`, the issue-lifecycle model) leaves its data visible.

Consequences for the proxy model: a `persistResource` / `persistFile` is an
HTTP/2 `POST` that completes only once `repo.save()` has persisted at the
orchestrator. There is **no staging layer to build**. A worker that writes 3 of 5
outputs then dies leaves 3 durable writes — exactly what a local process crash
does today.

Two `DataWriter` modes need an explicit remote shape:

- **`writeLine` (append)** promises per-line durability via `repo.append` — the
  live-log contract. Remotely it maps to `POST /data/writers/{id}/line` on the
  data plane: each request is durable at the orchestrator once acknowledged,
  so a worker crash loses at most the unacknowledged tail — same as today.
- **`getFilePath` (direct file I/O)** hands the method a real path, typically so
  a subprocess can write output straight to it. There is no orchestrator path on
  a worker, so remotely the path is a **worker-local spool file**; `finalize()`
  uploads it as one streamed `POST`. For this one mode, durability moves from
  write-time to finalize-time — a worker that dies mid-spool leaves *no* write
  rather than a partial file, the safer of the two divergences. Local behavior
  is unchanged.

### Data is versioned-immutable, not content-addressed

`DataId` is a random UUID (`src/domain/data/data_id.ts`), not a content hash.
A `DataHandle` is identified by the `(dataId, version)` tuple
(`src/domain/models/model.ts`). A pinned `(dataId, version)` is immutable
forever; a bare `dataId` resolves to `latest`, which mutates when a new version
is written.

This sets the **worker cache rule** precisely:

- **Cacheable:** artifact bytes keyed by `(dataId, version)`. Once fetched, that
  version never changes — safe to cache for the life of the worker, and a strong
  `ETag` on `GET /data/{type}/{modelId}/{dataName}/{version}` lets the runtime honor it for free.
- **Always live:** `latest` resolution and `queryData` results. `latest`
  resolution is a small control-plane RPC that yields a concrete version, which
  the worker then fetches (and caches) over h2.

"Lazy-load" therefore means "lazy-load *and* cache by versioned handle," which
collapses the round-trip cost of hot, immutable reads. The same immutability is
what gives worker-state data (above) free lifecycle history.

## Data plane: two transports

A worker never holds datastore configuration; all data still flows to the
orchestrator. But rather than hand-build chunking and flow control over one
socket, the orchestrator exposes **two worker-initiated transports**. The
realization that makes this clean: **the entire data plane is worker-initiated** —
a running method only ever *pulls* its inputs and *pushes* its outputs, and even
the bundle is pulled on a cache miss, so plain request/response suffices and no
server-push is needed.

- **Control plane — WebSocket** (worker-initiated, bidirectional, small messages):
  enrollment, dispatch, cancel, streamed run events, and the metadata capability
  verbs (`queryData`, `latest` resolution, `resolveSecret`, `readDefinition`,
  `resolveModel`, `log`). This is the symmetric two-registry protocol above.
- **Data plane — HTTP/2** (worker-initiated request/response, streamed): the
  byte-heavy operations only — read artifact content
  (`GET /data/{type}/{modelId}/{dataName}/{version}`), write artifact content (`POST /data/resource` →
  `repo.save()`), and bundle fetch on a cache miss (`GET /bundle/{fingerprint}`).
  HTTP/2 supplies multiplexing and per-stream flow control natively, so the
  chunking, credit accounting, and priority queues we would otherwise hand-roll
  come from the runtime. Deno streams request and response bodies, so memory stays
  bounded on both ends.

Implementation note: Deno negotiates HTTP/2 only via ALPN over TLS, so the
data plane runs h2 under `wss://`/`https://` deployments and HTTP/1.1 over
plain TCP — the handlers are identical either way, and the single listener
serves both the control socket and the data plane. The worker derives the
data-plane base URL from its connect URL (`ws → http`, `wss → https`) unless a
dispatch overrides it for split deployments.

Both connections are dialed **outbound by the worker**, so NAT-friendliness is
preserved. Ideally they are a *single* connection — a WebSocket bootstrapped over
an HTTP/2 stream via extended `CONNECT` (RFC 8441) — but Deno's WebSocket is
HTTP/1.1-based on both the server-upgrade and outbound-client sides and does not
implement RFC 8441 today, so v1 runs two worker-initiated connections that can
share one port via ALPN. Collapsing them to a single connection is a clean future
optimization if Deno gains RFC 8441 support. Versioned-immutable data is a natural
fit for h2: `GET /data/{type}/{modelId}/{dataName}/{version}` is an immutable, strongly-`ETag`'d
resource, freely cacheable by the worker and any intermediary.

### Authenticating the data plane

The two transports share one identity. At enrollment (over the control socket) the
orchestrator issues a short-lived **bearer token** as the session credential; the
worker presents it on every HTTP/2 request to prove it is an enrolled worker. Its
lifetime is deliberately short; the worker refreshes it over the control socket a
set interval before it would expire, so the window **slides** forward and an
active worker stays continuously authenticated with no hard cliff. A control-socket
reconnect also re-issues it.

Authorization on top of that authentication starts deliberately thin — it mirrors
single-host semantics and needs almost no new code:

- **Writes are constrained to the step's declared output specs.** This is already
  enforced by the data writer: `createResourceWriter` / `createFileWriter` throw
  on an undeclared spec (`Undeclared resource spec '<name>'`, `data_writer.ts`).
  Schema validation is deliberately *warn-only* in the writer today — it emits a
  `schema_validation_warning` event rather than rejecting — so spec-name
  enforcement, not schema enforcement, is the write-scoping guarantee. Because
  the orchestrator persists a worker's `POST` through that same writer, a worker
  can only write to specs its model declares — no new authorization layer
  required.
- **Reads are dispatch-scoped.** `getData` is refused for a model type
  outside the active dispatch's scope (`#assertDispatchScope` in
  `src/serve/capability_service.ts`); `queryData` caps predicate length and
  post-filters results so a query that touches access-control or
  infrastructure model data is rejected outright. `listVersions` is the one
  verb with no scope assertion.

## Scheduling, fan-out, and provisioning

The orchestrator owns the DAG (`WorkflowExecutionService`,
`src/domain/workflows/execution_service.ts`) and the worker pool — whose state
lives in swamp data ([above](#worker-state-is-swamp-data)). *Logical
provisioning* — admitting workers into that pool — is in scope for v1 and consists
of token issuance + enrollment + the data-backed pool + label dispatch.

Dispatch matches a ready step against the pool:

1. **Direct target (optional)** — a step may pin to a specific worker by its
   token name or `instanceUuid`. The scheduler routes only there, queuing until
   that worker is free or failing if it is not connected.
2. **Label selectors** — otherwise, does the worker match the step's required
   labels (`region=us-east`, `gpu`, a container/sandbox tag, etc.)? Isolation and
   environment requirements are expressed here, since there is no runtime axis.
3. **Platform/arch** — does the worker satisfy any platform constraint?
4. **Tiebreak** — most free slots, then worker name, among matching workers
   (`src/domain/remote/scheduler.ts`; there is no round-robin); queue when all
   matching workers are busy, up to `queueTimeout` (default
   `DEFAULT_QUEUE_TIMEOUT_MS` = 600 s, `src/serve/dispatch_service.ts`).

### Disconnected-worker early warning

When a step explicitly targets a worker by name and that worker is in the live
pool but disconnected (within the grace window), the dispatch service emits a
`target_disconnected` event before entering the queue loop
(`src/serve/dispatch_service.ts`), surfaced to run consumers as
`step_target_disconnected` (`src/domain/models/method_execution_service.ts`). This
is defense-in-depth — the primary prevention mechanism is `workers.connected()`
(see [expressions.md](./expressions.md#workers-namespace)), which filters out
disconnected workers at query time so fleet fan-out workflows never create
steps for unavailable workers. The early warning only fires for workers still
in the in-memory grace window; workers already removed from the pool are not
checked.

Label + platform matching, direct targeting, and **worker affinity** are the
placement and co-location story. Data-locality affinity is not pursued — because
every capability proxies home, **compute location and state location are fully
decoupled** — a step's data lives at the orchestrator regardless of which worker
runs it. v1 dispatches at the **step** granularity, which is what yields fan-out
*across* workers; shipping a whole workflow to one worker is just the degenerate
single-worker case.

#### Worker affinity

`affinity: true` can be set at the **workflow** or **job** level. When set, the
dispatch service pins all remote steps in that scope to the same worker: the
first step scheduled via the normal label/platform matching picks a worker, and
all subsequent steps in the group are forced to that worker via an internal
target override. Workflow-level affinity scopes the group to the entire run;
job-level scopes it to the job.

If the pinned worker disconnects mid-group — whether between steps or during a
dispatch — the step fails with a `WorkerAffinityLostError` instead of
re-dispatching. This preserves the co-location guarantee: silent re-dispatch to
another worker would violate the contract the author opted into.

The dispatch service maintains the pins in an in-memory `affinityKey → worker`
map, keyed by `runId` (workflow-level) or `runId:jobName` (job-level). Pins are
released when the group completes.

A step declares its requirements in workflow YAML with four placement fields
(`PlacementFieldsSchema` in `src/domain/workflows/placement.ts`) — `target:`
(worker name or `instanceUuid`), `labels:` (selector map), `platform:`, and
`queueTimeout:` (seconds to wait for a matching worker). These fields can be
set at the **workflow**, **job**, or **step** level with inheritance:
workflow-level placement applies to all steps as a default, job-level
overrides workflow, and step-level overrides job. An explicit `labels: {}`
clears the inherited labels, and causes the step to run locally only when no
`target` or `platform` remains in effect (`src/serve/dispatch_service.ts`).
Omitting a field inherits from the parent.
**`forEach` is the fan-out construct**: it already expands one step template
into N parallel instances (`ForEachExpansionService`), so `forEach` over a list
plus a label selector *is* "fan out across the fleet," with the existing
step-level `concurrency` field now capping in-flight dispatches rather than
in-process method runs.

v1 dispatch slots into the execution loop that exists: jobs and steps already
run concurrently within each topological level (`mergeWithConcurrency` from
`src/infrastructure/stream/merge.ts`, used by
`src/domain/workflows/execution_service.ts`), so a dispatching step executor that awaits a worker
instead of running in-process fans out naturally — N ready steps in a level
become N concurrent dispatches, queuing (not failing) when no matching worker is
free. The known consequence: fan-out breadth at any moment is bounded by the
steps ready in the current topological level and their concurrency caps. A
free-running ready-step queue that dispatches across level boundaries is future
work, not v1.

### Host launching is a swamp workflow

Actively launching worker *hosts* is not a bespoke provider plugin — it is a
swamp workflow, which is why worker state living in swamp data matters. The two
pieces:

- **Token minting is a built-in model.** Its `mint` method records the
  enrollment-token data *and writes the token secret into a vault*, returning a
  vault reference (not the secret) as its output. A provisioning workflow calls
  it, then passes the reference downstream.
- **Worker-launch models are ordinary user extensions** — a model wrapping a k8s
  Job, a cloud VM API, etc., that reads the token via a `${{ vault.get(...) }}`
  expression and boots the swamp binary with the token and orchestrator URL so it
  dials home. swamp ships the *mechanism*; the cloud/k8s integrations are authored
  as extension models.

Because the token's plaintext only ever lives in the vault, it never lands in
persisted workflow run data. A provisioning workflow can `data.query` the pool,
decide how many workers to add, mint that many tokens, and fan out launch steps —
and an autoscaler is simply that workflow on a schedule. There is no
chicken-and-egg: the provisioning workflow runs on the orchestrator's **loopback
executor**, so the first workers launch with an empty pool; once they enroll,
later provisioning can itself fan out across them.

## Failure, reconnection, and retry

The immediate-write contract makes naive retry unsafe. Writes are **not
idempotent**: `dataId` is a fresh UUID and each save bumps a version counter, so
re-running a step that already wrote produces duplicate versions and orphaned
artifacts. Reconnection and retry are both governed by that single constraint.

Liveness is the **control socket**; a data-plane HTTP/2 request that fails is
per-request — a failed read is simply retried (reads are idempotent), and a failed
write is the ambiguity case below. When the control socket drops with a step in
flight, the orchestrator holds the step lease through a **reconnection grace
window** (`DEFAULT_GRACE_WINDOW_MS` = 60 s, `src/serve/worker_gateway.ts`;
token expiry is enforced by a separate timer that disconnects the worker when
its token lifetime elapses) before giving up — so reconnection and re-dispatch
never race into double execution:

- **Worker reconnects within the window** (same `{token, machineId}`): it
  stays in the pool — same member, fresh session credential. As built, an
  in-flight dispatch does **not** survive the drop: the RPC pending state dies
  with the socket on both ends, and the worker aborts its in-flight execution
  when the channel closes (so a reconnected worker can never double-execute).
  If the step had **not written**, it is simply re-dispatched — to the
  reconnected worker or any other match — which is observably equivalent to
  resuming. If a **write** had landed, the step fails the run per the
  write-then-fail rule below.
- **Worker does not reconnect within the window:** the lease ends the same
  way. A **no-write** step re-dispatches to another matching worker; a
  **write-bearing** step fails the run and surfaces the partial state — exactly
  as a local mid-method crash leaves partial data today. swamp does not
  auto-retry crashed methods locally either, so this is not a regression.

### Write-bearing classification

Write-bearing status is determined by **two complementary mechanisms**:

- **Runtime inference (default):** The `DispatchService` tracks whether a
  dispatch performed any durable data-plane write via `recordFirstWrite`. This
  is automatic and requires no workflow author action — the data plane marks
  the dispatch on `POST /data/resource` and on a file writer's `line`,
  `content`, and `finalize` requests (`src/serve/data_plane.ts`). Merely
  opening a writer (`POST /data/writers`) does not mark it.

- **Declared at the step level (`writes: true`):** A step, job, or workflow may
  declare `writes: true` in the workflow YAML. When set, the dispatch is
  pre-marked as write-bearing **before the method body runs** — a worker
  disconnect fails the run immediately instead of re-dispatching, even if no
  data-plane write has occurred. This is necessary for steps that mutate
  external systems (API calls, `kubectl apply`, SSH commands) without calling
  `writeResource`, because the orchestrator cannot observe those side effects.
  Inheritance is child-wins: step overrides job, job overrides workflow.

A step with both `writes: true` and runtime data-plane writes is handled
correctly — `recordFirstWrite` is a no-op when the dispatch is already marked.

Transparent re-dispatch (or mid-step resume) of a write-bearing step is a later
feature that must first solve write idempotency. It is not promised in v1.

### Pre-enrollment failure handling

When the control socket closes before enrollment completes (e.g. HTTP 401/403
from token auth, or a network-level rejection), the worker treats it as a
connection error and applies two guards:

- **Permanent failure detection.** If the error message matches one of the
  seven permanent patterns in `isPermanentEnrollmentFailure`
  (`src/worker/connect.ts`: `revoked`, `expired`, `does not match`,
  `already bound`, `protocol version`, `does not exist`,
  `allowance exhausted`), the worker stops immediately with a clear error.
  These conditions cannot be fixed by retrying.

- **Consecutive failure cap.** If the error does not match a known pattern, the
  worker counts the failure and throws on the third consecutive one
  (`MAX_PRE_ENROLL_FAILURES`). The counter resets whenever a `connectOnce`
  attempt returns normally (i.e. after an enrolled session ends), so transient
  blips during an established session do not accumulate.

Post-enrollment socket drops (the worker was enrolled and executing dispatches)
continue to use exponential backoff and reconnect normally — a brief network
interruption during a session should not terminate the worker.

## Security and trust

The proxy-everything model with shipped code is a net security improvement over
provisioning credentials and extensions onto workers:

- A worker holds **no datastore or vault credentials, no datastore config, and no
  pre-installed extensions**. It reads or writes only what the orchestrator hands
  it, and runs only the bundle it was dispatched. The one deliberate exception is
  the per-dispatch environment snapshot
  (see [The execution environment](#the-execution-environment)): while a step is
  in flight, the worker holds the orchestrator's ambient environment in memory,
  scoped to that step's lifetime. The orchestrator sees *every*
  capability call and authorizes every data-plane request against the step lease,
  so it is a natural authorization and audit chokepoint. Per-step secret scoping
  is the orchestrator refusing a `resolveSecret` outside the dispatched step's
  allowed set. Vault secrets are resolved orchestrator-side and travel only for
  the step that needs them (consistent with the out-of-process resolution pattern
  of the removed execution-drivers design).

  **Secret redaction.** Vault-derived values must be scrubbed from all persisted
  output — log resources, result resources, and workflow-run records — before
  they reach durable storage or the WS event stream. Two complementary layers
  enforce this:

  1. **Worker-side (source redaction):** The orchestrator extracts resolved
     secret values from sensitive argument fields and ships them in the dispatch
     params (`secretValues`). The worker registers these with its
     `SecretRedactor` before method execution, so `stdout`/`stderr` and any
     `writeResource` data are redacted at the point of origin.
  2. **Data plane (defense in depth):** The orchestrator stores a per-dispatch
     `SecretRedactor` on the `ActiveDispatch` registration. When the data plane
     persists a worker's `writeResource` call, it passes this redactor to
     `createResourceWriter`, catching any value the worker-side redactor missed.
     **Known limit:** the file-writer path (`POST /data/writers` and its
     `line`/`content` requests) does not receive the redactor
     (`#openWriter` in `src/serve/data_plane.ts`); file outputs rely on the
     worker-side layer alone.

  Both layers use the same `SecretRedactor` class and the same
  `extractSensitiveFieldValues` utility that local execution has always used;
  the invariant is identical, just extended across the dispatch boundary.

- The **enrollment token** is named, time-boxed, and enrolls up to
  `maxEnrollments` machines, each binding to the worker's durable `machineId`. The
  `{token, machineId}` pair is a *bearer* reconnection secret rather than
  proof-of-possession — the machine id is client-asserted, so the binding
  contains *accidental* token reuse (pasting one token onto a second box),
  not an attacker who holds the plaintext. That is acceptable because the pair
  rides the authenticated, encrypted `wss://` channel and the only ways to
  capture it are to MITM the TLS or to compromise the worker host (which
  already grants code execution there, so no additional ground is lost). The
  TLS side is standard trust-anchor verification: `--ca-cert` /
  `SWAMP_CA_CERT` adds a PEM CA to trust (`src/cli/commands/worker_connect.ts`);
  certificate **pinning is not implemented**. The **session credential**
  for the data plane is short-lived and lease-scoped. Lifetimes should be
  short — a token leaked *before* enrollment is the real exposure, since an
  attacker could enroll first. Expiry is enforced actively: the orchestrator
  disconnects a connected worker when its token lifetime elapses, and `revoke`
  cuts a token off early.

- Conversely, a worker tricked into connecting to the wrong URL hands code
  execution on its host to whoever owns that URL — the same trust model as a
  self-hosted CI runner. Both channels are authenticated and encrypted under
  `wss://`; operators who need a stronger binding than CA trust should front
  the orchestrator with a private CA supplied via `--ca-cert`.

## What is reused vs. new

| Concern                          | Status                                                                                  |
| -------------------------------- | --------------------------------------------------------------------------------------- |
| Control protocol + multiplexing  | **Reuse** `src/serve/protocol.ts`, `connection.ts`, `serializer.ts`                     |
| Serializable execution envelope  | **Reuse** `ExecutionRequest` / `ExecutionResult` (serialize `followUpActions`; the envelope never carried driver fields) |
| Extension bundle + fingerprint   | **Reuse** `bundleSourceFactory` + inline `sha256Hex` fingerprint; fetched over h2 on miss; co-located assets ship the same way (report bundles do not ship — `reportBundleFingerprints` is always `[]`, `src/serve/dispatch_service.ts`) |
| Checks and reports pipeline      | **Reuse** at the orchestrator — checks are skipped for remote steps; reports run after the execution seam |
| Pure injectable operations       | **Reuse** libswamp `*Deps` + `MethodContext` injection seam                             |
| Worker/token/lease persistence   | **Reuse** the datastore + catalog — built-in models, not a private registry             |
| Out-of-process secret resolution | **Reuse** the resolve-before-dispatch pattern                                           |
| Run-event serialization          | **Reuse** `serializeEvent()`; worker → orchestrator events ride `rpc.stream` frames      |
| Driver abstraction               | **Remove** `ExecutionDriver`, raw/docker/custom drivers, registry, `driver:` fields      |
| Role split (server ≠ executor)   | **New** — move request-dispatch handling to the dial-out side; two handler registries   |
| Enrollment handshake             | **New** — token redemption, machine binding, label exchange, session-credential issue    |
| Built-in worker-management models| **New** — `worker`, `enrollment-token`, `step-lease`; `swamp worker token` + mint model   |
| Remote `MethodContext` adapters  | **New** — proxy implementations of the repository/vault/data-writer ports               |
| Capability protocol verbs        | **New** — nine `capability.*` verbs over ws (metadata) plus the h2 data-plane routes (bytes) |
| Environment shipping             | **New** — per-dispatch orchestrator env snapshot, worker-memory only                     |
| Spool + append write modes       | **New** — worker-local spool for `getFilePath`; `POST /data/writers/{id}/line` for `writeLine` |
| HTTP/2 data plane + auth          | **New** — worker-initiated bulk transfer; bearer-token auth, existing spec-write enforcement |
| Label scheduler + direct target  | **New** — data-backed pool registry, label/platform matching, target-by-name/uuid; step-level `target:`/`labels:`/`platform:` YAML fields |
| Lease + reconnection + failure   | **New** — grace window, full re-dispatch of no-write steps after a drop, write-then-fail |
| `swamp worker connect` command   | **New** — the dial-home CLI entry                                                        |

## v1 scope and non-goals

In scope:

- Worker dial-home + enrollment over `wss://` with a named, time-boxed token that
  enrolls one or more machines and reconnects each `{token, machineId}` for its lifetime;
  `swamp worker token` commands and a built-in mint model that writes the token to
  a vault.
- Drivers removed: isolation as a worker deployment property, the local
  loopback executor for single-host.
- Each dispatch runs in a child process (dispatch runner) for crash isolation
  and clean environment handling; extension code fetched over the data plane on
  a cache miss and loaded in the runner process.
- Remote `MethodContext` with the nine-verb capability protocol plus data-plane
  routes proxied home, including the spool-on-finalize `getFilePath` and
  per-request-durable line-append write modes; checks skipped for remote
  steps and reports run at the orchestrator.
- Per-dispatch environment shipping: the orchestrator's full env snapshot,
  worker-memory only, applied to the method and its subprocesses.
- A WebSocket control plane plus a worker-initiated HTTP/2 data plane for bulk
  transfer — native multiplexing/flow control, no hand-rolled framing.
- Worker/token/lease state persisted as swamp data by built-in models and
  queryable, with declared retention (`garbageCollection`/`lifetime`);
  token/lease transitions serialized in the orchestrator process.
- Versioned-handle read caching on the worker.
- Label + platform scheduling, plus direct targeting by worker name/uuid, over an
  orchestrator-owned, data-backed pool; step-level `target:`/`labels:`/
  `platform:` fields, with `forEach` as the fan-out construct and dispatch
  slotted into the existing level-parallel execution loop.
- Reconnection grace window; fail-the-run-on-write-then-drop failure semantics.
- The mint model and dial-home contract that let host launching be authored
  as a swamp workflow (mint model → vault → launch model → dial home),
  bootstrapped on the loopback executor.

Explicit non-goals for v1:

- **Remote datastore configuration for workers.** Workers never hold datastore
  config; all data terminates at the orchestrator. Revisit only if the ceiling
  bites.
- **Data-locality scheduler affinity.** Worker affinity (`affinity: true`)
  provides explicit co-location; automatic data-locality routing is not pursued.
- **Shipping cloud/k8s launch integrations.** swamp ships the mint model and
  dial-home contract; the launch models are user-authored extensions.

## Known limits

- **Latency amplification.** In-process capability calls are nanoseconds; over
  the wire each becomes a round-trip. Versioned-handle caching, the h2 data plane,
  and concurrent control RPCs mitigate it; the write path stays synchronous by
  contract.
- **Orchestrator as the data plane and SPOF.** Every read, write, secret,
  definition load, and catalog lookup — plus all worker-state bookkeeping —
  terminates at the orchestrator and its one datastore, so total throughput and
  availability are bounded by it, not by worker count. This is the accepted trade
  for credential-free workers and a single durable authority.
- **Two-transport correlation.** Until Deno supports RFC 8441, control (ws) and
  bulk (h2) are two separate worker-initiated connections sharing one identity via
  the session bearer token. Modest new surface — and the price of offloading
  framing to HTTP/2 rather than hand-rolling it.
- **Level-bounded dispatch.** v1 dispatches inside the existing level-parallel
  execution loop, so fan-out breadth at any moment is bounded by the steps ready
  in the current topological level and their concurrency caps — not by fleet
  size. A cross-level ready-step queue is future work.
- **Whole-environment dispatch.** Every dispatched step receives the full
  orchestrator environment snapshot; per-token or per-label env scoping is a
  later refinement.
- **No periodic bookkeeping GC.** Worker, token, lease, and pending-dispatch
  records accumulate until an operator runs `swamp data gc`; only the boot
  sweep is automatic.
- **No in-flight resume.** A dispatch that loses its control socket is
  re-dispatched from scratch when no write had landed
  (`src/serve/dispatch_service.ts`); partial progress on the worker is
  discarded.
- **No certificate pinning.** Worker TLS trust is CA-based (`--ca-cert`).
- **Report bundles do not ship.** Reports run at the orchestrator only.
- **`continueCondition` is dropped for remote steps** (see
  [The capability protocol](#the-capability-protocol)).
- **HTTP/2 is whatever Deno negotiates.** The listener passes no
  `alpnProtocols`; h2 on the data plane rests on Deno's TLS defaults.

## Hot-Reload for Pulled Extension Bundles

`swamp serve` loads extension bundles at startup and pins them for the process
lifetime. The `--hot-reload` flag enables SIGHUP-based hot-reload following the
nginx pattern.

### User Flow

1. Start serve with `swamp serve --hot-reload`
2. Push updated extension code, pull it (`swamp extension pull @name --force`)
3. Trigger a reload:
   - **Local**: `swamp serve reload` — reads `.swamp/serve.pid`, sends SIGHUP
   - **Remote**: `swamp serve reload --server wss://host:port` — sends a
     `serve.reload` WebSocket request (requires admin authorization)
4. Serve reloads all pulled extension types. In-flight requests complete on old
   code; new requests use new code.

### Mechanism

Both the SIGHUP signal handler and the `serve.reload` WebSocket handler call the
same shared `performServeReload()` function in `src/serve/extension_reload.ts`.
A module-level reloading guard (`isReloading()`) rejects a concurrent reload
from either trigger; `serve.reload` on a server started without
`--hot-reload` is refused with `hot_reload_disabled`
(`src/serve/handlers/admin_handlers.ts`). Besides extension types, a reload
also re-reads the `.swamp/serve.yaml` trigger overrides and refreshes the
extension trust list.

`reloadPulledExtensions()`:

1. Increments the module-level `reloadGeneration` counter
2. Opens a fresh `ExtensionCatalogStore` (reads `_extension_catalog.db`)
3. Reads the lockfile via `LockfileRepository` for extension names/versions
4. Queries `catalog.findBySourcePathPrefix(sourcePrefix)` for type rows
5. Re-bundles any source whose fingerprint changed, writing the new bundle
   file and recording the fingerprint with `catalog.updateSourceFingerprint()`
6. For each type across all four kinds (model, vault, datastore, report):
   - `invalidateType()` — removes from the registry's loaded and lazy maps
   - `registerLazy()` — re-adds with updated `source_fingerprint`
   - `ensureTypeLoaded()` — triggers `loadSingleType()` →
     `importBundleByPath()`, which imports
     `bundle?fp=<fingerprint>&gen=<reloadGeneration>` so V8's module cache
     is bypassed even when the fingerprint is unchanged
     (`src/domain/extensions/extension_loader.ts`)

### Catalog Safety Constraint

The reload path never calls `ExtensionCatalogStore.invalidate()`,
`ExtensionLoader.buildIndex()`, or `ensureLoaded()`. Only the per-type path
(`loadSingleType` and its sub-calls) is permitted. Its writes are the
re-bundled bundle file and `catalog.updateSourceFingerprint()`, so subsequent
reloads skip unchanged sources.

### Concurrency

During the reload window, a type is momentarily in `lazyTypes` (not yet
imported). Serve execution paths resolve types through
`resolveModelType()`/`resolveVaultType()`/`resolveDatastoreType()` or call
`ensureTypeLoaded()` directly (e.g. `src/cli/repo_context.ts`,
`src/cli/resolve_datastore.ts`, the datastore health check in
`src/cli/commands/serve.ts`) before `get()`. Concurrent callers share the same
load promise via `typeLoadPromises` and wait rather than failing.

### Known Limitations

- **SIGHUP carries no payload**: Cannot target a single extension; all pulled
  extensions are reloaded. Cost is proportional to pulled extension count.
- **Windows**: SIGHUP is not available. `--hot-reload` fails with a clear
  message on Windows.
- **V8 module cache**: Cache busting uses `?fp=<source_fingerprint>&gen=<reloadGeneration>`
  query parameters; the generation counter guarantees a fresh import on every
  reload even when the fingerprint is unchanged.

