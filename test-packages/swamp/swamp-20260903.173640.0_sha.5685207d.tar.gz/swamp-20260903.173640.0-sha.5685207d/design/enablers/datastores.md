---
audience: maintainer, operator, extension-author
enables: [data]
last-verified: 2026-08-28 @ 3d5955a9
---

# Datastores

A datastore in swamp determines where runtime data is stored. Runtime data
includes versioned model data, workflow runs, method outputs, audit logs,
telemetry, encrypted secrets, and cached bundles.

**Important:** Source-of-truth files (model definitions, workflow definitions,
vault configs) always live in the top-level `models/`, `workflows/`, `vaults/`
directories of the repository and are tracked in git. They are never part of the
datastore.

## Backends

Swamp has one built-in datastore backend (filesystem) and supports extension
backends via the datastore extension system.

### Filesystem

Stores runtime data at a local filesystem path. This is the default backend —
when no datastore is configured, runtime data lives in `{repoDir}/.swamp/`.

```yaml
# .swamp.yaml
datastore:
  type: filesystem
  path: /mnt/shared/swamp-data
```

An external filesystem path is useful for shared NFS mounts or keeping runtime
data out of the git repository.

### S3 (via `@swamp/s3-datastore` extension)

Stores runtime data in an S3 bucket with a local cache at
`~/.swamp/repos/{repoId}/`. All reads and writes hit the local cache;
synchronization with S3 happens automatically before and after each CLI command.

```yaml
# .swamp.yaml
datastore:
  type: "@swamp/s3-datastore"
  config:
    bucket: my-swamp-bucket
    prefix: project-name
    region: us-east-1
```

Legacy `type: s3` configs are automatically remapped to `@swamp/s3-datastore`
with a deprecation warning. The extension is auto-installed on first use when
the logged-in user has at least one trusted collective
(`src/cli/mod.ts` `resolveTrustedCollectives`; no trusted collective means no
auto-resolver). `@swamp/gcs-datastore` is the GCS equivalent
(`src/cli/commands/datastore_setup.ts`).

The local cache is fully disposable. Deleting it or cloning the repo on a new
machine repopulates the cache from S3 on the next command.

## Custom Backends

Extensions can register custom datastore backends via `extensions/datastores/`.
These are TypeScript files that export a `datastore` object conforming to the
`DatastoreProvider` interface, enabling storage on any backend swamp doesn't
ship with.

### Type Registry

The `DatastoreTypeRegistry` is a Map-backed singleton
(`datastoreTypeRegistry`). The built-in type (filesystem) is registered at
startup. Extension types (e.g., `@swamp/s3-datastore`) are loaded from
`extensions/datastores/` via `ExtensionLoader` with `datastoreKindAdapter` or
auto-resolved from the registry on first use. Types must follow the `@collective/name` or
`collective/name` pattern (e.g., `@myorg/redis-store`). Duplicate type
registrations are rejected with an error.

### DatastoreProvider Interface

A custom datastore implements seven methods, three of them required:

- **`createLock`** — returns a `DistributedLock` for concurrency control
- **`createVerifier`** — returns a `DatastoreVerifier` for health checks
- **`createSyncService?`** — optional; returns a `DatastoreSyncService` for
  remote sync (pull/push)
- **`resolveDatastorePath`** — resolves the datastore path relative to the repo
- **`resolveCachePath?`** — optional; resolves a local cache path (for remote
  backends)
- **`registerNamespace?`** — optional; writes the namespace manifest, failing
  if the slug is already claimed
- **`listNamespaces?`** — optional; returns the slugs found in namespace
  manifests (see [Namespace manifests](#namespace-manifests))

See `src/domain/datastore/datastore_provider.ts` for the full interface.

### Loading & Bundling

`ExtensionLoader` (with `datastoreKindAdapter`) discovers `.ts` files
recursively in the datastores directory (excluding `_test.ts` files), bundles
each via Deno with zod externalized, and validates the export against
`UserDatastoreSchema` — a Zod schema requiring `type`, `name`, `description`,
an optional `configSchema`, and a `createProvider` factory function. Files
without a `datastore` export are silently skipped. Bundles are cached in
`.swamp/datastore-bundles/` with
content-fingerprint invalidation (sha-256 over the entry point plus every
local `.ts` dep) to avoid redundant compilation — mtime-based freshness was
unreliable under atomic-rename saves, mtime-preserving sync tools, and
sub-millisecond edits (issue #125; `src/domain/extensions/bundle_freshness.ts`).
If re-bundling fails for any reason and a cached bundle exists, the cached
bundle is used (`extension_loader.ts`). The failure is logged at debug level
when it is expected — bare specifiers such as `from "zod"` instead of
`from "npm:zod@4"`, which cannot resolve without the project's `deno.json`
import map — and at warn level otherwise. Only the module's own static imports
count — import statements inside template literals are generated code and are
ignored.

### Custom Type Configuration

Custom types use the same resolution priority as built-in types. In
`.swamp.yaml`, custom types use the `type:` and `config:` fields:

```yaml
datastore:
  type: "@myorg/redis-store"
  config:
    host: localhost
    port: 6379
```

In environment variable format: `SWAMP_DATASTORE=@org/name:{"key":"val"}`. The
config object is validated against the optional `configSchema` Zod schema
defined by the extension.

### Custom Backend Implementation Files

| File | Purpose |
|------|---------|
| `src/domain/datastore/datastore_provider.ts` | `DatastoreProvider` interface |
| `src/domain/datastore/datastore_type_registry.ts` | Type registry singleton |
| `src/domain/extensions/extension_loader.ts` | Generic extension loader (used with kind adapters) |
| `src/domain/extensions/datastore_kind_adapter.ts` | Datastore-specific kind adapter for ExtensionLoader |
| `src/domain/datastore/datastore_sync_service.ts` | `DatastoreSyncService` interface |
| `src/cli/datastore_expression_resolver.ts` | Resolves `${{ env.* }}` and `${{ vault.get() }}` expressions in datastore config values |

### Config Value Interpolation

String values in the datastore `config` object support expression interpolation
using the same `${{ }}` delimiter syntax as model and workflow definitions.
Expressions are resolved during config resolution, before the config is passed
to the extension's schema validation and `createProvider()` factory.

Two expression namespaces are supported:

**Environment variables** — `${{ env.VAR_NAME }}`

Resolves to the value of the named environment variable. Throws a startup error
if the variable is not set or empty. This is the simplest approach for keeping
secrets out of `.swamp.yaml` — the token comes from the operator's environment
(direnv, shell profile, 1Password CLI, etc.).

```yaml
datastore:
  type: "@myorg/gitlab-datastore"
  config:
    token: "${{ env.GITLAB_TOKEN }}"
    endpoint: "https://${{ env.GITLAB_HOST }}/api/v4"
```

**Vault secrets** — `${{ vault.get(vaultName, secretKey) }}`

Resolves to the decrypted value of the named secret from the named vault. All
installed vault types are supported (native `local_encryption` and extension
providers like `@swamp/aws-sm`). The vault service is initialized lazily — only
when a `vault.get()` expression is encountered.

```yaml
datastore:
  type: "@myorg/postgres-datastore"
  config:
    connectionString: "${{ vault.get(infra, pg-connection-string) }}"
```

**Limitations:**

- Only `env.*` and `vault.get()` are supported. The full CEL evaluation context
  (model references, data lookups) is not available at this bootstrap phase.
- All installed vault types work (native and extension). Extension vault
  bundles are loaded directly from the `.swamp/vault-bundles/` cache during
  early boot, bypassing the extension loader. If an extension vault is not
  installed, install it before referencing it in datastore config.
- Vault expressions are not supported when `managedConfig: true` — managed
  config stores vault configurations in the datastore tier, creating a circular
  dependency. Use environment variable expressions instead.

## Configuration

### Resolution Priority

Datastore config is resolved from multiple sources (highest priority first):

1. `SWAMP_DATASTORE` environment variable
2. CLI `--datastore` argument
3. `.swamp.yaml` `datastore` field
4. Default: filesystem at `{repoDir}/.swamp/`

The environment variable format is `type:value`:

```bash
export SWAMP_DATASTORE=filesystem:/path/to/dir
export SWAMP_DATASTORE=@swamp/s3-datastore:{"bucket":"my-bucket","region":"us-east-1"}
```

Legacy `s3:bucket-name/prefix` format is auto-remapped to the
`@swamp/s3-datastore` extension.

### Fine-Grained Control

Two optional fields control which data goes to the datastore:

- **`directories`** — which subdirectories belong to the datastore. Defaults to
  `DEFAULT_DATASTORE_SUBDIRS` (`datastore_config.ts`): `auto-definitions`,
  `definitions-evaluated`, `workflows-evaluated`, `config`, `data`, `outputs`,
  `workflow-runs`, `audit`, `telemetry`, `logs`, `files`, plus the bundle
  directories. Anything not listed stays in local `.swamp/`. Note:
  `ALWAYS_LOCAL_SUBDIRS` (`secrets`, `bundles`, `vault-bundles`,
  `report-bundles`) stay local regardless of this setting.
  `swamp datastore setup filesystem --directories` sets the list at setup time.
- **`exclude`** — gitignore-style glob patterns. Files matching these patterns
  stay local even if their parent directory is in the datastore.

```yaml
datastore:
  type: filesystem
  path: /data/my-project
  directories:
    - data
    - outputs
    - workflow-runs
  exclude:
    - "telemetry/**"
```

### Sync Timeout

Each direction of a remote sync (push / pull) is bounded by a hard deadline
enforced in the coordinator, so a stuck or slow extension cannot hang the CLI
indefinitely. The effective timeout is resolved from the first source that
yields a positive value:

1. `--timeout <seconds>` CLI flag — per-invocation override, bounded at 21,600
   seconds (6 hours): `swamp datastore sync` rejects larger values
   (`datastore_sync.ts` `SYNC_TIMEOUT_CLI_MAX_SECONDS`), while
   `swamp datastore setup extension` clamps them (`datastore_setup.ts`).
   Preferred escape hatch for one-off large syncs or initial setup of large
   repos.
2. `CustomDatastoreConfig.syncTimeoutMs` — per-datastore config in
   `.swamp.yaml`. Applies to both explicit `swamp datastore sync` calls and
   the implicit syncs triggered by write commands. Not used by
   `datastore setup extension` (setup runs outside the flush coordinator).
3. `SWAMP_DATASTORE_SYNC_TIMEOUT_MS` — environment variable, uncapped. Useful
   for shell-session-scoped overrides during long-haul migrations. Applies to
   both sync and setup extension.
4. `DEFAULT_SYNC_TIMEOUT_MS` — 5 minutes.

The deadline fires a `SyncTimeoutError` regardless of whether the extension
honored the `AbortSignal` passed to `pushChanged(options)` /
`pullChanged(options)`. Timeouts propagate as a non-zero CLI exit so the user
sees that data did not make it to the remote; other push errors still
warn-downgrade (preserves historical behavior where a transient S3 blip does not
kill a run).

**Setup timeout behavior.** During `datastore setup extension`, a push or pull
timeout is treated as recoverable: the datastore type is still committed to
`.swamp.yaml` so the user can resume with `swamp datastore sync --push
--timeout <big>`. Hard failures (auth errors, network errors, config errors)
still block the type commit. This avoids the scenario where a slow first push
leaves the repo un-migrated despite valid credentials and config.

The `SyncTimeoutError` message lists every available remedy inline
(`--timeout`, the env var, updating the datastore extension, releasing a stuck
lock) so users get actionable next steps without chasing docs. The wording is
version-free — it points at "the latest extension" rather than a specific
version that would rot across releases.

See `src/domain/datastore/datastore_config.ts` (`DEFAULT_SYNC_TIMEOUT_MS`,
`SYNC_TIMEOUT_ENV_VAR`, `resolveSyncTimeoutMs`),
`src/domain/datastore/datastore_sync_service.ts` (`SyncTimeoutError`),
`src/cli/commands/datastore_sync.ts` (`--timeout` flag),
`src/cli/commands/datastore_setup.ts` (`--timeout` flag on setup extension), and
`src/infrastructure/persistence/datastore_sync_coordinator.ts`
(`runBoundedSync`).

## Path Resolution

Every file operation goes through a `DatastorePathResolver` that decides whether
a path belongs to the local tier or the datastore tier:

```
DatastorePathResolver.resolvePath(subdir, ...rest) → string
```

For filesystem datastores, this returns `{config.path}/{subdir}/...`. For
extension datastores (e.g., S3), this returns `{datastorePath}/{subdir}/...`
(typically the local cache path). The `DefaultDatastorePathResolver`
pre-compiles exclude patterns at construction time.

### Namespace prefixing (giga-swamp)

When a `namespace` is configured (giga-swamp multi-repo shared datastores), the
resolver prepends it as the **outermost** segment of the datastore tier:
`{base}/{namespace}/{subdir}/...` — never `{base}/{subdir}/{namespace}/...`.
This is applied at the single `datastorePath()` chokepoint, so it covers every
datastore-tier subdir uniformly. Solo mode (empty namespace) produces
byte-identical paths to a non-namespaced repo — no prefix, no stray separator.
The local tier (`localPath`, `.swamp/`) is never namespaced.

#### Migration

`swamp datastore namespace migrate` re-keys data from the solo layout to the
namespaced layout. For each directory in `DEFAULT_DATASTORE_SUBDIRS` that exists
at the un-namespaced path `{base}/{subdir}/`, it moves it to
`{base}/{namespace}/{subdir}/` via `Deno.rename()`. The catalog is invalidated
after migration so backfill rebuilds from the new paths.

When a file exists at both the source (root) and destination (namespace) paths,
forward migration compares their contents byte-by-byte. Byte-identical
duplicates (e.g. from a buggy pull that wrote namespace-stripped copies to the
cache root) are auto-resolved by deleting the root-level copy. Non-identical
collisions still error — the user must resolve them manually.

The reverse (`--reverse`) flattens namespaced paths back to solo layout, with
conflict detection — it refuses if the un-namespaced path already contains data
files, except for the subdirectories in `MERGEABLE_ON_REVERSE`
(`src/libswamp/datastores/namespace_migrate.ts`), which are merged.
`swamp datastore namespace unset --migrate` combines unset + reverse migration.
Both `namespace migrate` and `namespace unset --migrate` only preview until
`--yes`/`--confirm` is passed.

Two things are deliberately **not** namespaced:

- **The `_catalog.db` catalog** is repo-local at `{repoDir}/.swamp/data/`,
  resolved via the centralized `catalogDbPath` helper (not `resolvePath`).
  Under a shared datastore each repo owns a private catalog, so a per-repo
  backfill never clobbers another repo's rows; the catalog's
  `namespace` column distinguishes own rows from foreign rows pulled in a later
  phase.
- **Secrets and vault bundles** are written through `swampPath`/`localPath`
  (`.swamp/secrets`, `.swamp/vault-bundles`), never through `resolvePath`, so
  the namespace prefix cannot reach them — vaults stay repo-local by
  construction.

#### Orphaned data reclamation (`swamp data prune`)

**Orphaned data** is persisted data whose owning model definition no longer
exists in its namespace — e.g. after the definition is deleted from the repo, or
after a model instance is migrated to a different namespace leaving its
historical data behind. Because the on-disk layout and the catalog `DELETE`
predicate are keyed by model **type** (`{typeDir}/{modelId}/...` and
`type_normalized`), and the type is normally re-derived by resolving the
definition, both `swamp data delete` and `swamp data gc` fail on orphaned data:
`delete` throws `Model not found`, and `gc` only enforces each item's frozen
`lifetime`/`garbageCollection` policy (so `infinite`-lifetime orphans are never
collected). The rows then accumulate in the catalog indefinitely, inflating
index size and per-write sync cost.

`swamp data prune` reclaims them. It walks the datastore data root
(`findAllGlobal`), groups by `(type, modelId)`, and for each group asks a
per-item predicate whether the owning model definition still exists. The
predicate uses the definition repository's `findById` — which resolves **both**
`models/` and `.swamp/auto-definitions/`, matching `swamp model get` — so
auto-definition-backed models (auto-created model-run/workflow models, installed
`@swamp/*` models) are correctly treated as live and never pruned. Groups with
no live definition are reclaimed via the existing definition-free
`delete(type, modelId, dataName)`, which removes all versions on disk and their
catalog rows. Reclamation is irreversible and inferential (a definition can be
transiently absent — a branch switch or an in-flight migration), so prune is
opt-in per invocation, defaults to a confirmation prompt, supports `--dry-run`
for a preview (which uses the lock-free read-only path), and otherwise acquires
the global datastore lock (via `requireInitializedRepo`) like `gc`/`delete`.

This is distinct from two neighbouring concepts:

- **`swamp data gc`** enforces the retention policy a model *declared*
  (lifetime + version-cap). `prune` removes data whose model is *gone*. They are
  deliberately separate commands; `gc` stays safe to run unattended, while
  `prune` gates the inferential deletion behind its own verb.
- **"Orphan recovery"** in `data_access_service.ts` is the *opposite* intent — a
  read-time mechanism that keeps data reachable across a model's UUID change. It
  never deletes anything.

## Remote Datastore Sync

When a remote datastore (e.g., S3 via `@swamp/s3-datastore`) is configured,
synchronization happens automatically:

```
Write commands (create, edit, delete, run, gc, etc.):

  requireInitializedRepo()           ← called at command start
    ├─ acquire distributed lock
    └─ pullChanged()                 ← download new/modified files from S3

    ─── command executes ───
    (reads/writes local cache)

  flushDatastoreSync()               ← called after command completes
    ├─ pushChanged()                 ← upload new/modified files to S3
    └─ release distributed lock

Read-only commands (search, get, list, validate, history, etc.):

  requireInitializedRepoReadOnly()   ← called at command start
    └─ (no lock, no sync)

    ─── command executes ───
    (reads local cache directly)

    (no flush needed)

Explicit datastore sync (`swamp datastore sync` and `--push`):

  requireInitializedRepo({ skipImplicitSync: true })  ← command start
    └─ acquire distributed lock
       (no implicit pullChanged, no implicit pushChanged on flush)

    ─── command executes its OWN pullChanged / pushChanged ───
    (counts reflect work the command itself performed)

  flushDatastoreSync()
    └─ release distributed lock
```

`swamp datastore sync` deliberately bypasses the coordinator's implicit
pull/push. Without `skipImplicitSync` the implicit pull would silently
move files and the explicit pull would fast-path to 0, causing
`filesPulled: 0` to be reported even when data was hydrated (lab #220).
The explicit sync command is the user-facing "tell me what I synced"
command — it owns its I/O and reports honest counts.

`--pull` mode uses `requireInitializedRepoReadOnly` (no lock at all),
matching the existing read-only pattern.

Read-only commands skip the lock and sync entirely, allowing them to run
concurrently with write operations. On filesystem datastores, reads see writes
immediately (same directory). On S3 datastores, reads see whatever was last
synced to the local cache by a write command; users can run
`swamp datastore sync --pull` to refresh manually.

### SyncContext and SyncCapabilities

Extensions can advertise capabilities by implementing the optional
`capabilities()` method on `DatastoreSyncService`:

```typescript
capabilities(): SyncCapabilities {
  return { scopedSync: true, namespacedSync: true };
}
```

`SyncCapabilities` (`src/domain/datastore/datastore_sync_service.ts`) carries
`scopedSync`, `lazyHydration`, `namespacedSync`, `twoPhaseSync`, `previewPush`
(gates `sync --push` behind a preview unless `--yes`/`--confirm`),
`controlPlane` and `configRefresh`.

**`namespacedSync`** (Phase 6): when `true`, the extension correctly handles
the `namespace` field on `DatastoreSyncOptions` — scoping its index walk and
upload to `{namespace}/` in the remote datastore. Extensions that don't
advertise this capability still receive the namespace field but are expected to
ignore it and sync everything (solo-mode behavior).

When `scopedSync` is `true`, swamp core passes a `SyncContext` to
`pullChanged()` and `pushChanged()` containing the models being operated on:

```typescript
interface SyncContext {
  models?: ReadonlyArray<{ modelType: string; modelId: string }>;
}
```

Extensions translate this domain context to their own storage model — S3
extensions filter by key prefix, MongoDB extensions build a query filter, etc.

**Capability gating.** Core only passes context when the extension advertises
`scopedSync`. Extensions that don't implement `capabilities()` (or return
`{ scopedSync: false }`) receive `pullChanged()` / `pushChanged()` with no
arguments — exactly today's behavior.

**Graceful degradation.** If `capabilities()` throws, core catches the error
and falls back to full sync. The try/catch wraps only the `capabilities()` call,
not pull/push.

**Per-model loop behavior.** `acquireModelLocks` calls `pullChanged()` once
per model in the lock acquisition loop. When `scopedSync` is `true`, each call
receives a context containing only the current model whose lock was just
acquired. The extension pulls exactly one model per call.

**Push path.** The flush function calls `pushChanged()` once (not per-model)
under the global lock. When `scopedSync` is `true`, context contains all
deduplicated models. When `twoPhaseSync` is `true`, the push is split into
`preparePush` (outside global lock) and `commitPush` (under global lock) — see
"Two-Phase Sync" below.

**Catalog rebuild invariant.** `synced = true` is set after `pullChanged()`
succeeds on both the scoped and full paths. This boolean is returned in
`{ flush, synced }` and checked at every call site across `src/cli` and
`src/serve` (21 at last count) to trigger `catalogStore.invalidate()`. It must
never be skipped or moved.

### Namespace-Scoped Sync

When a repo has a `namespace` configured in `.swamp.yaml`, the sync lifecycle
scopes push and pull to the namespace's subtree in the remote datastore. This
is how two repos sharing a single S3 bucket avoid syncing each other's data.

#### How namespace flows through sync

1. **Config → coordinator.** `repo_context.ts` reads `datastoreConfig.namespace`
   and passes it to `registerDatastoreSync({ namespace })`. The coordinator
   stores it on the `SyncEntry`.
2. **Coordinator → extension.** On pull, the coordinator passes
   `{ signal, namespace }` to `pullChanged()`. On push (flush), it passes
   `{ signal, namespace }` to `pushChanged()`. The namespace field is only
   included when non-empty — solo-mode calls omit it entirely.
3. **Per-model path.** `acquireModelLocks` reads `datastoreConfig.namespace`
   and passes it alongside the `SyncContext` (model list). When
   `namespacedSync` is advertised, both namespace and context are passed; when
   only namespace is available (no `scopedSync`), the extension receives
   `{ namespace }` alone.

#### Per-namespace index partitioning

> **Extension behaviour.** This section describes the `@swamp/s3-datastore`
> extension's index design; none of it is implemented in this repo.

> **See also:** The [shard-first index](#shard-first-index) design extends
> partitioning beyond per-namespace to per-model shards covering all datastore
> subdirectories, eliminating the monolithic index entirely.

Extensions that advertise `namespacedSync: true` partition their remote index
per namespace:

- **Pull**: fetch `{namespace}/.datastore-index.json`, walk only keys under
  `{namespace}/`.
- **Push**: upload only files under `{namespace}/`, write
  `{namespace}/.datastore-index.json`.
- **Solo mode** (no namespace): use the global `.datastore-index.json` and
  walk all keys — identical to pre-namespace behavior.

The zero-diff fast path (sidecar fingerprint + dirty flag) operates
per-namespace: the sidecar caches the ETag of the namespace's index, not the
global index. A repo that hasn't written anything skips sync in O(1)
regardless of how much data other namespaces contain.

Push must never delete keys outside the namespace prefix. A namespace-scoped
push uploads files under `{namespace}/` and updates only that namespace's
index. Keys belonging to other namespaces are invisible to the walk and
untouched.

#### Namespace manifests

Each namespace writes a `.namespace.json` manifest to the datastore on
registration (`swamp datastore namespace set`):

```json
{
  "namespace": "infra",
  "repoId": "uuid-of-the-repo",
  "registeredAt": "2026-06-03T00:00:00.000Z"
}
```

The manifest lives at `{namespace}/.namespace.json` in the remote datastore
(for extension backends) or at `{datastorePath}/{namespace}/.namespace.json`
(for filesystem). It serves two purposes:

- **Conflict detection**: before registering a namespace, the system checks
  if a manifest already exists with a different `repoId`. If so, the
  registration fails with a clear error.
- **Discovery**: `swamp datastore namespace list` lists all registered
  namespaces by scanning for `.namespace.json` files
  (`src/cli/commands/datastore_namespaces.ts`,
  `src/libswamp/datastores/namespace_list.ts`).

For extension datastores, `DatastoreProvider.registerNamespace()` and
`DatastoreProvider.listNamespaces()` manage manifests via the remote API
(S3 PUT/GET, GCS equivalent). After writing to the remote, swamp core also
materializes the manifest into the local cache at
`{cachePath}/{namespace}/.namespace.json`. This ensures the extension's
`pushChanged()` orphan detection sees a local counterpart for the manifest
and does not delete the remote copy (swamp-club#834). For filesystem
datastores, the built-in `namespace_manifest.ts` utility reads and writes
manifest files directly. Both methods are optional on `DatastoreProvider` —
when the extension does not implement them, the CLI warns that conflict
detection is unavailable and proceeds with only the `.swamp.yaml` update.

### Two-Phase Sync

> **Next step:** The two-phase sync narrows the critical section to the index
> merge, but `commitPush` still reads/merges/writes the full monolithic index.
> The [shard-first index](#shard-first-index) design eliminates the monolithic
> index entirely — `commitPush` reads and writes only the touched per-model
> partition shard(s), making lock-hold time proportional to the write size, not
> the total index.

When an extension advertises `twoPhaseSync: true` in its capabilities, swamp
core splits the push into two phases to narrow the global-lock critical section:

```
Single-phase (default — pushChanged under global lock):

  acquire global lock
  pushChanged()          ← entire sync: index read + file upload + index write
  release global lock

Two-phase (twoPhaseSync: true):

  preparePush()          ← file uploads only, outside global lock
  acquire global lock
  commitPush(manifest)   ← index merge only, fast
  release global lock
```

This matters for workloads with many concurrent per-model writers in the same
namespace. Without two-phase sync, every writer acquires the global lock to
do a full push — serializing all concurrent writes behind the lock. With
two-phase sync, the expensive file I/O (`preparePush`) overlaps across
writers, and only the fast index merge (`commitPush`) serializes.

#### Extension contract

Extensions implement two optional methods on `DatastoreSyncService`:

- **`preparePush(options?)`** — Upload new/changed files to the remote.
  Return an opaque `PushManifest` describing what changed. Do NOT update the
  remote index. Do NOT clear the dirty flag (if `commitPush` fails, the dirty
  flag must remain set so the next push retries).

- **`commitPush(manifest, options?)`** — Read the **current** remote index
  (not a cached copy — another writer may have committed between
  `preparePush` and `commitPush`). **Merge** the manifest entries into the
  index — never replace the entire index. Write the updated index back. Clear
  the dirty flag only after the index write succeeds.

The manifest type (`PushManifest`) is opaque to core — core passes it through
from `preparePush` to `commitPush` without inspection. The extension defines
what goes inside.

#### Integrity guarantees

Core provides the integrity guarantees; extensions do not need to implement
their own concurrency control:

1. **Global lock on `commitPush`** — the index read-modify-write is always
   serialized. Two concurrent `commitPush` calls never overlap.
2. **Per-model locks across both phases** — held from before `preparePush`
   through after `commitPush`. Structural commands' symmetric drain waits
   for these locks, so a concurrent delete/GC cannot interfere.
3. **Additive merge** — since per-model locks guarantee non-overlapping file
   paths between concurrent writers, manifests from different writers never
   conflict. `commitPush` merges into whatever the current index contains.
4. **Catalog export before upload** — `.catalog-export.json` is written
   before `preparePush` so it is included in the file upload phase. The
   export is a full snapshot of the local catalog, so concurrent writers
   that overwrite it produce a correct (more complete) result. This avoids
   a gap where the export is dirty but never uploaded.

#### Fallback

Extensions that do not advertise `twoPhaseSync` (or do not implement
`preparePush`/`commitPush`) continue to use the single-phase
`pushChanged`-under-global-lock path — zero regression.

### Shard-First Index

> **Extension behaviour.** This section describes the `@swamp/s3-datastore`
> extension's index design and is not implemented in this repo. Core's only
> part is the optional `migrateMonolithToShards?()` method on
> `DatastoreSyncService`, its `MigrateIndexResult`, and the
> `swamp datastore migrate-index` command that calls it.

The two-phase sync narrows the critical section to the index merge in
`commitPush`, but `commitPush` still reads, parses, merges, and rewrites the
full monolithic `.datastore-index.json` under the lock. On a high-churn
namespace with a large index this can take long enough that few concurrent
writers fit within the 60-second lock timeout.

The shard-first index design eliminates the monolithic index as the source of
truth during `commitPush`. Instead, the index is partitioned into per-model
shard files under `_index/`, and `commitPush` reads and writes only the touched
shard(s). Lock-hold time becomes proportional to the write size (typically KB),
not the total index size (potentially hundreds of MB).

#### Partition scheme

Every datastore subdirectory is assigned a partition key strategy:

| Subdirectory              | Partition key pattern                      | Granularity  |
|---------------------------|--------------------------------------------|--------------|
| `data/`                   | `data--{type}--{modelId}`                  | Per model    |
| `outputs/`                | `outputs--{type}--{modelId}`               | Per model    |
| `definitions-evaluated/`  | `definitions-evaluated--{type}--{modelId}` | Per model    |
| `workflows-evaluated/`    | `workflows-evaluated--{workflowId}`        | Per workflow |
| `workflow-runs/`          | `workflow-runs--{workflowId}`              | Per workflow |
| `auto-definitions/`       | `auto-definitions`                         | Single shard |
| `audit/`                  | `audit`                                    | Single shard |
| `telemetry/`              | `telemetry`                                | Single shard |
| `logs/`                   | `logs`                                     | Single shard |
| `files/`                  | `files`                                    | Single shard |

Model-scoped subdirectories (`data/`, `outputs/`, `definitions-evaluated/`)
partition per model. Low-cardinality subdirectories (`audit/`, `telemetry/`,
etc.) use a single shard each — they are small and rarely written concurrently.

Each shard is stored as `_index/{partitionKey}.json`. A `_meta.json` file
tracks all partition keys and a monotonic `commitSeq` counter:

```json
{
  "version": 2,
  "partitions": ["data--mytype--abc123", "outputs--mytype--abc123", "audit"],
  "commitSeq": 42,
  "lastCompacted": "2026-07-01T12:00:00.000Z"
}
```

- `version: 2` distinguishes shard-first from the earlier `version: 1`
  (dual-write) format. Readers seeing `version: 1` know the monolith is still
  authoritative.
- `commitSeq` is bumped on every `commitPush`, replacing the monolith ETag as
  the zero-diff fast path fingerprint.

#### Push path (`commitPush`)

Under the global lock:

1. Read `_meta.json` to get the current partition list and `commitSeq`.
2. Read only the shard(s) touched by the manifest entries.
3. Merge the manifest entries into those shard(s).
4. Write the updated shard(s) back.
5. If new partition keys were introduced (new model, new workflow), append them
   to `_meta.json`.
6. Bump `commitSeq` and write `_meta.json`.
7. Clear the dirty flag.

`preparePush` is unchanged — it uploads files outside the lock and returns an
opaque manifest containing the affected relative paths, from which `commitPush`
derives partition keys.

#### Pull path

**Scoped pull** (`pullChanged` with `context.models`): read the relevant model
shard(s) from `_index/`. No monolith fallback needed when `_meta.json` version
is 2.

**Unscoped pull** (`pullChanged` without context): read `_meta.json` to discover
all partition keys, then fetch all shards in parallel. Merge into the in-memory
index. This replaces the single monolith GET with N parallel GETs — on S3/GCS
this is typically faster because parallelism beats single-large-object latency.

#### Shard cleanup

When deletions empty a shard (all entries removed), the shard file is deleted
from `_index/` and its key is removed from the `_meta.json` partitions list.
This prevents unbounded growth of orphaned shard files after model deletion.

#### Zero-diff fast path

The sidecar caches `commitSeq`. On the next sync, the extension reads
`_meta.json` and compares `commitSeq`. If unchanged, skip — no per-entry work.
If changed, fetch the relevant shard(s).

#### Migration

Migration from monolithic to shard-first is an explicit one-time operation, not
auto-triggered during normal writes. This avoids a race where multiple
concurrent writers all independently read a large monolith and write redundant
shards on a freshly upgraded extension.

The migration is triggered via the CLI:

```
swamp datastore migrate-index
```

The command acquires the distributed lock and calls
`migrateMonolithToShards()` on the active sync service, which:

1. Reads the existing `.datastore-index.json`.
2. Partitions all entries into shards using the partition key scheme above.
3. Writes all shard files to `_index/`.
4. Writes `_meta.json` with `version: 2` and `commitSeq: 1`.

This runs under the lock (it is a structural command) so there is no
concurrent-migration race. It is idempotent — running it again produces the
same result. If the monolithic index is empty, the command recovers by listing
existing shard files in `_index/` and rebuilding `_meta.json`.

The command handles several edge cases:

- **Filesystem datastore** — reports that index migration is only available for
  sync-capable custom datastores.
- **Extension without migration support** — advises updating the datastore
  extension to a version that supports shard-first indexing.
- **Empty datastore** — recovers from `_index/` listing if shards already exist.

**Pre-migration behavior:** When `_meta.json` is missing or `version: 1`,
`commitPush` and `pullChanged` fall back to the monolithic path — identical to
pre-shard-first behavior. An info-level log hints that migration is available
via `swamp datastore migrate-index`. This means upgrading the extension alone
causes zero regression.

#### Backward compatibility

**Phase 1 (initial release):** `commitPush` writes shards as the source of
truth and also dual-writes the monolith as a derived artifact. Old extension
versions continue to read the monolith. New versions read shards.

**Phase 2 (future major version):** Stop writing the monolith. Old extension
versions must upgrade.

**Old writers:** If an old extension version writes the monolith but not shards,
shard-first readers fall back to the monolith when `_meta.json` is missing or
`version: 1`. This fallback is permanent, not just a migration path.

#### Namespace interaction

In namespaced mode, the shard path is `{namespace}/_index/`. The partition
scheme is unchanged — the namespace prefix is applied by existing path
resolution logic. `_meta.json` and all shards are per-namespace.

#### Recovery

If `_meta.json` is missing or corrupted, the extension lists the `_index/`
prefix via `ListObjectsV2` to discover all shard files and rebuilds `_meta.json`
automatically. This is a self-healing path — no operator intervention required.

If an individual shard is missing or corrupted, the extension falls back to the
monolith for that shard's entries (if the monolith exists). If no monolith, the
shard is rebuilt by listing objects under the shard's path prefix.

### Zero-Diff Fast Path (Extension Guidance)

At production scale, most sync invocations are "nothing to do" — the local
cache already matches the remote index. Sync implementations that walk every
index entry unconditionally become O(n) in wall time on invocations that
should be O(1). Extension authors implementing `DatastoreSyncService` SHOULD
provide a zero-diff fast path that returns `0` without per-entry work when it
can prove the cache and remote are in sync.

The recommended pattern is a **fingerprint + local-dirty watermark** stored
in a small sidecar file under the cache directory:

- **Remote fingerprint** — a cheap, backend-native change token for the remote
  index. S3 uses the object ETag; GCS uses the `generation` number; any
  monotonic identifier exposed by a metadata-only request (HEAD-equivalent,
  not the full index body) works. Cache the last-observed fingerprint on disk.
- **Local-dirty flag** — flipped `true` by every code path that writes to the
  cache (e.g. the extension's `pushFile`-equivalent); cleared only after a
  successful writeback or a verified zero-diff pull. Default must be `true`
  on missing/corrupt sidecar so the slow path runs.

On `pullChanged` and `pushChanged`, the fast path issues one metadata request
against the remote index. If the returned fingerprint matches the sidecar and
the local-dirty flag is `false`, return `0` immediately. On any mismatch,
corruption, or uncertainty, fall through to the full walk — the fast path
must never skip real work.

The sidecar is client-local state. It is never uploaded, is excluded from the
sync walker, and can always be deleted to force a full re-verification.

#### `markDirty()` contract

Swamp core writes into the cache directly — the persistence repositories
(`FileSystemUnifiedDataRepository`, `YamlOutputRepository`,
`YamlWorkflowRunRepository`, `YamlEvaluatedDefinitionRepository`) call
`atomicWriteFile` / `atomicWriteTextFile` / `Deno.remove` against paths that
the sync service walks. These writes bypass the extension's own write path, so
the fast path's local-dirty flag would stay `false` and the next `pushChanged`
would short-circuit past real work.

The `markDirty()` method on `DatastoreSyncService` is the contract that closes
this gap. The signature accepts an options bag with an optional `relPath` so
extensions tracking per-path dirty state can record exactly which path
changed instead of only flipping a single global bit:

```typescript
markDirty(options?: DatastoreSyncOptions): Promise<void>;

interface DatastoreSyncOptions {
  signal?: AbortSignal;
  /** Cache-relative path of the file about to be written or removed. */
  relPath?: string;
  /** Domain-level sync context, passed when the extension advertises scopedSync. */
  context?: SyncContext;
  /** Namespace whose data subtree this sync operation targets (Phase 6). */
  namespace?: string;
  /** When true, pull downloads only metadata files (lazy hydration). */
  metadataOnly?: boolean;
  /** Restrict the sync to these datastore subdirectories. */
  subdirs?: readonly string[];
}
```

The contract is eight load-bearing rules:

1. **Pre-write timing.** `markDirty` fires *before* the cache write begins.
   Extensions MUST NOT act synchronously on `relPath` — the file isn't on
   disk yet. Treat `relPath` as a hint to record for the next `pushChanged`.
2. **Absence-on-disk = delete.** When `pushChanged` later consumes a
   recorded `relPath` and the file no longer exists in the cache, the
   extension SHOULD delete the corresponding remote record. This collapses
   create/update/delete into one signal — no separate op-kind needed.
3. **`undefined` `relPath` = bulk.** A call without `relPath` signals a
   mutation core couldn't attribute to a single path (`rename`,
   `deleteAllByWorkflowId`, `clearAll`).
   Extensions maintaining a per-path dirty set MUST honor this by either
   invalidating the set or flagging the next `pushChanged` for a full
   walk.
4. **Process restart loses the set.** Extensions holding the dirty set in
   memory MUST fall back to a full walk on the first `pushChanged` after
   process start. Persisting the set to a sidecar is allowed but optional.
5. **`relPath` is cache-relative + forward-slash.** Relative to the
   directory returned by `DatastoreProvider.resolveCachePath`, with
   forward-slash separators on the wire regardless of host OS — matching
   the `.datastore-index.json` key convention. **Extensions consuming
   `relPath` for disk access on Windows MUST convert to native separators**
   (e.g. via `@std/path` `join`) before `Deno.stat`/`Deno.readFile`/etc.
6. **Backward compatibility.** `relPath` is optional. Existing
   implementations (`@swamp/s3-datastore`, `@swamp/gcs-datastore`,
   filesystem no-op, every test mock) keep working unchanged because the
   old single-watermark pattern still satisfies the contract — any
   `markDirty` call still flips the dirty flag.
7. **Field scope.** swamp core only sets `relPath` on `markDirty` calls.
   The field has no defined meaning on `pullChanged` or `pushChanged`
   (it lives on the shared `DatastoreSyncOptions` for source
   compatibility, not because pull/push consume it).
8. **Bulk overrides per-path within one operation.** Some core mutations
   emit a bulk signal AND one or more per-path signals from the same
   logical operation — `rename` is the canonical example: the upfront
   `markDirty()` call has no `relPath` (bulk, for the tombstone +
   latest-marker writes that don't decompose), and the inner `save()` of
   the new name then emits a per-path signal. Extensions MUST treat any
   bulk signal as overriding per-path signals from the same operation.
   Easiest implementation: keep both a `bulkInvalidated: boolean` flag
   and the dirty set; in `pushChanged`, fall back to a full walk when
   `bulkInvalidated` is true regardless of the set's contents.

**Core obligation.** Repositories writing into the cache call the dirty
hook at the start of every public mutation method (`save`, `append`,
`delete`, `rename`, `allocateVersion`, `finalizeVersion`,
`removeLatestMarker`, non-dry-run `collectGarbage`, and the equivalents
on the three yaml repositories). The call happens **before** any write
begins so a crash mid-write leaves the watermark dirty —
markDirty-then-slow-walk is always recoverable; a lost dirty-flip is not.

**Per-call granularity emitted by core.**

| Method                                     | `relPath`                                                       |
| ------------------------------------------ | --------------------------------------------------------------- |
| `save`, `append`, `allocateVersion`        | data-name directory (version not yet allocated at notify time)  |
| `removeLatestMarker`                       | data-name directory                                              |
| `delete(version=specific)`                 | version directory                                                |
| `delete(version=undefined)`                | data-name directory (entire subtree removed)                     |
| `finalizeVersion`, `finalizeVersionDeferred` | version directory (version known)                              |
| `saveDeferred`                             | data-name directory                                              |
| `rename`                                   | `undefined` (bulk; inner `save()` emits its own per-path signal) |
| `collectGarbage` (non-dry-run)             | one signal per removed version directory, or the data-name directory when the whole name goes |
| `pruneExcessVersions` (write-time cap)     | one signal per removed version directory                         |
| Yaml repos: `save`, `delete`, `deleteOlderThan` | per-yaml file path                                          |
| `deleteAllByWorkflowId`, `clearAll`        | `undefined` (bulk)                                               |

`advanceLatestMarkers` and `rollbackVersions` emit nothing — they rely on the
signal their `saveDeferred` / `finalizeVersionDeferred` already sent
(`src/infrastructure/persistence/unified_data_repository.ts`).

Filesystem datastores have no fast path and wire no sync service, so the
markDirty plumbing is a no-op for them.

**Sync is not a content-integrity tool.** The fingerprint detects index-level
changes, not per-file corruption — a silently damaged cache file (bit rot,
truncated write after a crash) can slip through the fast path if the index
itself has not changed. Cache integrity is the verifier's job; use
`DatastoreVerifier.verify()` when integrity needs to be re-established, or
`rm -rf` the cache and re-pull.

### Foreign Catalog Export/Pull (Phase 6)

In a giga-swamp, each namespace publishes a `.catalog-export.json` after each
push — a flat JSON array of catalog rows for that namespace. Foreign catalog
pull fetches these exports from other namespaces and upserts into the local
catalog.

**Interface methods** (optional on `DatastoreSyncService`):

```typescript
exportCatalog?(namespace: string): Promise<void>;
pullForeignCatalogs?(namespaces: readonly string[]): Promise<CatalogExportEntry[]>;
fetchForeignContent?(namespace: string, relPath: string): Promise<Uint8Array | null>;
```

- `exportCatalog` — writes `{namespace}/.catalog-export.json` to the remote
- `pullForeignCatalogs` — fetches exports from named namespaces, returns rows
- `fetchForeignContent` — downloads a single file from a foreign namespace

**Catalog backfill** uses `bulkUpsert(rows)` (INSERT OR REPLACE) to additively
merge the on-disk walk into the catalog, preserving rows the walk cannot see
(e.g. lazily-hydrated remote data). Foreign rows are upserted via
`bulkUpsertForeign` which records a `foreign_synced:{namespace}` timestamp in
`catalog_meta`.

**On-demand content fetch** (Phase 6d): when a cross-namespace CEL expression
accesses `attributes` and the content is not locally available, the
`DataQueryService` calls `fetchForeignContent` through its `ForeignContentFetcher`
callback. Fetched content is cached in-memory for the command duration, not
persisted. Missing content or errors leave attributes empty (graceful
degradation).

**CLI**: `swamp datastore catalog pull --namespaces infra,security` pulls
foreign catalog metadata from the specified namespaces.

### Lazy Hydration

When `hydrationStrategy: "lazy"` is configured on a custom datastore, the
initial pull downloads only metadata files (`metadata.yaml`, `latest` markers,
partition indexes) and skips content files (`raw`) under `data/`. This gives
full catalog visibility — `data list`, `data query`, and CEL expressions all
work immediately — while deferring the expensive content download until the data
is actually needed.

#### How it works

1. **Setup/initial pull**: The extension's `pullChanged` filters files by
   suffix. Files ending in `/metadata.yaml` or `/latest` under `data/` are
   downloaded. Files ending in `/raw` under `data/` are skipped, but their
   parent directories are created so the catalog backfill walker (which uses
   `readdir`) finds the version directories. Files outside `data/` (outputs,
   workflow-runs, definitions-evaluated) are downloaded fully — they have no
   metadata/raw split.

2. **Model runs / workflow runs**: `acquireModelLocks` performs a scoped pull via
   `pullChanged({ context })`. The pull reads the partition file, compares
   against local files, sees `raw` is missing, and downloads it. No new code
   needed — the existing Phase 2 scoped sync handles this.

3. **`data get` (read-only, no sync)**: `UnifiedDataRepository.getContent()`
   attempts to read the `raw` file. If missing and a `HydrateFileHook` is
   wired, it calls the hook to download just that file from the remote, then
   retries the read.

#### `HydrateFileHook` contract

`HydrateFileHook` mirrors `MarkDirtyHook` — a thin callback injected into
repositories so they do not need a handle on the full sync service.
Repositories pass an absolute path; the composition root in `repo_context.ts`
wraps `DatastoreSyncService.hydrateFile` with path normalization
(absolute → cache-relative, forward-slash-normalized). Same contract as
`MarkDirtyHook` — repositories never convert paths themselves.

- Wired in `requireInitializedRepo`, `requireInitializedRepoUnlocked`, and
  `requireInitializedRepoReadOnly` (the read-only variant creates a lightweight
  sync service without a lock, solely for single-file downloads).
- Returns `true` if the file was downloaded, `false` if it does not exist on the
  remote.
- Implementations MUST write atomically (tmp + rename) to avoid partial reads
  from concurrent consumers.

#### `getContentSync` limitation

`getContentSync()` is synchronous and cannot call the async `HydrateFileHook`.
Its callers are:

- `data_record_mapper.ts` — query predicate attribute/content loading during
  `data query '<predicate>'` evaluation.
- `data_query_service.ts` — the stale-row check in `getLatestRecord()`.
- `model_resolver.ts` — CEL expression resolution during model runs.
- The composite and in-memory repositories, which delegate to it.

The `model_resolver.ts` path is safe: model runs go through `acquireModelLocks`
→ scoped pull, which downloads `raw` files before CEL evaluation begins.

The `data_record_mapper.ts` path means `data query` predicates referencing
`attributes` or `content` on un-hydrated data will see `null` values. This is a
documented limitation of lazy hydration — queries that filter only on metadata
fields (tags, version, owner, etc.) work correctly.

#### Configuration

- `CustomDatastoreConfig.hydrationStrategy` — `"full"` (default) or `"lazy"`.
- `SyncCapabilities.lazyHydration` — advertised by extensions that support
  selective pull and single-file hydration.
- `DatastoreSyncService.hydrateFile` — optional method; extensions without lazy
  hydration do not implement it. Core wires the `HydrateFileHook` only when
  `hydrationStrategy === "lazy"` **and** the service implements `hydrateFile`
  (`src/cli/repo_context.ts`).

### Index

> **Extension behaviour.** This and the next three sections describe the
> `@swamp/s3-datastore` extension; none of it is implemented in this repo.

A metadata index (`.datastore-index.json`) tracks all files in the S3 bucket.
It is a JSON manifest mapping relative paths to their size and last-modified
timestamp. The index is fetched once per command, with a short local cache TTL
to avoid redundant fetches during rapid command sequences.

### Change Detection

> **Extension behaviour** (`@swamp/s3-datastore`), not implemented in this repo.

Changes are detected by comparing `stat.size` and `stat.mtime`:

- **Pull**: files in the remote index that are missing locally or have a
  different size are downloaded.
- **Push**: files in the local cache that are new or have a different
  size/mtime compared to the index are uploaded.

No content hashing is used. The write paths (`atomicWriteTextFile`,
`Deno.writeFile`) always update mtime, so mtime changes reliably detect
rewrites even when the file size doesn't change.

### Transfer Concurrency

> **Extension behaviour** (`@swamp/s3-datastore`), not implemented in this repo.

All pull and push operations download/upload files concurrently in bounded
batches. This reduces wall-clock time for syncs with many files by overlapping
S3 round trips. The concurrency limit prevents overwhelming the network or
hitting S3 request rate limits.

### Offline Behavior

> **Extension behaviour** (`@swamp/s3-datastore`), not implemented in this repo.
> Core's own contribution is the sync timeout above and the diagnostics in
> `src/infrastructure/persistence/sync_error_diagnostic.ts`.

If S3 is unreachable, pull and push warn and continue. The command runs against
the local cache. Data is pushed on the next successful connection.

## Concurrency Control

Both backends use a distributed lock to prevent concurrent write access. The
lock is acquired by write commands at command start and released at command end
(on both success and error paths). Read-only commands
(`requireInitializedRepoReadOnly`) bypass the lock entirely, allowing concurrent
reads alongside writes. This is safe because all file writes use atomic
write-to-temp-then-rename (`atomicWriteTextFile`), so reads never see
partial/corrupt files.

### DistributedLock Interface

```typescript
interface DistributedLock {
  acquire(): Promise<void>;   // Acquire lock, start heartbeat
  release(): Promise<void>;   // Release lock, stop heartbeat
  withLock<T>(fn: () => Promise<T>): Promise<T>;
  inspect(): Promise<LockInfo | null>;  // Read without acquiring
  forceRelease(expectedNonce: string): Promise<boolean>;  // Breakglass delete
}
```

`forceRelease` re-verifies the lock's nonce immediately before deleting and
returns `false` if the holder has changed, narrowing the TOCTOU window to
the gap between that final read and the delete itself. It is the
breakglass primitive used by `swamp datastore lock release --force` and
by `acquireModelLocks` to clean up stale global locks observed during
per-model lock acquisition (see "Lock Lifecycle" below).

Lock metadata (`LockInfo`) is stored as JSON:

```json
{
  "holder": "user@hostname",
  "hostname": "hostname",
  "pid": 12345,
  "acquiredAt": "2026-03-10T12:00:00.000Z",
  "ttlMs": 30000,
  "nonce": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}
```

### Extension Locks

> **Extension behaviour.** The S3 mechanism below is the
> `@swamp/s3-datastore` extension's design, not implemented in this repo.

Extension datastores provide their own `DistributedLock` implementation via the
`DatastoreProvider.createLock()` method. For example, the `@swamp/s3-datastore`
extension uses S3 conditional writes (`PutObject` with `If-None-Match: *`) for
atomic lock acquisition with background heartbeat.

### FileLock

Uses advisory lockfiles (`Deno.open({ createNew: true })`) for atomic
check-and-create. The lockfile is at `{datastorePath}/.datastore.lock` in solo
mode. A background heartbeat rewrites the lockfile content with a fresh
timestamp. Stale locks (where `acquiredAt + ttlMs < now`) are removed and
retried.

When a `namespace` is configured, `datastoreGlobalLockOptions` returns
`{ lockKey: ".datastore.lock", namespace }`. Both `FileLock` and remote lock
providers (S3, GCS) prefix the lock key under `{namespace}/`, placing it at
`{datastorePath}/{namespace}/.datastore.lock`. Two repos writing to different
namespaces of a shared datastore never contend on structural commands, and the
lock key stays within the namespace prefix so IAM credentials scoped to the
prefix can access it. This is a lock-**path** change only — the lifecycle
protocol below is unchanged. Per-model lock keys are namespaced:
`{namespace}/data/{type}/{modelId}/.lock` when a namespace is set,
`data/{type}/{modelId}/.lock` otherwise. The `modelLockKey()` helper in
`lock.ts` constructs the key; `createModelLock` and `acquireModelLocks` read
`config.namespace` to thread it through. `parseModelLockKey` is unchanged —
callers use `stripNamespacePrefix()` to strip the namespace from
filesystem-relative paths before parsing.

### Lock Timeout and Retry Behavior

The default lock acquisition timeout is **60 seconds** (`DEFAULT_LOCK_TIMEOUT_MS`).
This is sufficient for most workloads because per-step locking gives each model
method step a fresh timeout budget.

The timeout can be overridden via the `SWAMP_LOCK_TIMEOUT_MS` environment
variable (`LOCK_TIMEOUT_ENV_VAR` in `datastore_config.ts`). Resolution order
(first positive value wins):

1. Per-invocation override (internal; no CLI flag currently exposes this)
2. `SWAMP_LOCK_TIMEOUT_MS` env var (must parse as a positive integer)
3. `DEFAULT_LOCK_TIMEOUT_MS` (60,000 ms)

Invalid env values (non-numeric, zero, negative) are silently ignored.

The resolved timeout is threaded into every lock creation site: per-model
locks (`createModelLock`), global datastore locks (`createDatastoreLock`),
and inline lock constructions in `requireInitializedRepo` and flush paths.
Custom datastore providers receive `maxWaitMs` in `LockOptions` — whether
they honor it depends on their implementation.

**Retry backoff.** `FileLock.acquire` uses jittered exponential backoff:
starting at `retryIntervalMs` (default 1 second), doubling each attempt,
capped at 8 seconds, with ±25% random jitter. Each sleep is also clamped to
the remaining timeout budget so the loop never overshoots `maxWaitMs`.

**Contention logging.** When a lock is acquired after one or more retries,
an info-level log line reports the retry count and total wait time:

```
INF datastore·lock Acquired lock "/abs/path/to/datastore/.datastore.lock" after 3 retries (4521ms)
```

The path is the absolute `lockPath` (`file_lock.ts`).

### Lock Lifecycle

The sync coordinator (`datastore_sync_coordinator.ts`) manages the lock
lifecycle as a global singleton:

- `registerDatastoreSync({ service?, lock?, label?, syncTimeoutMs?,
  metadataOnly?, namespace? })` — acquire lock, pull if S3
- `flushDatastoreSync()` — push if S3, release lock

Per-model commands (`model method run`) acquire only per-model locks via
`acquireModelLocks`; they do not acquire the global lock but do `inspect()`
it to wait out any in-flight structural command. The `inspect()` must
target the **same** namespaced global-lock key the structural command
acquires (`datastoreGlobalLockOptions`); otherwise the drain coordination
would inspect a different lock than the one held and silently become a
no-op in namespaced mode. When a stale global lock is observed during this
wait, `acquireModelLocks` calls `forceRelease(expectedNonce)` to clear
it — without this, the post-acquire TOCTOU re-check would re-detect the
same stale lock on every iteration and recurse indefinitely.

Workflow commands (`workflow run`, `workflow resume`) and serve-hosted
workflow execution do **not** acquire locks upfront. Instead, per-model
locks are acquired per-step via a `StepLockHook` callback injected into
the workflow execution engine. Each model method step acquires its own
per-model lock before execution and releases it in a finally block after
the method completes. This per-step locking prevents deadlocks when a
model method spawns a subprocess `swamp model method run` targeting a
model that would otherwise be locked by the parent workflow. Parallel
workflow steps on different models lock independently; parallel steps on
the same model serialize at the lock (correct — concurrent writes to the
same model are unsafe). The coordinator uses unique keys per lock
acquisition (suffixed with a random ID) so parallel steps on the same
model get separate entries and do not overwrite each other.

Per-model lock keys are namespace-scoped, so `waitForPerModelLocks` uses
`stripNamespacePrefix` to match locks under the repo's namespace. The walk
still starts from the datastore root, so locks from other namespaces are
visible but filtered out by the prefix check — only the current namespace's
per-model locks are drained.

#### Symmetric Drain (structural commands)

Structural commands (`requireInitializedRepo`) acquire the global lock with
a **symmetric drain** — `waitForPerModelLocks` is invoked twice, once
before the global lock is acquired and once after:

1. **First drain (pre-acquire).** Wait for any per-model locks visible at
   command start to be released. A writer that is already past its own
   TOCTOU recheck (in `acquireModelLocks`) is committed to writing data
   and must be allowed to finish.
2. **Acquire global lock.** From this point on, any writer that runs
   `inspect()` against the global lock will see it held and back off.
3. **Second drain (post-acquire).** Wait for any per-model locks that
   slipped past the first drain — i.e., writers that inspected the global
   lock between the first drain ending and the global-lock acquisition,
   saw it not held, and went on to acquire a per-model lock.

The second drain is what closes the symmetric TOCTOU window between the
two sides of the protocol. Without it, a writer can:

1. Inspect global → not held (deleter has not yet acquired)
2. Take per-model lock
3. Pass its TOCTOU recheck → not held (deleter still has not acquired)
4. Begin writing a new version directory

…while the deleter completes its first drain, acquires the global lock,
and runs `Deno.remove(dataNameDir, { recursive: true })`. The recursive
removal then races the writer's new version subdirectory and fails with
ENOTEMPTY (Linux: `os error 39`, macOS: `os error 66`) — the failure mode
behind swamp-club#234.

The second drain catches the writer's still-held per-model lock and waits
for the writer to finish (and either commit cleanly or release on its own
TOCTOU recheck) before structural work proceeds. Because the writer's
recheck runs *immediately* after taking the per-model lock — before any
data I/O — there is no remaining window where the writer can write data
without the deleter's second drain seeing the per-model lock.

> **Maintainer note.** Both drain calls are required to keep this
> contract sound. The bidirectional citation
> (`src/cli/repo_context.ts:requireInitializedRepo` ↔ this section) is
> there so a future change cannot silently remove one of the two waits
> without confronting the contract. When changing this lifecycle, update
> both sites.

Caveat: `waitForPerModelLocks` only scans the local filesystem. Custom
(S3, distributed) datastores use their own `DistributedLock`
implementation and rely on its semantics rather than the local drain.

#### Parent-Process Lock Awareness

When `acquireModelLocks` acquires per-model locks it sets the environment
variable `SWAMP_LOCK_HOLDER_PID` to the current process PID.
`waitForPerModelLocks` reads this variable and skips any lock file whose
`pid` field matches — those locks are held by the parent process, so
waiting for them would deadlock (the parent is blocked on the child, and
the child is blocked on the parent's locks).

This arises when a workflow shell step spawns a nested `swamp` command
(e.g. `swamp extension push`). The child inherits the env var and avoids
polling on its parent's locks. The env var is cleared when the parent
flushes its locks.

A SIGINT handler ensures best-effort lock release on Ctrl-C. If the process
crashes without releasing, the lock expires after the TTL (30 seconds by
default).

### Lock Breakglass

Two CLI commands for inspecting and force-releasing stuck locks:

```bash
swamp datastore lock status                          # Show who holds the lock
swamp datastore lock release --force                 # Delete the global lock directly
swamp datastore lock release --force --model type/id # Release one per-model lock
```

The `--force` flag is required. The release command bypasses `acquire()`/
`release()` and directly deletes the lock, which is necessary when a crashed
process left a lock that hasn't expired yet.

### Other maintenance commands

- `swamp datastore type search` — search the registry for datastore extension
  types (`src/cli/commands/datastore_type_search.ts`).
- `swamp datastore compact` — checkpoint the WAL and vacuum `_catalog.db`
  (`datastore_compact.ts`).
- `swamp datastore config migrate` — copy definitions, vault configs, the
  extension lockfile and pulled extensions into the datastore `config/` tier
  and set `managedConfig: true`; once the sentinel exists,
  `resolveManagedConfigPaths` (`src/cli/repo_context.ts`) points the
  pulled-extensions root and lockfile at `.swamp/config/`
  (`datastore_config_migrate.ts`).
- `swamp doctor datastores [--repair [-y]]` — health check plus optional
  repair of catalog completeness, root-level unmigrated data and foreign
  namespace contamination, the last via the optional
  `repairNamespaceContamination?()` on `DatastoreSyncService`
  (`src/cli/commands/doctor_datastores.ts`).

## Setup and Migration

### Initial Setup

`swamp repo init` creates a default filesystem datastore at `.swamp/`. To use
a different backend, run `swamp datastore setup` after init:

```bash
swamp datastore setup filesystem --path /mnt/shared/swamp-data
swamp datastore setup extension @swamp/s3-datastore \
  --config '{"bucket":"my-bucket","prefix":"my-project","region":"us-east-1"}'
```

Each setup command (`src/libswamp/datastores/setup.ts`):
1. Verifies the target is accessible (writable directory or reachable S3 bucket)
2. Migrates existing runtime data from `.swamp/` to the new location
   (skipped when `--skip-migration` is used)
3. Pushes migrated data to the remote (extension datastores; skipped when
   `--skip-migration` is used or when there is nothing to push)
4. **Hydrates** the local cache from the remote datastore (extension
   datastores only) — runs unconditionally, regardless of `--skip-migration`
5. Persists and cleans up — the order differs by backend:
   - **extension**: cleans up migrated directories from `.swamp/` (only when
     no step reported an error), then updates `.swamp.yaml` (when there were
     no errors, or only timeouts — see below), then registers the namespace
     manifest via `provider.registerNamespace` when `--namespace` was given
   - **filesystem**: updates `.swamp.yaml`, then cleans up migrated
     directories, so a crash between the two leaves harmless orphaned source
     data rather than a repo pointing at a cleaned-up datastore

`setup extension` also takes `--namespace <slug>` and
`--hydration-strategy full|lazy`, both persisted into the datastore block.

`--skip-migration` controls only step 2 (the local→remote push of existing
`.swamp/` data). It does NOT skip step 4 (hydration). A contributor joining a
shared datastore that already has data needs hydration even when there is
nothing local to migrate; without it the local cache stays empty and reads
return nothing until a manual `swamp datastore sync --pull` runs.

**Hydration invariant.** After `swamp datastore setup extension` succeeds
with no errors, the local cache contains every entry advertised by the
remote `.datastore-index.json` at setup time. Subsequent reads from
datastore-tier repositories see consistent data without an explicit
`swamp datastore sync --pull` first.

### Partial Failure and Retry

If `swamp datastore setup extension` fails partway through (network blip,
auth error, Ctrl-C, transient 5xx), the repo stays in a safe, resumable state:

- `.swamp.yaml` is **not updated** — the repo remains filesystem-typed — unless
  the only errors were sync timeouts, in which case the type **is** committed
  so the user can resume with `swamp datastore sync --push --timeout <big>`
  (see [Sync Timeout](#sync-timeout)).
- `.swamp/` data is **not cleaned up** — local data stays intact for retry.
- Objects already pushed to the remote are harmless — S3 PutObject is
  idempotent, so a subsequent push overwrites with identical content.

**To retry:** re-run the exact same `swamp datastore setup extension` command
(or, after a timeout-only failure, `swamp datastore sync --push`).

### Directory Relocation

When a datastore is enabled on a repo that previously used the default
filesystem layout, the runtime directories (`data`, `outputs`, `workflow-runs`,
and others listed in `DEFAULT_DATASTORE_SUBDIRS`) are relocated from
`{repoDir}/.swamp/` to the datastore path. For extension datastores this is the
local cache (`~/.swamp/repos/{repoId}/`), not the remote. The setup command
prints which directories moved and where:

```
Relocated: data, outputs, workflow-runs now resolve under /new/path
  Moved from: /repo/.swamp
```

After setup, `DefaultDatastorePathResolver.resolvePath()` routes these
subdirectories to the new location. Code that hardcodes `.swamp/workflow-runs/`
or similar paths will silently break — use `swamp workflow run search --json`,
`swamp data get`, or equivalent CLI commands instead of direct filesystem access.
The migration copies files to the cache (overwriting any partial cache from the
previous attempt), pushes to the remote (idempotent), pulls from the remote,
and only then cleans up `.swamp/` and updates `.swamp.yaml` (in that order for
extension datastores — see [Initial Setup](#initial-setup)).

The same applies to `swamp datastore setup filesystem` — the config update is
guarded behind a successful migration, so a partial copy leaves `.swamp.yaml`
unchanged and a retry is safe.

The CLI surfaces a retry hint in the output whenever setup completes with
errors, so the user knows re-running is safe without consulting documentation.

### Migrating Between Backends

Run `swamp datastore setup` again with the new backend type. The setup command
migrates data from the current location to the new one.

When switching **from a remote/sync-based datastore to filesystem**, the CLI
resolves the outgoing datastore's local cache path
(`~/.swamp/repos/{repoId}/`) and passes it to `datastoreSetupFilesystem` as
`outgoingCachePath`. The migration copies content from the cache — not from
`{repoDir}/.swamp`, which is empty for remote datastores. If the cache path
does not exist or cannot be resolved (e.g. the outgoing extension was
uninstalled), the setup falls back to `{repoDir}/.swamp` and logs a warning.

To ensure the cache is fully up to date before switching, run
`swamp datastore sync --pull` first.

### Health Verification

The per-command entry points do only a light accessibility check
(`src/cli/repo_context.ts`):

- **Filesystem**: `requireInitializedRepo()` and
  `requireInitializedRepoReadOnly()` `Deno.stat` the path and fail only if it
  exists but is not a directory; a missing directory is allowed (it is created
  on first write). Writability is not tested here.
- **Extension datastores**: the write path ensures the cache directory exists
  and creates the sync service; the read-only path does the same without a
  lock and without any health check. Neither calls `createVerifier()`.

Full health checks (`DatastoreVerifier.verify()` from `createVerifier()`, or
`filesystem_datastore_verifier.ts`) run in `swamp datastore status`,
`swamp datastore setup`, `swamp doctor datastores`, and at `swamp serve`
startup. `swamp datastore status` shows the current config, health, latency,
directories, and exclude patterns.

## Implementation Files

### Domain Layer

| File | Purpose |
|------|---------|
| `src/domain/datastore/datastore_config.ts` | `DatastoreConfig` union type, directory lists |
| `src/domain/datastore/datastore_path_resolver.ts` | `DatastorePathResolver` interface |
| `src/domain/datastore/datastore_pattern_matcher.ts` | Gitignore-style glob compiler |
| `src/domain/datastore/datastore_health.ts` | `DatastoreVerifier` interface |
| `src/domain/datastore/datastore_migration_service.ts` | File copy + verification for migration |
| `src/domain/datastore/distributed_lock.ts` | `DistributedLock` interface, `LockInfo`, `LockTimeoutError` |
| `src/domain/datastore/datastore_types.ts` | Datastore type name parsing/validation |
| `src/infrastructure/persistence/namespace_manifest.ts` | `.namespace.json` read/write for filesystem datastores |
| `src/infrastructure/persistence/sync_error_diagnostic.ts` | Classifies sync failures into user-facing summaries |
| `src/infrastructure/persistence/lockfile_repository.ts` | Extension lockfile persistence (local or managed-config tier) |
| `src/domain/extensions/bundle_freshness.ts` | Content-fingerprint bundle invalidation |

### Infrastructure Layer

| File | Purpose |
|------|---------|
| `src/infrastructure/persistence/default_datastore_path_resolver.ts` | Path resolver with compiled patterns |
| `src/infrastructure/persistence/filesystem_datastore_verifier.ts` | Filesystem health check |
| `src/infrastructure/persistence/datastore_sync_coordinator.ts` | Global sync lifecycle (lock + pull/push) |
| `src/infrastructure/persistence/file_lock.ts` | File-based distributed lock (advisory lockfile) |

### Application Layer (libswamp)

`src/libswamp/datastores/` holds one generator per command: `setup.ts`,
`status.ts`, `sync.ts`, `lock.ts`, `compact.ts`, `migrate_index.ts`,
`type_search.ts`, `namespace_set.ts`, `namespace_unset.ts`,
`namespace_migrate.ts`, `namespace_list.ts`, `doctor_datastores.ts`.

### CLI Layer

| File | Purpose |
|------|---------|
| `src/cli/resolve_datastore.ts` | Config resolution (env > CLI > yaml > default) |
| `src/cli/repo_context.ts` | Wires datastore into repo lifecycle, `createDatastoreLock()` factory |
| `src/cli/commands/datastore.ts` | `swamp datastore` command group |
| `src/cli/commands/datastore_status.ts` | `swamp datastore status` |
| `src/cli/commands/datastore_setup.ts` | `swamp datastore setup` (filesystem + extension) |
| `src/cli/commands/datastore_sync.ts` | `swamp datastore sync` (manual) |
| `src/cli/commands/datastore_lock.ts` | `swamp datastore lock` (status + release) |
| `src/cli/commands/datastore_namespace.ts` | `swamp datastore namespace set/unset/migrate` |
| `src/cli/commands/datastore_namespaces.ts` | `swamp datastore namespace list` |
| `src/cli/commands/datastore_catalog_pull.ts` | `swamp datastore catalog pull` |
| `src/cli/commands/datastore_compact.ts` | `swamp datastore compact` |
| `src/cli/commands/datastore_migrate_index.ts` | `swamp datastore migrate-index` |
| `src/cli/commands/datastore_type_search.ts` | `swamp datastore type search` |
| `src/cli/commands/datastore_config_migrate.ts` | `swamp datastore config migrate` |
| `src/cli/commands/doctor_datastores.ts` | `swamp doctor datastores` |
| `src/presentation/renderers/datastore_status.ts` | `swamp datastore status` rendering |
| `src/presentation/renderers/datastore_sync.ts` | `swamp datastore sync` rendering |
| `src/presentation/renderers/datastore_lock.ts` | `swamp datastore lock` rendering |
| `src/presentation/renderers/datastore_setup.ts` | `swamp datastore setup` rendering |
| `src/presentation/renderers/datastore_compact.ts` | `swamp datastore compact` rendering |
| `src/presentation/renderers/datastore_migrate_index.ts` | `swamp datastore migrate-index` rendering |
| `src/presentation/renderers/datastore_namespace_set.ts` | `swamp datastore namespace set` rendering |
| `src/presentation/renderers/datastore_namespace_unset.ts` | `swamp datastore namespace unset` rendering |
| `src/presentation/renderers/datastore_namespace_migrate.ts` | `swamp datastore namespace migrate` rendering |
| `src/presentation/renderers/datastore_namespace_list.ts` | `swamp datastore namespace list` rendering |
