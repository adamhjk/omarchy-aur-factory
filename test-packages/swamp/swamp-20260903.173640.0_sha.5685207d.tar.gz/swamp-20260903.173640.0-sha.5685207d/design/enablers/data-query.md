---
audience: maintainer, operator
enables: [data]
last-verified: 2026-08-28 @ 3d5955a9
---

# Data Query

Data query is the general interface for finding data artifacts across models
using CEL predicates. Queries filter on artifact metadata (model name, spec
name, tags, version, etc.) and optionally on JSON content.

The query interface is available in three places:

- **CLI** — `swamp data query '<predicate>'`
- **CEL expressions** — `data.query('<predicate>')` in definitions and workflows
- **Extension methods** — `context.queryData('<predicate>')` in model method
  implementations

All three accept the same CEL predicate syntax and operate on the same fields.

## Query is the primitive; helpers are shortcuts

Every `swamp data` read subcommand and every `data.*` CEL helper answers the
same question a `data query` predicate would, over the same `DataRecord`
fields — but not all of them walk the catalog. On the CLI only `data search`
and `data query` read `_catalog.db` (`src/cli/commands/data_search.ts`,
`src/infrastructure/persistence/catalog_search_adapter.ts`); `get`, `list` and
`versions` go through the filesystem repository
(`src/libswamp/data/{get,list,versions}.ts`). The shortcuts exist because
they read more clearly when your intent matches. **Prefer the shortcut when
it fits** — `data.latest("m", "n")` is easier to understand than the
equivalent predicate. Reach for `data query` / `data.query()` directly when
you need a multi-field predicate, a projection, tag filters beyond a single
key, or history access beyond a single version.

### CLI shortcuts

| Shortcut                              | Underlying query                                                                             |
| ------------------------------------- | -------------------------------------------------------------------------------------------- |
| `swamp data get <m> <n>`              | `swamp data query 'modelName == "<m>" && name == "<n>"' --select content`                    |
| `swamp data get <m> <n> --version 2`  | `swamp data query 'modelName == "<m>" && name == "<n>" && version == 2' --select content`   |
| `swamp data list <m>`                 | `swamp data query 'modelName == "<m>"'`                                                      |
| `swamp data list <m> --type resource` | `swamp data query 'modelName == "<m>" && dataType == "resource"'`                            |
| `swamp data list --workflow <w>`      | `swamp data query 'workflowName == "<w>"'`                                                   |
| `swamp data list --run <id>`          | `swamp data query 'workflowRunId == "<id>"'`                                                 |
| `swamp data versions <m> <n>`         | `swamp data query 'modelName == "<m>" && name == "<n>" && version >= 0' --select 'version'` |
| `swamp data search --tag env=prod`    | `swamp data query 'tags.env == "prod"'`                                                      |

### CEL shortcuts

| Shortcut                      | Underlying query                                                           |
| ----------------------------- | -------------------------------------------------------------------------- |
| `data.latest("m", "n")`       | `data.query('modelName == "m" && name == "n"')[0]`                         |
| `data.version("m", "n", 2)`   | `data.query('modelName == "m" && name == "n" && version == 2')[0]`         |
| `data.listVersions("m", "n")` | `data.query('modelName == "m" && name == "n" && version >= 0', 'version')` |
| `data.findByTag("k", "v")`    | `data.query('tags.k == "v"')`                                              |
| `data.findBySpec("m", "s")`   | `data.query('modelName == "m" && specName == "s"')`                        |

Results from any shortcut are structurally identical to the equivalent
`data.query()` call — same `DataRecord[]` type, same fields. The execution
path differs in three ways (`src/domain/expressions/model_resolver.ts`):

- `data.latest()` / `data.version()` without a `*:` wildcard resolve
  filesystem-first (`dataRepo.findByName` on the model's coordinates) and only
  fall back to the catalog when that misses.
- Every helper except `data.query()` injects `&& ns == "<own namespace>"`
  unless the model name carries a namespace prefix (`routeNamespace`).
- `data.findBySpec()` and `data.findByTag()` deduplicate to the newest record
  per `(modelName, name, stepName)` (`deduplicateByName`).

**specName ambiguity detection:** `data.latest()` throws a `UserError` when the
lookup argument matches a `specName` tag that is shared by multiple data items
under the same model. This fires only when the argument equals the specName —
callers who pass an exact data name that differs from the specName are not
affected, even when sibling items share the same spec. Use `data.findBySpec()`
to explicitly query by specName. The raw `data.query()` equivalent does not
perform this check.

### Null-safe access (.?)

`data.latest()` and `data.version()` return `null` when the named instance
doesn't exist. Use `.?` (optional select) to chain through a potentially null
result instead of throwing:

```cel
data.latest("m", "n").?attributes.?payload.?findings           // null if missing
data.latest("m", "n").?attributes.?findings.orValue([])        // [] if missing
data.latest("m", "n").attributes.findings                      // throws if missing
```

See [expressions.md](./expressions.md#null-safe-optional-access-) for details.

### Cross-namespace queries (giga-swamp Phase 4)

Model-name helpers (`data.latest`, `data.version`, `data.findBySpec`,
`data.listVersions`) support namespace-prefixed model names. `data.findByTag`
takes no model name and always searches the caller's own namespace
(`model_resolver.ts` `findByTag`):

| Syntax | Scope |
| --- | --- |
| `data.latest("model", "name")` | Own namespace only (default) |
| `data.latest("infra:model", "name")` | Target namespace `infra` |
| `data.latest("*:model", "name")` | All namespaces (errors if ambiguous) |

`data.query()` spans all namespaces by default — no implicit namespace filter
is injected. Use the `ns` field to filter explicitly:

| Query | Scope |
| --- | --- |
| `data.query('modelType == "aws/ec2/vpc"')` | All namespaces |
| `data.query('ns == "security"')` | Security namespace only |
| `data.query('ns == ""')` | Solo-mode data only |

The `ns` field name (not `namespace`) is used because `namespace` is a reserved
identifier in CEL.

## DataRecord

`data.query()` returns `DataRecord[]` — the same type returned by
`data.latest()`, `data.version()`, `data.findByTag()`, `data.findBySpec()`,
and `context.readModelData()`. As part of this work, `DataRecord` is extended
with metadata fields:

```typescript
interface DataRecord {
  id: string;
  name: string;
  version: number;
  isLatest: boolean;
  createdAt: string;
  // Provenance namespace (giga-swamp Phase 2). Identifies which repo produced
  // this data within a shared datastore. Empty string ('') in solo mode.
  namespace: string;
  attributes: Record<string, unknown>;
  tags: Record<string, string>;
  modelName: string;
  modelId: string;
  modelType: string;
  specName: string;
  dataType: string;
  contentType: string;
  lifetime: string;
  ownerType: string;
  streaming: boolean;
  size: number;
  content: unknown; // parsed object for JSON, text for other text types

  // Provenance fields — promoted from tags/ownerDefinition to first-class.
  // Empty string when the data was not produced inside a workflow.
  ownerRef: string;
  workflowRunId: string;
  workflowName: string;
  jobName: string;
  stepName: string;
  source: string;
}
```

All `DataRecord` fields are populated by standalone exported mapper functions
in `data_record_mapper.ts`: `fromRow()` for catalog-backed queries,
`fromData()` for version lookups, `fromResourceHandle()` for workflow step
resource outputs, and `fromFileHandle()` for file-kind outputs. This is
backward-compatible: existing code that reads `record.name` or
`record.attributes` continues to work; the provenance fields are additive.

For JSON resources (`contentType == "application/json"`), `attributes` contains
the parsed content — matching the existing behavior of `data.latest()` and
other accessors. For non-JSON data, `attributes` is `{}`.

Results from `data.query()` are interchangeable with results from any other
data accessor. CEL expressions that work on `data.latest()` results work
identically on `data.query()` results, and vice versa.

## Filter Context

The predicate is evaluated against each `DataRecord`. The full set of
filterable fields:

| Field | Type | Description |
| --- | --- | --- |
| `id` | string | Data artifact UUID |
| `name` | string | Data artifact name |
| `version` | int | Version number |
| `isLatest` | bool | Whether this is the latest version of the artifact |
| `createdAt` | string | ISO-8601 timestamp |
| `attributes` | map | Parsed JSON content (lazy-loaded; `{}` unless `contentType` is `application/json`) |
| `tags` | map | All tags as key-value pairs |
| `modelName` | string | Owning model name |
| `modelType` | string | Owning model type |
| `specName` | string | Output spec name |
| `dataType` | string | `"resource"` or `"file"` |
| `contentType` | string | MIME type |
| `lifetime` | string | Lifetime policy |
| `ownerType` | string | `"model-method"`, `"workflow-step"`, or `"manual"` |
| `streaming` | bool | Whether data is append-only |
| `size` | int | Content size in bytes |
| `content` | dyn | Parsed object for JSON, raw text for other text types (lazy-loaded) |
| `ownerRef` | string | Model definition ID that owns this data |
| `workflowRunId` | string | Workflow run ID (`""` outside workflows) |
| `workflowName` | string | Workflow name (`""` outside workflows) |
| `jobName` | string | Job name (`""` outside workflows) |
| `stepName` | string | Step name (`""` outside workflows) |
| `source` | string | Provenance source (e.g. `"step-output"`, `""`) |
| `ns` | string | Namespace slug (`""` in solo mode). Alias for `DataRecord.namespace` — CEL reserves `namespace` as an identifier |

All fields except `attributes` and `content` are metadata stored in the
catalog. `attributes` and `content` are loaded from disk on demand when the
predicate or select expression references them. `attributes` contains parsed
JSON (for `application/json` only). `content` is the raw text string for
`text/*`, `application/yaml` and `application/x-yaml`
(`src/domain/data/content_type.ts` `isTextContentType`); for
`application/json` it is the same parsed object as `attributes`
(`src/domain/data/data_record_mapper.ts` `parseContent`). For binary content
types, `content` is `""`.

## Provenance-Based Filtering

Data produced inside a workflow carries first-class provenance fields
(`workflowRunId`, `workflowName`, `stepName`, etc.). These fields are
queryable just like any other `DataRecord` field — no hidden scoping is
applied by the framework.

To scope results to a specific workflow run, write an explicit predicate:

```cel
modelName == "dedup" && specName == "episode" && workflowRunId == "run-uuid"
```

No data access function scopes by workflow run. Only `data.query()` and
`context.queryData()` are fully unscoped — the model-name helpers and
`context.readModelData()` add an own-namespace filter (see above), but nothing
else. The predicate string is the contract — if it doesn't say it, it isn't
happening.

**Step-aware versioning:** The `is_latest` flag follows asymmetric
demotion rules based on `step_name`:

- **Model-method writes** (`step_name = ""`) demote ALL prior latest rows
  for the same `(model, data)`, regardless of their `step_name`. A
  model-method write always produces exactly one latest.
- **Workflow-step writes** (`step_name != ""`) demote prior rows with the
  same `step_name` AND prior model-method rows (`step_name = ""`), but
  leave other steps' latest rows untouched. Different workflow steps
  writing to the same data name maintain independent version chains.

Collection helpers (`findBySpec`, `findByTag`) return the latest version
per step, so multiple records may be returned for the same data name when
produced by different workflow steps. `data.latest()` returns the single
most-recently-written record regardless of step.

**Vault resolution:** JSON attributes containing `vault.get(...)` references
are resolved automatically in async data access paths (extension methods,
`data.query()` in CEL). Resolution failures leave the reference unresolved
rather than failing the record.

## Predicate Syntax

Predicates are standard CEL expressions that evaluate to a boolean. Any CEL
operator or built-in function can be used.

```cel
modelName == "ingest-pipeline" && specName == "result"

tags.env == "prod" && tags.team == "platform"

specName == "result" || specName == "summary"

name.contains("episode") && version > 3

streaming && ownerType == "workflow-step"

modelName == "scanner" && attributes.status == "failed"
```

### Field Validation

Before evaluation, the predicate AST is walked to verify that all referenced
identifiers are known query record fields. Unknown fields produce an error
(`src/domain/data/query_predicate.ts` `validateFieldReferences`; the message
pluralises to `Unknown fields` and lists the available names alphabetically):

```
Error: Unknown field "model" in query predicate.
Available: attributes, content, contentType, createdAt, dataType, id, isLatest,
  jobName, lifetime, modelName, modelType, name, ns, ownerRef, ownerType, size,
  source, specName, stepName, streaming, tags, version, workflowName,
  workflowRunId
```

## Catalog

Query performance is backed by a SQLite metadata catalog at `_catalog.db`
inside the local-tier `data/` directory (`.swamp/data/_catalog.db` by default;
`catalogDbPath` in `src/infrastructure/persistence/repository_factory.ts`
resolves it via `localPath("data")`, never the datastore tier), using
`node:sqlite` (built into the Deno runtime).
The catalog stores one row per artifact version, with an `is_latest` column
distinguishing the current version. It contains all metadata fields from the
query record except `attributes`.

### Schema

```sql
CREATE TABLE catalog (
  namespace       TEXT NOT NULL DEFAULT '',
  type_normalized TEXT NOT NULL,
  model_id        TEXT NOT NULL,
  data_name       TEXT NOT NULL,
  id              TEXT NOT NULL,
  version         INTEGER NOT NULL,
  is_latest       INTEGER NOT NULL DEFAULT 1,
  model_name      TEXT NOT NULL,
  spec_name       TEXT NOT NULL DEFAULT '',
  data_type       TEXT NOT NULL DEFAULT '',
  content_type    TEXT NOT NULL DEFAULT '',
  lifetime        TEXT NOT NULL DEFAULT '',
  owner_type      TEXT NOT NULL DEFAULT '',
  streaming       INTEGER NOT NULL DEFAULT 0,
  size            INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT NOT NULL,
  tags            TEXT NOT NULL DEFAULT '{}',
  owner_ref       TEXT NOT NULL DEFAULT '',
  workflow_run_id TEXT NOT NULL DEFAULT '',
  workflow_name   TEXT NOT NULL DEFAULT '',
  job_name        TEXT NOT NULL DEFAULT '',
  step_name       TEXT NOT NULL DEFAULT '',
  source          TEXT NOT NULL DEFAULT '',
  PRIMARY KEY (namespace, type_normalized, model_id, data_name, version)
);

CREATE INDEX idx_catalog_model_name      ON catalog(model_name);
CREATE INDEX idx_catalog_spec_name       ON catalog(spec_name);
CREATE INDEX idx_catalog_data_type       ON catalog(data_type);
CREATE INDEX idx_catalog_created_at      ON catalog(created_at);
CREATE INDEX idx_catalog_workflow_run_id ON catalog(workflow_run_id);
CREATE INDEX idx_catalog_step_name       ON catalog(step_name);
CREATE INDEX idx_namespace               ON catalog(namespace);
CREATE INDEX idx_catalog_is_latest       ON catalog(namespace, type_normalized, model_id, data_name, is_latest);
CREATE INDEX idx_catalog_latest_lookup   ON catalog(model_name, data_name, is_latest, namespace);

CREATE TABLE catalog_meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
```

The catalog includes a `schema_version` key in `catalog_meta`. When the
version changes, the catalog table is dropped and rebuilt via self-healing
backfill on next query.

Content is not stored in the catalog. It remains on disk in the existing
versioned file layout.

### Write-Through Updates

Every mutation in `UnifiedDataRepository` updates the catalog inline:

| Repository Method | Catalog Operation |
| --- | --- |
| `save()` | `upsertNewVersion` — full row for the new version, size, createdAt (no checksum column) |
| `append()` | `upsertNewVersion` — full row for the appended version |
| `delete()` | Remove row, or update version if only one version deleted |
| `rename()` | Remove old row, insert new row |
| `finalizeVersion()` | Upsert row |
| `removeLatestMarker()` | Remove row |
| `collectGarbage()` | Update version or remove row |

`UnifiedDataRepository` is an interface (in `repositories.ts`). The concrete
`FileSystemUnifiedDataRepository` takes `CatalogStore` as a required
constructor parameter. Every repository instance maintains write-through
catalog consistency. Use `createCatalogStore()` from `repository_factory.ts`
to construct one from a repo directory.

### Population Strategy

The catalog builds up incrementally:

1. **Write-through** — every data mutation upserts or removes a catalog row.
   New data is immediately queryable.
2. **Scoped backfill** — `getLatestRecord()` uses a three-tier lookup that
   avoids the full `findAllGlobal()` walk. First it tries the indexed SQL
   lookup (O(1) — catches write-through rows). If the catalog is not populated
   and the row is missing (or stale), it runs a scoped filesystem walk for just
   the requested `(modelName, dataName)` pair, upserts matching rows, and
   retries. The `populated` flag is not set by scoped backfill.
3. **Full backfill on first query or search** — on the first call to
   `DataQueryService.query()` or `ensurePopulated()` (used by `data search`),
   if the catalog is not marked as populated, a one-time `findAllGlobal()` runs,
   commits every row it found, and sets a `populated` flag in the
   `catalog_meta` table. Both `data search` and `data query` use the catalog
   after backfill — `data search` iterates `is_latest` rows directly rather
   than re-walking the filesystem.
4. **Self-healing** — if `_catalog.db` is deleted or corrupted, the next query
   triggers a backfill automatically.

Full backfill **upserts** rather than replaces. It commits through
`bulkUpsert()`, which uses `INSERT OR REPLACE` without a preceding `DELETE`.
Rows the on-disk walk finds are added or updated; rows it cannot see are left
untouched. This is critical for `hydrationStrategy: lazy`, where the local
cache is intentionally incomplete — data lives in the remote datastore and is
materialized on demand. Under the previous destructive replace semantics, a
walk gap was data loss in the catalog; under additive upsert, a walk gap is a
no-op for the rows it misses.

### Stale-Row Filtering

`DataQueryService` accepts a `filterStaleRows` option. When enabled, the
query hydration loop calls `Deno.statSync` on each row's `raw` content file
and drops rows where the file is absent. This catches catalog rows orphaned
by a model retype (type field changed, UUID kept), where data moves to a new
type directory path and the old catalog row becomes stale.

`filterStaleRows` must be **disabled** for remote datastores (S3/GCS) where
content may not yet be hydrated into the local cache. A missing `raw` file in
that context means "not yet downloaded", not "stale". The repo-context
composition root sets `filterStaleRows: !isCustomDatastoreConfig(...)`.

The trade-off is that the catalog can accumulate orphaned rows for data that
was genuinely deleted or renamed outside the write-through path (e.g. manual
file deletion). Write-through handles normal deletes and renames, and
`swamp doctor datastores --repair -y` removes `_catalog.db` so the next query
rebuilds it from scratch for full reconciliation. That rebuild also clears
foreign-namespace rows fetched by `swamp datastore catalog pull` — they
describe data that is not on local disk, so a local walk cannot recreate
them; re-pull to restore them.

### Remote Datastores (S3)

The catalog is local-only. It lives in the local cache directory and is excluded
from sync — it is never pushed to or pulled from S3.

After a `pullChanged()` that reports work, core sets `synced = true` and the
caller invalidates the catalog (`catalogStore.invalidate()`), so the next query
backfills from the freshly-pulled cache (`src/cli/repo_context.ts`
`acquireModelLocks`). There is no incremental row-level update from a pull
diff — `pullChanged()` returns `Promise<number | void>`, not a structured
diff.

On cold start (new machine, empty cache), the initial pull downloads all files.
The catalog doesn't exist yet, so the first query triggers a backfill from the
freshly-pulled cache.

## Query Execution

Queries use a two-phase evaluation: SQL pre-filtering narrows the candidate
set, then the full CEL predicate evaluates on every row returned by SQL. The
CEL evaluation is always the correctness authority — SQL pushdown is a
performance optimization only.

### SQL Pushdown

Before iterating, the query service extracts trivially correct predicates from
the CEL AST and pushes them down to SQL WHERE clauses:

| CEL pattern                     | SQL pushdown                  | Notes                                              |
| ------------------------------- | ----------------------------- | -------------------------------------------------- |
| implicit `isLatest == true`     | `WHERE is_latest = 1`         | Applied when predicate doesn't reference `version` or `isLatest` |
| `modelName == "<literal>"`      | `WHERE model_name = ?`        | Extracted from top-level AND conjuncts only         |

All other predicates (OR expressions, comparisons, tag filters, `attributes`
references, complex expressions) remain CEL-only and are evaluated per-row on
the narrowed result set. Future versions may push down additional patterns
(tag equality via `json_extract`, comparisons on indexed columns).

The pushdown invariant: SQL must produce a **superset** of matching rows. CEL
can only narrow, never widen. If a pushdown translation is uncertain, the
conjunct stays in CEL.

### Execution Flow

```
1. Parse predicate into AST
2. Validate field references
3. Extract SQL pushdown clauses (isLatest, modelName equality)
4. Detect whether the filter or the select expression references
   `attributes` or `content` (referencesAttributes / referencesContent)
5. SELECT * from catalog with WHERE pushdown
   (via paged LIMIT/OFFSET queries using stmt.all(); content is never
   a column, so this is metadata only)
6. For each row:
   a. Project row into query record
   b. If step 4 found a content reference:
      load content from disk for this row
   c. Evaluate full CEL predicate against query record
   d. If true: add to results
   e. If results.length >= limit: stop
7. Return results
```

Iteration uses paged `stmt.all()` with `LIMIT/OFFSET` so that rows are fetched
in bounded batches. Content is loaded per-row only when needed. The query stops
as soon as the limit is reached.

When neither the predicate nor the projection references `attributes` or
`content`, no content is loaded at all. This is detected by walking both ASTs
for those identifiers before execution
(`src/domain/data/data_query_service.ts`).

## Projection (`--select`)

The `--select` flag takes a second CEL expression that controls what to show
from each matched row. The filter predicate decides **which rows** match. The
projection decides **what to extract**.

```bash
swamp data query '<filter predicate>' --select '<projection expression>'
```

Both expressions operate on the same `DataRecord` fields. The filter returns a
boolean; the projection returns any value.

### Output Format by Return Type

The projection result type determines the output format:

| Projection returns | Log mode | JSON mode |
| --- | --- | --- |
| string / number / bool | One value per line | Array of values |
| map (object) | Table with map keys as headers | Array of objects |
| list (array) | Markdown table with positional numeric headers (`1`, `2`, …) | Array of arrays |
| null | Empty line (scalar) or empty cells (map/list) | `null` in array |

The first **non-null** result's type sets the format
(`src/libswamp/data/query.ts` `classifyProjection`). If it is a map, all
results render as a table; if it is a scalar, all results render as lines
(`src/presentation/renderers/data_query.ts`).

### Map Key Syntax

CEL map literals require **quoted string keys**. Bare identifiers are resolved
as variable references, not key names:

```cel
{"name": name, "status": attributes.status}    ✓ correct
{name: name, status: attributes.status}         ✗ wrong — "name" resolves as variable
```

### Examples

**Scalar projection** — one value per row, pipe-friendly:

```bash
$ swamp data query 'modelName == "ingest"' --select 'name'

episode-001
episode-002
episode-003
```

**String expression** — formatted output:

```bash
$ swamp data query 'specName == "result"' \
    --select 'modelName + "/" + name + " v" + string(version)'

ingest/episode-001 v3
ingest/episode-002 v1
scanner/scan-result v7
```

**Map projection** — custom-columned table:

```bash
$ swamp data query 'modelName == "ingest"' \
    --select '{"name": name, "status": attributes.status, "v": version}'

name             status    v
───────────────  ────────  ──
episode-001      failed     3
episode-002      ok         1
episode-003      failed     5
```

The map keys become column headers. This is the primary way to build custom
views — pick exactly which fields you want, name them how you want.

With `--json`, map projections produce a JSON array of objects:

```bash
$ swamp data query 'modelName == "ingest"' \
    --select '{"name": name, "status": attributes.status}' --json

[
  {"name": "episode-001", "status": "failed"},
  {"name": "episode-002", "status": "ok"}
]
```

**Nested map projection** — complex structures as table values:

```bash
$ swamp data query 'modelName == "scanner"' \
    --select '{"name": name, "system": {"kernel": attributes.kernel, "arch": attributes.arch}}'

name             system
───────────────  ─────────────────────────────────────────
ip-172-31-12     `{"kernel":"6.1.161-183","arch":"x86_64"}`
ip-10-0-3-42     `{"kernel":"6.1.161-183","arch":"arm64"}`
```

Complex values (objects, arrays) in table cells render as inline JSON code
spans. Any object-valued projection is classified as a map and rendered as a
table — there is no pretty-printed JSON block mode in log output. To dump
whole objects, use `--json`:

**Bare attributes** — dump content from matching records:

```bash
$ swamp data query 'modelName == "ingest" && specName == "result"' \
    --select 'attributes' --json

[
  { "status": "failed", "errorCode": "TIMEOUT", "retries": 3 },
  { "status": "ok", "processedCount": 142 }
]
```

In log mode the same projection renders as a table whose columns are the keys
of the first non-null record.

**Conditional projection:**

```bash
$ swamp data query 'specName == "result"' \
    --select 'attributes.status == "failed" ? "FAIL " + name : "ok   " + name'

FAIL episode-001
ok   episode-002
FAIL episode-003
```

**List projection** — positional columns with numeric headers:

```bash
$ swamp data query 'tags.env == "prod"' \
    --select '[name, modelName, string(size)]'

1            2         3
───────────  ────────  ────
episode-001  ingest    1234
episode-002  ingest    890
config       platform  45
```

### Default (no `--select`)

Without `--select`, the CLI renders a Cliffy `Table` (not markdown) with fixed
columns `name`, `modelName`, `specName`, `dataType`, `version`, `size`, prefixed
by a `namespace` column when any result has a non-empty namespace
(`src/presentation/renderers/data_query.ts` `renderDefaultTable`).

### Interaction with Other Flags

`--select` and `--json` compose naturally: `--json` changes the rendering of
projected values from human-readable to JSON. `--select` and `--limit` compose
naturally: limit applies to matched rows, projection applies to output.

### Implementation

Projection is a domain/application concern. The `DataQueryService` returns
`DataRecord[]` as before, but accepts a `select` option so it loads
`attributes`/`content` from disk when the projection references them. The
libswamp generator evaluates the projection against each result, classifies
the output shape, and yields typed events. On the `--select` path the renderer
builds markdown from the event data and passes it through
`renderMarkdownToTerminal()`; the default (no `--select`) path builds a Cliffy
`Table` directly.

## Usage

### CLI

```bash
swamp data query 'modelName == "ingest" && specName == "result"'
swamp data query 'tags.env == "prod" && size > 1048576'
swamp data query 'attributes.status == "failed"' --limit 10
swamp data query 'modelName == "scanner"' --json
swamp data query 'modelName == "ingest"' --select 'name'
swamp data query 'specName == "result"' --select '{"name": name, "err": attributes.errorCode}'
```

### CEL Expressions

`data.query()` accepts a predicate and an optional projection expression.
Without projection, it returns `DataRecord[]`. With projection, it returns
the projected values directly.

```yaml
attributes:
  # Query returns DataRecord[]
  results: ${data.query('modelName == "ingest" && specName == "result"')}

  # With projection — returns projected values directly
  names: ${data.query('modelName == "ingest"', 'name')}

  # Project a custom object per record
  summary: ${data.query('specName == "result"', '{"name": name, "status": attributes.status}')}

  # Without projection — use .map() for the same effect
  names2: ${data.query('tags.team == "platform"').map(r, r.name)}

  # Check existence
  hasData: ${size(data.query('modelName == "config" && name == "active"')) > 0}
```

Results without projection are interchangeable with `data.latest()`,
`data.findBySpec()`, etc.

### Extension Methods

`context.queryData()` accepts the same two arguments:

```typescript
// Without projection — returns DataRecord[]
const results = await context.queryData!(
  'modelName == "upstream" && tags.env == "prod"'
);
for (const record of results) {
  const { hostname, os } = record.attributes;
}

// With projection — returns projected values
const names = await context.queryData!(
  'modelName == "scanner"',
  'name'
);
// names is string[]
```

## Architecture

`CatalogStore` is an infrastructure component wrapping `node:sqlite`
(`src/infrastructure/persistence/catalog_store.ts`). It exposes row writes
(`upsert`, `upsertNewVersion`, `bulkUpsert`, `bulkUpsertForeign`), removal
(`remove`, `removeVersion`, `bulkRemoveVersions`), reads (`iterate`,
`iterateFiltered`, `findLatestRow`, `findLatestRowsBySpecName`, `count`,
`distinctValues`, `distinctTagKeys`/`distinctTagValues`), population
management (`isPopulated`, `markPopulated`, `invalidate`) and maintenance
(`checkpoint`, `vacuum`).

`DataQueryService` is a domain service. It owns the query lifecycle: catalog
population, AST validation, row iteration, content loading, and CEL evaluation.

```
CLI / CEL / Extension method
         │
    DataQueryService (domain)
         │
    ┌────┴────┐
    │         │
CatalogStore  CelEvaluator
(node:sqlite) (existing)
    │
    │         UnifiedDataRepository
    │              │
    │         content loading
    │         (lazy, per-row)
    │
    └── write-through updates from UnifiedDataRepository mutations
```

Both `CatalogStore` and `DataQueryService` are wired through
`RepositoryContext` via `createRepositoryContext()`.

## Ephemeral Data

Data with `lifetime: "ephemeral"` lives only in memory for the duration of a
workflow run or method run. It uses a parallel in-memory stack:

- **`InMemoryUnifiedDataRepository`** — `Map`-based storage, no disk I/O.
  `allocateVersion` creates a temp file for `DataWriter` compatibility;
  `finalizeVersion` reads it into memory and deletes it.
- **`:memory:` `CatalogStore`** — a separate SQLite instance so queries work
  transparently. Marked as pre-populated to skip filesystem backfill.
- **`CompositeUnifiedDataRepository`** — wraps the filesystem and in-memory
  repos. Writes route by `data.lifetime === "ephemeral"`. Reads check ephemeral
  first, fall back to persistent. `data.latest()` resolves transparently.
- **`CompositeDataQueryService`** — merges query results from both catalogs
  with deduplication.

### Lifecycle scoping

The ephemeral store is created at the start of each execution and disposed in
the `finally` block:

- **Workflow runs** — `workflowRun()` creates the store, passes it through
  `createExecutionService` → `WorkflowExecutionService` constructor. All steps
  share the same store so downstream steps can read upstream ephemeral data.
- **Standalone method runs** — `modelMethodRun()` creates and disposes its own
  store.
- **Workflow resume** — a fresh store is created. Ephemeral data from before
  suspension is lost (by design — use `"workflow"` or `"infinite"` lifetime for
  data that must survive suspension).

### Definition-level overrides

Definitions can override a model type's default resource lifetime:

```yaml
resources:
  result:
    lifetime: ephemeral
    garbageCollection: 3
```

These are converted to `dataOutputOverrides` and merged with any workflow step
overrides (step wins).

### Remote execution

Each `ActiveDispatch` carries the per-execution composite repo. The data plane
resolves `dispatch.dataRepo` for each worker's reads and writes, so remote
workers transparently access ephemeral data through the same composite as local
steps.
