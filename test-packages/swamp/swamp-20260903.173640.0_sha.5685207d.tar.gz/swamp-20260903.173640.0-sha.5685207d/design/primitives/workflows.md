---
audience: maintainer, operator
last-verified: 2026-08-28 @ 3d5955a9
---

# Workflows

The workflow is the overall definition of what to execution, represented by a
_Workflow Run_.

Each workflow is made up of one or more _jobs_.

Jobs are made up for one or more _steps_, where a step can be calling a method
on a model or invoking another workflow. Jobs can be dependent on each other,
and only execute if their dependcy condition is met (for example, only run this
job if one of its upstream dependencies fail).

Within a job, steps are executed with a weighted topological sort, so that they
have maximum parallelism through the job. Steps support an optional
`concurrency` field that caps how many steps in a topological level run
simultaneously — particularly useful for `forEach` expansions that hit
rate-limited APIs.

Jobs can have dependencies on other jobs. The entire workflow is executed with a
weighted topological sort, so that they have maximum parallelism through the
workflow. Like steps, jobs also have conditions that trigger them.

## Step Task Variants

A `model_method` step task supports two mutually exclusive variants:

### Existing Definition (`modelIdOrName`)

References a pre-created definition by name or ID:

```yaml
task:
  type: model_method
  modelIdOrName: my-vpc
  methodName: create
  inputs:
    cidr: "10.0.0.0/16"
```

### Direct Type Execution (`modelType` + `modelName`)

Auto-creates a definition if it doesn't exist, using the type's schemas to route
inputs between global arguments and method arguments:

```yaml
task:
  type: model_method
  modelType: "@swamp/aws/ec2/vpc"
  modelName: my-vpc
  methodName: create
  inputs:
    region: us-east-1
    cidr: "10.0.0.0/16"
```

These variants are mutually exclusive — a step cannot have both `modelIdOrName`
and `modelType`. Auto-created definitions are stored in
`.swamp/auto-definitions/`.

An optional `globalArgs` field passes global arguments explicitly, bypassing
schema-based input routing. When present, `inputs` are treated as method
arguments only:

```yaml
task:
  type: model_method
  modelType: "@myorg/deployer"
  modelName: my-deployer
  methodName: deploy
  globalArgs:
    region: us-east-1
  inputs:
    version: "1.0"
```

`globalArgs` is only valid with direct type execution — the schema rejects it
for `modelIdOrName` tasks.

Both `inputs` and `globalArgs` accept either a literal YAML record or a single
CEL expression that evaluates to a record at runtime:

```yaml
# Literal record (individual values may contain expressions)
inputs:
  host: ${{ self.host }}
  port: 443

# Whole-field expression (must evaluate to a record)
inputs: ${{ self.item.implementation.inputs }}
globalArgs: ${{ self.item.implementation.globalArgs }}
```

Whole-field expressions are validated after evaluation — if the expression
produces a non-record value (null, array, number, string), the step fails with a
clear error.

For `forEach` steps, `self.*` CEL template expressions resolve in every task
target field — `modelIdOrName`, `modelName`, `methodName`, and (for workflow
tasks) `workflowIdOrName` — as well as the step `name`, `inputs`, and
`globalArgs`:

```yaml
- name: scan-${{self.host}}
  forEach: { item: host, in: "${{ inputs.hosts }}" }
  task:
    type: model_method
    modelType: "@swamp/cve/dirtyfrag"
    modelName: fleet-scanner
    methodName: scanFleet
    inputs:
      host: ${{ self.host }}
```

### Manual Approval (`manual_approval`)

Suspends workflow execution at a step boundary and persists the run to disk. The
operator (or another user) approves or rejects via CLI, then the original
operator resumes the workflow to continue executing remaining steps.

```yaml
steps:
  - name: verify-ssh
    task:
      type: manual_approval
      prompt: "Verify Tailscale SSH access from your laptop before proceeding"
      timeout: 3600
```

**Fields:**

- `prompt` (required, string) — message displayed to the operator.
- `timeout` (optional, number) — seconds. Checked at approve **and** reject
  time against the step's suspension timestamp (`evaluateApprovalTimeout` in
  `src/libswamp/workflows/approve.ts` and `reject.ts`). When expired, both
  approve and reject are refused, the run is omitted from
  `swamp workflow approvals` (`src/libswamp/workflows/approvals.ts`), and the
  run stays `suspended` — cancel it to clear it.

**Lifecycle: suspend → approve → resume**

1. `swamp workflow run` executes until hitting a `manual_approval` step. The step
   is marked `waiting_approval` and the run status is set to `suspended`.
   Parallel sibling steps that are already in-flight continue executing until
   they reach a terminal state (succeeded, failed, or skipped) — the executor
   drains all generators at the current level before persisting. The saved run
   record is a consistent checkpoint: every step is either completed, parked in
   `waiting_approval`, or has not started. Before starting execution, `workflow run` **supersedes** any prior
   suspended runs of the same workflow whose resolved inputs match the new run's
   inputs (deep equality). Matching suspended runs are cancelled with reason
   "Superseded by new run with matching inputs". Runs with different inputs are
   left alone — they represent independent intents. Serve-owned suspended runs
   are also skipped (cancel those via the serve API). Use `--no-supersede` to
   opt out. The CLI then exits once the new run suspends.
2. `swamp workflow approve <workflow> <step> --run <id>` marks the step as
   succeeded in the persisted run record. Lightweight — no execution. The
   local command performs no authorization of its own: `decidedBy` is recorded
   from `$USER`/`$USERNAME`, falling back to `"unknown"`
   (`src/libswamp/workflows/approve.ts`); authorization applies only on the
   `--server` path via the `workflow.approve` handler. The `--run` flag
   disambiguates when multiple runs are suspended; it is optional when only
   one run is suspended.
3. `swamp workflow resume <workflow> --run <id>` re-enters the executor, skips
   completed steps, and runs remaining pending steps.

`swamp workflow reject <workflow> <step> --run <id>` marks the step as failed and
the run as failed. No resume needed.

`swamp workflow approvals` lists suspended runs awaiting approval — one row per
run, naming the first waiting gate (`findWaitingApprovalStep` in
`src/domain/workflows/workflow_run.ts`), with runs whose gate has timed out
omitted — showing each run's id, suspended-at timestamp, inputs digest, and
ready-to-run `--run <id>` approve/reject/resume commands. Supports `--server` /
`SWAMP_SERVE_URL` / `SWAMP_SERVER_URL` via the `workflow.approvals`
wire-protocol endpoint (read-only, `read` authorization verb).

**Programmatic gate control (not wired):** `MethodContext` declares
`context.approveWorkflowGate()` / `context.rejectWorkflowGate()`, but no
production path constructs the `WorkflowGateService` behind them
(`createWorkflowGateService` in `src/libswamp/models/workflow_gate.ts` has no
callers outside tests; `src/libswamp/workflows/run.ts` leaves the service
deliberately unwired because model code bypasses authorization), and on a
remote worker both return `{ ok: false }`
(`src/worker/remote_method_context.ts`). Approve and reject via the CLI or the
`workflow.approve` / `workflow.reject` WebSocket requests instead.

**Resume inputs (`--input`):** `swamp workflow resume` accepts `--input`,
`--input-file`, and `--stdin` (same parsing as `swamp workflow run`). These let
an operator supply values that were not available at the original run time —
elevated credentials, environment-specific overrides, or a freshly minted auth
key issued during the gate. Resume inputs are **deep-merged** (`deepMerge` in
`src/domain/workflows/execution_service.ts`) over the inputs captured when the
run suspended: existing keys are preserved, nested records merge key by key,
and a resume `--input` wins on a key collision. The merged set is placed on the expression context before
evaluation, so post-gate `inputs.*` expressions resolve to the updated values.
Workflow evaluation remains **strict**: a workflow must declare (at run time)
every input it references, so the pattern is _declare the input at run, supply
or override its value at resume_ — e.g. start with `authKey` set to a
placeholder and pass the real key at resume. For audit, the run record captures
the **key names** of resume-time inputs (never their values, so secrets are not
written to the persisted run).

**Input persistence:** A run's effective inputs are captured on the run record
at run **start** (`run.captureInputs` in
`src/domain/workflows/execution_service.ts`, persisted by the first `saveRun`)
and re-captured when the run suspends, so every run's `inputs` block is on
disk and steps after a gate can resolve `inputs.*` on resume. Only the *key
names* of resume-time inputs are recorded, never their values.

**Persistence:** The run record survives process restarts. The approval and
resume can happen from any machine with access to the repo (or synced
datastore).

**forEach compatibility:** A `forEach` expansion of a `manual_approval` step
creates N parallel approval gates, each independently approvable via its expanded
step name. `resume()` refuses to start while *any* step is still
`waiting_approval` (`src/domain/workflows/execution_service.ts`), so all N
gates must be decided before the run resumes.

### Resume from Failed Step (`--from`)

Re-enters a **failed** run's DAG at a named step. Combined with the `guard`
field, this enables safe workflow recovery — guards decide which steps actually
re-execute while `--from` controls where to re-enter.

```
$ swamp workflow resume <workflow> --from <step>
$ swamp workflow resume <workflow> --from <step> --run <run-id>
```

If there is exactly one failed run for the workflow, `--run` can be omitted.

**Semantics:**

1. The `--from` step and all its transitive downstream dependents are reset to
   `pending`.
2. Steps before `--from` retain their terminal status (`succeeded`, `failed`,
   `skipped`) and are skipped by the executor's existing resume-skip logic.
3. Guards on reset steps are evaluated normally — a step with a truthy guard is
   skipped even if reset.
4. Steps without a guard always execute on resume. If you didn't write a guard,
   you're saying "always run this step."

**Step name resolution:** `--from` targets template step names as written in the
workflow YAML, not forEach-expanded iteration names. For forEach steps, all
expanded iterations are reset and re-evaluated — completed iterations with truthy
guards are skipped; failed or unstarted iterations execute.

**Status restriction:** `--from` only works on failed runs. It cannot be used
with suspended runs (use the gate-approval resume path instead) or succeeded
runs. When `--from` is omitted, resume behaves as before (gate-suspend only).

**Cross-job propagation:** If the `--from` step is in job B, only job B and any
downstream jobs containing transitive dependents are reset. Upstream jobs (job A)
that completed successfully retain their terminal status.

**Trigger conditions:** Trigger conditions on reset steps are still evaluated.
If `--from` targets a step whose upstream dependency also failed, the trigger
condition will see the upstream's `failed` status. Resume from the earlier step
instead.

### Assert (`assert`)

Evaluates a CEL predicate over prior step data, records a pass/fail result, and
fails the step when the predicate is false. Can optionally invoke model methods
via `model.method()` to check external state as part of the assertion.

```yaml
steps:
  - name: instance-count
    task:
      type: assert
      expr: size(data.latest("cp-nodes", "instances")) == 3
      message: "Expected 3 instances, got ${{ size(data.latest('cp-nodes', 'instances')) }}"
      severity: high
```

**Fields:**

- `expr` (required, string) — CEL expression evaluated via `evaluateAsync()`.
  Has access to the full expression context including `data.latest()`,
  `inputs.*`, `self.*`, and `model.method()` (see
  [model.method() in guards](#modelmethod-in-guards) for syntax).
- `message` (required, string) — human-readable message. Supports `${{ }}`
  expression interpolation. Displayed on failure and included in JUnit XML
  output.
- `severity` (optional, `low` | `medium` | `high`, default `high`) — controls
  whether a failure triggers the `--fail-on` exit code threshold.

**Execution:** The CEL `expr` is evaluated asynchronously. A truthy result marks
the step as succeeded; a falsy result marks it as failed with the resolved
`message`. The `assertResult` (passed, expr, resolved message, severity) is
recorded on the `StepRun` and persisted to the workflow run record.

**Exit code control (`--fail-on`):** `swamp workflow run` accepts
`--fail-on <severity>` (default `low`). The run exits non-zero only when at
least one assert failure is at or above the threshold. A `low` severity failure
under `--fail-on high` is recorded but does not affect the exit code.

**JUnit XML output (`--junit`):** `swamp workflow run --junit [--out <file>]`
emits one `<testcase>` per assert step, with a `<failure>` element on false.
Non-assert steps are omitted from the JUnit output.

**model.method() in assert:** Assert expressions can invoke model methods using
`model.method(modelName, methodName)` or
`model.method(modelName, methodName, inputs)`, with the same semantics as
[guard expressions](#modelmethod-in-guards). The method executes through the step
executor. When the method produced a `resource` data handle, the return value
is that resource's parsed content; otherwise the raw execution result is
returned as-is (`src/domain/workflows/execution_service.ts`). This enables
assertions that check external state:

```yaml
steps:
  - name: verify-instance-running
    task:
      type: assert
      expr: model.method("infra", "check-status", {"name": inputs.instanceName}).stdout == "running"
      message: "Instance ${{ inputs.instanceName }} is not running"
      severity: high
```

**forEach compatibility:** Assert steps support `forEach` expansion. Each
expanded iteration produces its own assert result and JUnit `<testcase>`.

**Known limitation — message interpolation:** The `${{ }}` pattern in `message`
uses non-greedy matching. A CEL expression containing a literal `}}` (e.g.
map/struct literals) will be split prematurely. The error is silently caught and
the expression left as-is, so it degrades gracefully. Keep `message`
interpolation to simple value lookups; use the `expr` field for complex CEL.

**Known limits:**

- `expr` must be a raw CEL expression. Wrapping it in `${{ }}` is a
  validation failure (`validateAssertExprNotInterpolated` in
  `src/domain/workflows/validation_service.ts`).
- An assert failure below the `--fail-on` threshold is recorded as an
  **allowed failure** (`markAllowedFailure`), so downstream `succeeded`
  conditions see the step as failed while the run can still succeed.
- `--fail-on` is rejected together with `--server`
  (`src/cli/commands/workflow_run.ts`); `--junit` cannot be combined with
  `--json` or with NDJSON `--stdin` batches, and `--out` requires `--junit`.

## Concurrency Limits

By default, all jobs in a topological level and all steps in a topological level
run concurrently (maximum parallelism). The optional `concurrency` field caps
the number of simultaneously executing units at each level:

```yaml
concurrency: 10  # workflow level — caps parallel jobs

jobs:
  - name: fan-out
    concurrency: 5  # job level — caps parallel steps in this job
    steps:
      - name: per-item
        forEach:
          item: target
          in: ${{ inputs.targets }}
        concurrency: 3  # step level — caps forEach iterations
        task: { ... }
```

**Semantics:**

- A positive integer is a hard cap on simultaneously executing units at that
  level.
- `0` or absent means unbounded (current default behavior).
- Resolution order: step > job > workflow > unbounded. Step-level values are
  collected across the topological level and the **minimum** is applied to
  every step stream in that level (`src/domain/workflows/execution_service.ts`).
  Fall-through only happens for *absent* values: an explicit `0` at the job
  level does not fall through to the workflow value — it resolves to
  unbounded (or the global ceiling).
- A global `SWAMP_MAX_CONCURRENT_STEPS` environment variable provides a
  host-level ceiling. The effective limit is `min(local, global)` when both are
  set. On `workflow resume` the ceiling is applied at the step level only — the
  job-level limit is taken from the workflow as written.

Concurrency limiting is implemented via a semaphore-gated
`mergeWithConcurrency()` that wraps the existing `merge()` stream combinator.
When the limit is unset or exceeds the stream count, the unbounded `merge()` path
is used with zero overhead.

Workflows are specified in YAML files, that are validated with Zod, in the
top-level `workflows/` directory of the repository, as
`workflows/workflow-{name}.yaml` (legacy `workflow-{uuid}.yaml` files are also
supported). Workflow run output is stored in the datastore at
`workflow-runs/{workflow-id}/workflow-run-{run-id}.yaml` (default path:
`.swamp/workflow-runs/`).

## Validation

`swamp workflow validate` checks structure (schema, unique names, dependency
references, cycles) and validates each step's inputs against the resolved
method's required arguments. To resolve a step's model type, the local path
first hot-loads pulled and local extensions (`modelRegistry.ensureLoaded()` in
`src/cli/commands/workflow_validate.ts`), matching the resolution available to
`swamp model type describe` and `swamp model validate`. With `--server` the
command delegates to the serve instance, which resolves types from its own
loaded registry.

Validation results have three severity levels:

- **Pass** (green ✓) — the check succeeded.
- **Warning** (yellow ⚠) — the check passed but something looks suspicious.
  Warnings do not fail validation or affect the exit code.
- **Fail** (red ✗) — the check failed. At least one failure causes non-zero
  exit.

Step-input checks fail when the resolved method does not exist
(`method_not_found`) or when a required argument is missing. A step whose model
**type cannot be resolved** also fails: an unresolvable type is reported as a
validation failure (non-zero exit), never silently skipped as a pass — a silent
skip would mask real contract bugs such as non-existent method names or wrong
argument keys. Dynamic CEL references (`${{ ... }}`) in model/type names are
skipped, since they can only be resolved at run time. A step that references a
model **instance** which does not exist locally (`model_not_found`) produces a
**warning**: the instance may be created by an upstream step during the run, but
it could also be a typo. The warning surfaces the reference without failing
validation.

### GlobalArgument Input References

When a model definition's `globalArguments` or method-level argument defaults
contain `${{ inputs.* }}` expressions, the validator checks that each referenced
input is supplied by the calling step's `inputs:` block. This catches cases where
a model definition expects an input (e.g. `host: ${{ inputs.ip }}`) that the
workflow step never provides, which would fail at runtime with an unresolved
expression. The check resolves against the step's inputs — not the workflow's
top-level inputs — because `${{ inputs.* }}` in a model definition refers to the
model's own input namespace, populated by the step at runtime.

Steps with dynamic inputs (a single `${{ ... }}` expression as the entire
`inputs` value) are skipped, as are steps with dynamic model references, since
neither can be statically analysed. A nested-workflow step whose target
workflow cannot be found reports its input check as "skipped" rather than
failing (`src/domain/workflows/validation_service.ts`). Other checks the
validator runs: placement fields (`queueTimeout`, `affinity`, `writes` without
a placement) and the assert-`expr` interpolation rule described above.

### Unknown Keys Are Rejected

The workflow, job, and step schemas reject unknown keys at parse time with an
actionable error (swamp-club#1240). Zod's default unknown-key stripping is
disabled by a `rejectUnknownKeys` preprocess hook (chained after the
removed-driver-fields guard, which keeps its specific migration message):

- Placement properties (`labels`, `target`, `platform`, `queueTimeout`) are
  valid at the workflow, job, and step level (swamp-club#1685). Workflow-level
  placement applies to all steps as a default, job-level overrides workflow,
  and step-level overrides job.
- Any unknown key gets a did-you-mean suggestion (Levenshtein) plus the
  list of valid keys for that entity.

Because a schema-rejected file is invisible to the repository loader (it is
skipped with a warning), `workflow validate` and `workflow run` re-scan the raw
files on a lookup miss and surface the parse error inline — a broken file fails
validation naming the offending key, and can never make `validate` (or
validate-all) report green.

**Schema evolution consequence**: persisted evaluated-workflow snapshots and
suspended approval runs are re-parsed on resume through these same schemas.
Removing a schema field is therefore a breaking change for data persisted
before the removal — it now requires an explicit migration or tolerance
decision (the removed `driver`/`driverConfig` fields chose a hard, actionable
failure), never a silent strip.

## Workflow Definition

Workflows are specified in `workflows/workflow-{name}.yaml` (legacy
`workflow-{uuid}.yaml` files are also supported). They have a unique id, a
globally unique name, a set of jobs, and optionally workflow inputs.

### Workflow Inputs

Like model definitions, workflows can specify custom inputs (workflow inputs) as
JsonSchema. These inputs allow parameterizing workflows without modifying the
workflow definition file:

```yaml
id: abc123
name: deploy-application
inputs:
  environment:
    type: string
    enum: ["dev", "staging", "production"]
    description: "Target environment for deployment"
  version:
    type: string
    description: "Application version to deploy"
  enableRollback:
    type: boolean
    default: true
    description: "Enable automatic rollback on failure"
jobs:
# ... job definitions can reference ${{ inputs.environment }}, etc.
```

**Workflow Input Rules:**

- Specified as JsonSchema (same rules as model inputs)
- Can be required or optional
- Accessed through CEL expressions: `${{ inputs.someWorkflowParameter }}`
- Distinguish as "workflow inputs" (different from "model inputs")
- Provide dynamic configuration for workflow execution

See [expressions](../enablers/expressions.md) for CEL expression syntax and [models](./models.md) for detailed
input specification patterns.

### Workflow Triggers

Workflows can declare a `trigger` section to enable automatic execution via
`swamp serve`. The `trigger` section is an optional object that contains trigger
configuration.

#### Schedule Trigger

A `schedule` trigger runs the workflow on a cron schedule:

```yaml
id: abc123
name: anime-downloader
trigger:
  schedule: "0 3,12 * * *"
jobs:
  # ... jobs run automatically at 3am and noon
```

**Schedule behavior:**

- Uses [croner](https://github.com/Hexagon/croner) grammar: standard 5-field
  cron (minute, hour, day-of-month, month, day-of-week); a 6-field expression
  puts **seconds first**; `@daily`-style nicknames and the `L` / `#` modifiers
  are accepted
- Validated at parse time by constructing a croner `Cron`
  (`src/domain/workflows/workflow.ts`)
- On `swamp serve` startup, all workflows with schedules are registered
- A filesystem watcher monitors the `workflows/` directory for live reload —
  adding, changing, or removing a schedule takes effect without restart
- Each scheduled fire calls the `executeWorkflow` callback injected into
  `ScheduledExecutionService` (`src/libswamp/workflows/scheduled_execution.ts`),
  which serve wires to `executeWorkflowWithLocks` (`src/serve/deps.ts`) — the
  same path as WebSocket `workflow.run` and webhooks, not the local CLI path
- In an HA deployment each fire is claimed once across instances via the
  `cronFireDedup` hook, and a workflow fires single-flight per instance
- **Overlap prevention:** If a workflow is still running from a previous
  scheduled trigger, the next trigger is skipped with a warning
- **No catch-up:** If serve was down during a scheduled time, it does not fire
  missed schedules on startup — it waits for the next natural cron tick
- Use `--no-schedule` on `swamp serve` to disable scheduled execution

The `ScheduledExecutionService` lives in libswamp, so any consumer (serve, a
future daemon, or programmatic use) can use the same scheduling infrastructure.

#### Trigger Overrides

Extension-bundled workflows are read-only — users cannot modify their YAML to
add or change a trigger. The `triggers` section in `.swamp/serve.yaml` provides
per-workflow overrides that survive extension updates.

Overrides can be managed via the CLI or by editing `serve.yaml` directly:

```bash
# Set a trigger override (replace semantics — writes the full entry)
swamp workflow trigger set @swamp/cve/researcher/scan --schedule "0 3 * * *" --input 'channel=#security'
swamp workflow trigger set daily-report --schedule "0 8 * * 1-5"

# Show the effective trigger (built-in merged with override)
swamp workflow trigger get @swamp/cve/researcher/scan

# Remove a trigger override
swamp workflow trigger remove daily-report
```

The equivalent `serve.yaml` representation:

```yaml
# .swamp/serve.yaml
triggers:
  "@swamp/cve/researcher/scan":
    schedule: "0 3 * * *"
    inputs:
      channel: "#security"
  daily-report:
    schedule: "0 8 * * 1-5"
```

Each key is a workflow name (including scoped `@collective/name` patterns). An
override `schedule` **replaces** the workflow's built-in schedule
(`resolveSchedule` in `src/libswamp/workflows/scheduled_execution.ts`); an
override `inputs` map is deep-merged over the built-in `trigger.inputs` at fire
time. A workflow with no built-in trigger block gains one from the override.
`swamp workflow trigger set` requires `--schedule`
(`src/cli/commands/workflow_trigger_set.ts`); unknown keys in an override
entry are warned about and ignored (`src/serve/serve_config.ts`).

**Override behavior:**

- Applied at `ScheduledExecutionService` startup in a two-phase scan: every
  workflow with a schedule (built-in or override, resolved through
  `resolveSchedule`) is registered first, then the override map is walked for
  any remaining names. An inputs-only override on a workflow that has no
  schedule from either source is a logged no-op
- The `handleScheduleChange` callback also consults the override map, so
  live-reloaded workflows respect overrides
- Overrides for unknown workflow names are logged as warnings and skipped
- Overrides are read at startup and re-read on `swamp serve reload` (SIGHUP or
  WebSocket `serve.reload`). Both reload triggers require the server to have
  been started with `--hot-reload` — without it the SIGHUP handler is not
  installed (`src/cli/commands/serve.ts`) and `serve.reload` is refused with
  `hot_reload_disabled` (`src/serve/handlers/admin_handlers.ts`)
- Works with both extension and local workflows — but the primary use case is
  extension workflows that cannot be edited directly

**Precedence for schedule:** `serve.yaml override > workflow YAML trigger`

**Precedence for trigger inputs:** override inputs are deep-merged on top of
the workflow's built-in `trigger.inputs` — override keys win, but built-in keys
not present in the override fall through. The existing
`caller inputs > trigger.inputs > schema defaults` layering remains unchanged;
override inputs occupy the caller inputs slot, layered above built-in
`trigger.inputs`.

#### Trigger Inputs

Scheduled (and webhook) runs have no `--input` flag, so a `trigger.inputs` map
supplies baseline input values at fire time:

```yaml
trigger:
  schedule: "* * * * *"
  inputs:
    projectId: "a6b254a2-0b57-4d0f-bf8b-fef767ab119e"
jobs:
  # ... runs with projectId already populated
```

This lets a workflow declare `required` inputs without abusing the input
schema's `default` (which would apply to every caller, not just trigger-fired
runs). `trigger.inputs` is a free values map — the runtime values to inject —
distinct from the workflow's `inputs` block, which is the JSON-Schema
description of allowed inputs.

**Precedence:** the values are merged exactly like `--input` on
`swamp workflow run`, layered as `caller inputs > trigger.inputs > schema
defaults`. For a scheduled run there is no caller, so `trigger.inputs` becomes
the baseline. The merged inputs flow through the same coercion,
default-application, and validation pipeline as every other run, so a `required`
input satisfied only by `trigger.inputs` validates successfully.

Trigger inputs are layered in by `executeWorkflowWithLocks`
(`workflow.baselineInputs` in `src/serve/deps.ts`), so they apply to every
serve-executed run — scheduled, webhook, **and** ad-hoc `workflow.run` requests
from `swamp workflow run --server`. Only a local `swamp workflow run` (which
calls `workflowRun` directly, `src/cli/commands/workflow_run.ts`) is unaffected
by `trigger.inputs` — there the operator supplies inputs explicitly.

#### Webhook Payload Extraction

For webhook runs, `trigger.inputs` values may be CEL expressions that read the
inbound request through the `webhook` namespace, mapping payload fields onto
named workflow inputs:

```yaml
trigger:
  inputs:
    identifier: "${{ webhook.body.data.issue.identifier }}"
    eventType: '${{ webhook.headers["x-linear-event"] }}'
inputs:
  type: object
  properties:
    identifier: { type: string }
  required: [identifier]
jobs:
  # ... runs with identifier populated from the webhook body
```

The `webhook` namespace exposes:

- `webhook.body` — the request body, parsed as JSON when the payload is valid
  JSON, otherwise the raw string.
- `webhook.headers` — request headers as a map of lowercased names to values.
  The active scheme's signature header and sensitive credential headers are
  excluded. Redacted headers (`REDACTED_HEADERS` in `src/serve/webhook.ts`)
  include authentication (`authorization`, `proxy-authorization`, `cookie`,
  `set-cookie`, `x-api-key`, `x-auth-token`), provider signatures
  (`x-hub-signature`, `x-shopify-hmac-sha256`), proxy credentials
  (`x-amzn-oidc-accesstoken`, `x-amzn-oidc-data`,
  `x-goog-iap-jwt-assertion`, `cf-access-jwt-assertion`,
  `x-forwarded-client-cert`), and any header ending in `-token` or `-secret`.
- `webhook.route` — the matched webhook route (e.g. `/hooks/linear`).

The signature scheme is selected per endpoint on the `--webhook` flag:
`<route>:<workflow>:<secret>[:<scheme>[:<header>[:<prefix>]]]`. `scheme` is one
of `github` (the default, `X-Hub-Signature-256`), `jira` (`X-Hub-Signature`),
`linear`, `stripe`, `slack`, or `generic` (which requires a header name and
accepts an optional value prefix). When no
scheme is given the flag behaves exactly as before, so the secret may still
contain colons; a scheme is recognized only when the fourth field is a known
scheme keyword.

These expressions are evaluated against the verified payload **at fire time,
before input validation**, so a payload field can satisfy a `required` input.
A whole-value expression preserves the field's native type (object, number,
boolean); an expression embedded in a larger string is interpolated.

swamp's CEL has no `??` operator — guard optional payload fields with the
`has()` macro and a ternary instead:

```yaml
trigger:
  inputs:
    identifier: >-
      ${{ has(webhook.body.data.issue) ?
        webhook.body.data.issue.identifier : webhook.body.data.identifier }}
```

A hard reference to a missing field (without a `has()` guard) surfaces an error
and the run does not start. The `webhook` namespace is available only inside
`trigger.inputs`; the rest of the workflow reads the extracted values as normal
inputs (`${{ inputs.identifier }}`).

**Security:** Sensitive headers (authentication, proxy credentials, and headers
ending in `-token` or `-secret`) are redacted before the payload is persisted or
exposed to workflow expressions. Provider event headers (e.g. `x-github-event`,
`content-type`) are preserved.

**Limits** (`src/serve/webhook.ts`): request bodies are capped at 10 MB, the
in-memory run queue at 100 entries, and every verification failure returns a
uniform `401` so the response cannot be used as an oracle. Webhook endpoints
can also be declared under a `webhooks:` array in `.swamp/serve.yaml`
(`src/serve/serve_config.ts`), with secrets given as `@env=`, `@file=`, or
`@vault=` references; CLI `--webhook` flags replace the config-file entries
entirely.

## Jobs

Each job has a name, a description, a series of steps, and an array of objects
that specify other jobs it depends on that also includes the trigger for this
job to execute. Each `dependsOn` entry is `{ job, condition }`; the condition
is one of `always`, `succeeded`, `failed`, `completed`, `skipped`, or a
boolean combination via `and` / `or` / `not`
(`src/domain/workflows/trigger_condition.ts`, `src/domain/workflows/job.ts`).
For example, job C can depend on jobs A and B and run only if either failed.

## Steps

Each step has a name, a descirption, and a task (which is either a method on a
model to run or a nested workflow to invoke). Each step has dependency logic that
is identical to jobs, only for steps rather than jobs.

When a step invokes a mutating model method (`create`, `update`, `delete`,
`action`), the model's pre-flight checks run automatically before execution. If
any check fails, the step fails immediately without executing the method. Use
`allowFailure: true` on the step to allow the workflow to continue past a
pre-flight failure.

## Allow Failure

Steps can be marked with `allowFailure: true` to indicate that their failure
should not cause the job or workflow to fail. This is useful for test or
diagnostic workflows where some steps may fail due to external constraints (e.g.,
billing plan limitations).

When a step with `allowFailure: true` fails:

- The step is recorded as **failed** with its error message
- The failure is **not propagated** to the job — the job can still succeed
- The step run is flagged with `allowedFailure: true` in the run output
- Trigger conditions behave normally: `succeeded` evaluates to `false` (step did
  fail), `failed` evaluates to `true`, `completed` evaluates to `true`
- Downstream steps with `dependsOn: succeeded` will skip; `dependsOn: completed`
  will fire

```yaml
steps:
  - name: optional-check
    allowFailure: true
    task:
      type: model_method
      modelIdOrName: checker
      methodName: validate
  - name: always-runs
    dependsOn:
      - step: optional-check
        condition:
          type: completed
    task:
      type: model_method
      modelIdOrName: runner
      methodName: execute
```

## Guard (Idempotent Step Execution)

A step can declare a `guard` — a CEL expression evaluated before execution. When
the guard evaluates truthy, the step is skipped (already done). When falsy or
absent, the step executes normally.

Guard is the workflow-level primitive for idempotent step execution, enabling safe
workflow resume, re-run, and cron scheduling without re-executing completed
steps.

### Evaluation order

1. Dependency conditions are checked (`dependsOn`)
2. Expression context is built (including `self.*` for forEach steps)
3. Guard expression is evaluated via `celEvaluator.evaluateAsync()`
4. If truthy → step is skipped with reason `"guarded"`
5. If falsy → step proceeds to execution

### Expression context

Guard expressions have access to the same context as other step expressions:

- `inputs` — workflow inputs
- `data` — data namespace (e.g., `data.latest()`)
- `self` — for forEach steps, includes the iteration variable

### Guard patterns

```yaml
steps:
  # Data truthiness — truthy scalar means done, null means not done
  - name: read-plate
    guard: ${{ data.latest("plate-reader", "scan-complete").attributes.id }}
    task:
      modelName: plate-reader
      method: read-all

  # Value comparison — same batch means skip, different batch means re-run
  - name: dispense-reagent
    guard: >
      ${{ data.latest("liquid-handler", "dispense-log").attributes.batchId
          == inputs.batchId }}
    task:
      modelName: liquid-handler
      method: dispense

  # Method call — invoke a model method to check external state
  - name: create-instance
    guard: >
      ${{ model.method("infra", "check-exists",
          {"name": inputs.instanceName}).stdout }}
    task:
      modelName: infra
      method: create
```

### model.method() in guards

`model.method(modelName, methodName)` or
`model.method(modelName, methodName, inputs)` invokes a model method and returns
the content of its first resource data output (parsed as JSON if possible). This
lets guards check external state by running a lightweight probe method.

The method executes through the same step executor as regular workflow steps, so
it has full access to vault secrets, expression context, and data storage. The
return value is the parsed data output content — for command/shell models this is
`{exitCode, stdout, stderr, ...}`, so guard expressions typically access a
specific field like `.stdout`.

### forEach compatibility

Guard expressions can reference `self.*` (the forEach variable), so each
expanded iteration evaluates its own guard independently:

```yaml
- name: read-plate
  forEach:
    item: well
    in: ${{ range(1, 97) }}
  guard: ${{ data.latest("plate-reader", self.well) }}
  task:
    modelName: plate-reader
    method: read-single-well
```

On resume, each iteration's guard evaluates independently — completed wells are
skipped, failed/unstarted wells execute.

### Error handling

A CEL parse error or runtime error in a guard expression fails the step. Guard
errors are not silently swallowed — they produce a `step_failed` event with the
error message.

### Events and rendering

Guard-skipped steps emit a `step_skipped` event with `reason: "guarded"` (vs
`"dependency"` for dependency skips). The event includes `guardExpression` (the
raw CEL expression string) and `guardResult` (the evaluated value) so consumers
can display why the step was skipped.

Console output shows the guard expression inline:

```
   main │ skipped (guarded) · guard: data.latest("checker", "result").attributes.exitCode == 0
```

JSON output includes both fields:

```json
{"step":"do-work","job":"main","status":"skipped","reason":"guarded","guardExpression":"data.latest(\"checker\", \"result\").attributes.exitCode == 0","guardResult":true}
```

Debug-level logging (`--log-level debug`) emits guard evaluation results for both
skipped and non-skipped steps, showing the expression and its result.

## Data Output Overrides with Vary Dimensions

Steps can declare `vary` on `dataOutputOverrides` to produce
environment-isolated data storage. The `vary` field lists input key names whose
values are appended to the data instance name, creating composite names like
`result-prod` or `result-dev-us-east-1`.

### Syntax

```yaml
steps:
  - name: scan-${{ self.env }}
    forEach:
      item: env
      in: ${{ inputs.environments }}
    task:
      type: model_method
      modelIdOrName: scanner
      methodName: execute
      inputs:
        environment: ${{ self.env }}
    dataOutputOverrides:
      - specName: result
        vary:
          - environment
```

### On-Disk Layout

With `environments: ["dev", "staging", "prod"]`, the above produces:

```
data/scanner/{id}/
  result-dev/
    1/content.json
    latest → 1
  result-staging/
    1/content.json
    latest → 1
  result-prod/
    1/content.json
    latest → 1
```

Each environment gets its own versioning and `latest` marker, preventing
cross-environment data interleaving.

### Accessing Varied Data

Use the 3-argument form of `data.latest()` to dynamically access varied data,
typically from a forEach step or via workflow inputs:

```yaml
# In a forEach step, use the iteration variable:
inputs:
  scanResult: ${{ data.latest('scanner', 'result', [self.env]).attributes.count }}

# Or use a workflow input:
inputs:
  scanResult: ${{ data.latest('scanner', 'result', [inputs.environment]).attributes.count }}
```

See [Expressions](../enablers/expressions.md) for the full vary dimensions syntax.

## Pre-flight Check Control

Workflow runs support the same pre-flight check skip options as direct model
method invocations. These flags apply to all model method steps in the workflow:

| Flag                         | Behavior                                   |
| ---------------------------- | ------------------------------------------ |
| `--skip-checks`              | Skip all pre-flight checks                 |
| `--skip-check <name>`        | Skip a specific check by name (repeatable) |
| `--skip-check-label <label>` | Skip all checks with a label (repeatable)  |

Check skip options are threaded from the CLI through `WorkflowRunInput` →
`StepExecutionContext` → `MethodContext`, ensuring consistent behavior with
`swamp model method run`.

## Workflow Runs

When a workflow is run, it executes the jobs and steps in the correct order. The
order should be topologically sorted for dependencies, and weighted so it does
not vary between identical inputs. (If the inputs are identical, the run order
should be deterministic.)

The output of the run will be written to a workflow run log, kept in the
datastore at `workflow-runs/{workflow-uuid}/workflow-run-{run-uuid}.yaml`
(default path: `.swamp/workflow-runs/`).

### Run Statuses

- `pending` — created but not yet started
- `running` — actively executing jobs/steps
- `suspended` — paused at a manual approval gate
- `succeeded` — all jobs completed successfully
- `failed` — at least one job failed or an error occurred
- `cancelled` — explicitly cancelled by a user (runs orphaned by a serve
  restart are marked `failed`, see below)

### Cancellation

Runs can be cancelled via `swamp workflow cancel <workflow> [--run <runId>]`.
When `swamp serve` is running, the cancel command sends a request to the serve
cancel API (`POST /api/v1/cancel/workflow-run/<id>`), which fires the
AbortController for live cancellation. When serve is not running, the command
writes the cancelled status directly to the run YAML (offline cancel).

`swamp workflow cancel --all` cancels all active runs across all workflows.
With `--server`, `--run <id>` is required, `--all` is rejected, and `--reason`
is ignored (the cancel endpoint accepts no reason;
`src/cli/commands/workflow_cancel.ts`).

On daemon restart, `swamp serve` automatically reaps orphaned runs left in
`running` state by the previous process (`reapOrphanedWorkflowRuns` in
`src/cli/commands/serve.ts`): each is interrupted via
`run.interrupt("server_crash")` (`src/domain/workflows/workflow_run.ts`), which
marks in-flight steps and the run **`failed`** and tags the run with
`interrupt_reason: server_crash`. "daemon restarted" appears only in the log
line explaining why the run was reaped.

A `RunCancelRegistry` in the serve layer centralises AbortController tracking
across all execution paths (scheduled, WebSocket ad-hoc, webhook). The cancel
API checks both the registry and the `ScheduledExecutionService` running map.

The same mechanism applies to model method runs via
`swamp model cancel <model> [--all] [--reason <reason>]`.

### Post-Cancellation Cleanup

When a workflow is cancelled (via `--timeout`, Ctrl+C, or `swamp workflow
cancel`), steps with `always` or `completed` dependency conditions still run.
This allows cleanup branches (notifications, resource teardown, metric
reporting) to execute even after cancellation.

The execution engine evaluates remaining steps in topological order after
cancellation:

- Steps whose dependency conditions are met (`always` returns true
  unconditionally; `completed` returns true when the dependency reached
  `succeeded` or `failed`) run with a fresh 30-second cleanup signal.
- Steps whose conditions are not met (`succeeded` on a failed dependency) are
  skipped.
- In-flight steps interrupted by the cancellation signal are marked `failed`
  with reason `cancelled`.

The same behavior applies after normal step failure (without cancellation):
steps with `always` or `completed` conditions in subsequent topological levels
run instead of being skipped.

The `--timeout` flag kills in-flight subprocesses (SIGTERM) when the deadline
elapses, then runs cleanup steps. It does not wait for the subprocess to finish
before marking it failed.

## Domain Events

The WorkflowRepository and WorkflowRunRepository emit domain events:

**Workflow Events:**

- `WorkflowCreated` - Emitted when a new workflow is created via
  `workflow create`
- `WorkflowUpdated` - Emitted when a workflow definition is modified
- `WorkflowDeleted` - Emitted when a workflow is deleted

**WorkflowRun Events:**

- `WorkflowRunStarted` - Emitted when `workflow run` begins execution
- `WorkflowRunCompleted` - Emitted when a workflow run completes successfully
- `WorkflowRunFailed` - Emitted when a workflow run fails

The RepoIndexService subscribes to these events (currently a noop
implementation). See [repo](../surfaces/repo.md) for details on domain events.

## Per-Method Telemetry

A workflow run emits one parent telemetry entry for the outer
`swamp workflow run` invocation plus one child entry per workflow YAML step
that resolves to a model method. Children are linked to the parent through
`parentInvocationId` and carry a `workflowContext` block:

```yaml
workflowContext:
  workflowName: deploy
  runId: <workflow-run-uuid>
  jobName: build
  stepName: validate-config
  modelType: command/shell
  executor: loopback
```

Children use the same `cli_invocation` event shape as a direct
`swamp model method run <name> <method>` invocation, with the same
redactions: `command="model"`, `subcommand="method"`,
`args=["run", "<REDACTED>", <methodName>]`. Analytics that aggregate by
command/method roll up direct invocations and workflow-internal
invocations uniformly; per-executor and per-model-type queries read
`workflowContext` directly without joining through the parent.

### Failure Semantics

- A step that fails AFTER `method_executing` was yielded records an error
  child entry with the actual duration.
- A step that fails BEFORE `method_executing` (model lookup failure, vault
  expression resolution failure, vary-key validation failure, env-var
  validation) records a synthesized child entry with `durationMs = 0` —
  the method was never actually invoked, so duration is honestly zero.
  Dashboards that filter zero-duration entries will hide
  failure-by-validation cases by design.
- A step with `allowFailure: true` records as `error` in the child entry
  (the method outcome) while the parent records its overall workflow
  outcome — `success` if all unallowed failures were absent. Joining
  `child.error_category × parent.success` on `parentInvocationId` surfaces
  "how many allowed failures" without changing the entry shape.

### V1 Limitations

- **Workflow-step granularity only.** Sub-method follow-up calls inside
  `DefaultMethodExecutionService.execute` (e.g. one method that internally
  invokes another method) are NOT captured as separate child entries; the
  workflow-step boundary is the unit of measurement.
- **Workflow-task steps** (a step whose task is a nested workflow) emit no
  child entry of their own. The nested workflow's own model-method steps
  generate child entries linked to the same parent CLI invocation.
- **Failures before workflow validation** (e.g. workflow not found, input
  schema validation) produce no child entry — no method was ever resolved.
- **Cancellation** during a method invocation (AbortSignal, timeout)
  records the in-flight method as an error child entry via the bridge's
  finalize path with a synthetic "workflow run terminated before
  completion" message.

The bridge lives in `src/libswamp/workflows/telemetry_bridge.ts`. The
domain `step_failed` event carries optional `modelName` and `methodName`
fields populated only at the model-method failure site (other yield
sites — nesting depth, cycle detection, nested-workflow failure — leave
them undefined so the bridge can distinguish structural failures from
method failures).

### Runs Executed by `swamp serve`

Scheduled, webhook, and API-triggered runs record the same parent and child
entries as an interactive `swamp workflow run`, with two differences.

**The parent is the run, not the process.** The CLI allocates one invocation
id per process, because for a CLI one process is one invocation. A daemon
breaks that assumption: its own process-level entry is not written until it
exits, possibly weeks later, so hanging children off it would leave every
child with a dangling `parentInvocationId` for the daemon's entire uptime.
Each serve-executed run therefore forks its own service
(`TelemetryService.forkForRun`) and records a per-run parent shaped like the
`swamp workflow run` invocation it stands in for, with the workflow name
redacted exactly as the CLI redacts it.

**Entries carry a `triggerSource`** of `schedule`, `webhook`, or `api`.
Interactive runs leave the field unset, so their events are unchanged. The
field is deliberately not called `source`: the telemetry backend derives a
field by that name from the recorded command, and overloading it would
collide two independently-owned concerns.

Because a run reports failure through its event stream rather than by
throwing — input validation, a failed step, and cancellation all return
normally — the outcome is read from the stream. A run that did not reach
`succeeded` records an error parent, which matters because only successful
invocations are counted downstream.

The composition lives in `src/serve/telemetry.ts`; the sink is threaded
through `executeWorkflowWithLocks` in `src/serve/deps.ts`, which is the
single path all three trigger types share. Callers that supply no trigger
source (libswamp consumers, tests) produce no telemetry at all.
