---
audience: maintainer, extension-author
last-verified: 2026-08-28 @ 3d5955a9
---

# Models

A model in swamp is defined by a _type_. They are instantiated by creating a
_definition_, whose global arguments can be set statically or dynamically
through _inputs_. An instantiated _model_ can be used through calling _methods_,
which _output_ their results and can store _resources_ and _files_. Each method
also declares its own _arguments_ schema, and at execution time receives the
merged set of global arguments and per-method arguments. Resources are
structured data with a schema, and files are raw content with a content type.
Both are immutable, have a _lifetime_, can be _tagged_ with capabilities, and
store the _definition_ that created it (so the model can be instantiated from
the data it produces). Data produced by a model can only be written again by an
instantiated model with the same definition as the original data.

## Type

All models in swamp are of a unique _type_. Types are defined by the thing that
they model - for example, a swamp model to manage AWS VPCs using the Cloud
Control API would be named 'AWS::EC2::VPC', because that is what the cloud
control api calls it. They should map semantically to the domain.

They _must_ include a domain identifier at the start of the type. For example:

AWS: AWS::EC2::VPC, AWS::Budget::Budgets Docker CLI: docker run, docker pull
Azure: Microsoft.Resources/resourceGroup

Each type also has a normalized representation, where special characters are
mapped into directory structures like 'aws/ec2/vpc' or 'docker/run' or
'microsoft/resources/resourceGroup'.

## ID

Each instance of a model has a unique ID that is a uuidv4.

## Version

Each model has a version using **CalVer** format `YYYY.MM.DD.MICRO` (e.g.,
`"2025.01.15.1"`, `"2025.06.01.3"`). The micro counter allows multiple version
bumps per day and resets for each new date.

Version comparison splits on `.`, compares the first three segments as
zero-padded strings, and the fourth as a number. This is implemented as the
`CalVer` value object in `src/domain/models/calver.ts`.

Models must support data written by all earlier versions, but not later
versions.

## Migration

A model can migrate its definitions from one version to the next using **upgrade
functions**. Each model declares an ordered list of `VersionUpgrade` entries,
one per version transition. When a definition's `typeVersion` is behind the
model's current `version`, the upgrade chain runs all applicable upgrades in
order, transforming global arguments at each step.

Upgrades are **lazy** — they run at method execution time in
`DefaultMethodExecutionService.executeWorkflow()`
(`src/domain/models/method_execution_service.ts`) via
`DefinitionUpgradeService` (`src/domain/models/definition_upgrade_service.ts`),
not at load time. The upgraded definition is persisted so the upgrade only runs
once.

### Upgrade Rules

- Upgrades must be ordered chronologically by `toVersion`
- The last upgrade's `toVersion` must equal the model's current `version`
- Upgrade functions are pure global argument transforms (old args → new args)
- Upgrades are forward-only; there is no downgrade path

### Example

A model starts at version `"2025.01.15.1"` with just a `message` global
argument. On `"2025.06.01.1"`, a `priority` field is added with a default. On
`"2026.02.09.1"`, the `message` field is renamed to `content`:

```typescript
import { z } from "zod";

export const model = {
  type: "acme/notifier",
  version: "2026.02.09.1",
  globalArguments: z.object({
    content: z.string().min(1),
    priority: z.enum(["low", "medium", "high"]),
  }),
  upgrades: [
    {
      toVersion: "2025.06.01.1",
      description: "Add priority field with default 'medium'",
      upgradeAttributes: (old) => ({ ...old, priority: "medium" }),
    },
    {
      toVersion: "2026.02.09.1",
      description: "Rename 'message' to 'content'",
      upgradeAttributes: (old) => {
        const { message, ...rest } = old;
        return { ...rest, content: message };
      },
    },
  ],
  methods: {
    send: {
      description: "Send a notification",
      arguments: z.object({}),
      execute: async (args, context) => {
        const globalArgs = context.globalArgs;
        const handle = await context.writeResource("result", "result", {
          sent: true,
          content: globalArgs.content,
          priority: globalArgs.priority,
        });
        return { dataHandles: [handle] };
      },
    },
  },
};
```

If a definition was created at `"2025.01.15.1"` with `{ message: "hello" }`, and
the model is now at `"2026.02.09.1"`, running a method will:

1. Apply upgrade to `"2025.06.01.1"`: `{ message: "hello", priority: "medium" }`
2. Apply upgrade to `"2026.02.09.1"`: `{ content: "hello", priority: "medium" }`
3. Persist the definition with `typeVersion: "2026.02.09.1"` and new global
   arguments
4. Execute the method with the merged arguments (global + per-method)

### Backwards Compatibility

Existing definitions on disk with numeric `typeVersion` (e.g., `typeVersion: 1`)
are automatically coerced to `undefined` by the `DefinitionSchema`
(`z.preprocess` in `src/domain/definitions/definition.ts`), meaning
"pre-CalVer, needs upgrade from earliest version". They will be upgraded on
first method execution and persisted with the new CalVer `typeVersion`.

## Definitions

There are two ways to create a definition:

### Direct Instantiation (`model create`)

Use this when you want to manage values in the definition file. Global arguments
are baked into the YAML, edited with `model edit`, and version-controlled in
git. Good for: static configuration that rarely changes, definitions that use CEL
expressions in global arguments, definitions shared across multiple workflow
steps.

These definitions live in the top-level `models/` directory of a repository,
underneath the normalized type as a directory. The file name is `<name>.yaml`
when the definition name is filename-safe — for example
`models/aws/ec2/vpc/my-vpc.yaml`. Names that are not filename-safe fall back
to the legacy `${id}.yaml` form (`resolveWritePath` in
`src/infrastructure/persistence/yaml_definition_repository.ts`).

### Direct Type Execution (recommended starting point)

Use this when everything comes from `--input` at runtime. The definition is
auto-created as a byproduct, not as a deliberate configuration act. Good for:
scripts, CI pipelines, one-shot CLI invocations, and workflow steps where all
values are dynamic.

**CLI syntax:**

```sh
swamp model @swamp/aws/ec2/vpc method run create my-vpc \
  --input region=us-east-1 --input cidr=10.0.0.0/16
```

**First run:** The definition `my-vpc` doesn't exist yet. Swamp auto-creates it
with type `@swamp/aws/ec2/vpc` and executes `create`. The `--input` values are
automatically routed between global arguments and method arguments using the
type's schemas (method arguments take precedence on ambiguous keys).

**Subsequent runs:** Finds `my-vpc`, verifies its type matches
`@swamp/aws/ec2/vpc` (safety check), and runs. If the routed global arguments
differ from the stored definition, the definition is updated and persisted
automatically — this ensures parameterized workflows that vary inputs per run
always use the current values.

**Storage:** Auto-created definitions live in `.swamp/auto-definitions/` (not
`models/`). They exist for data ownership boundaries — giving model data a home
without requiring a hand-authored definition file. They are local runtime state,
not git-tracked, and do not appear in `swamp model search` results (by design).
They are findable by name for `model get`, `model method run`, and workflow
references. `model get` shows `Auto-created: yes` for these definitions.

### Choosing Between the Two

| Question                                        | Direct Instantiation | Direct Type Execution |
| ----------------------------------------------- | -------------------- | --------------------- |
| Do you manage values in the definition file?    | Yes                  | No                    |
| Are values passed at runtime via `--input`?     | Sometimes            | Always                |
| Is the definition git-tracked?                  | Yes                  | No                    |
| Visible in `model search`?                      | Yes                  | No                    |
| Stored in                                       | `models/`            | `.swamp/auto-definitions/` |

### Definition Properties

The valid shape of a definition is specified with a Zod 4 schema as part of the
type.

Each definition has the following core properties:

- id: the models unique id
- name: a unique human readable name
- tags: string based key value pairs
- globalArguments: domain specific data shared across all methods (for example,
  the specific properties of a VPC from above).

### Input

A definition file can also specify custom inputs as JsonSchema serialized to
yaml. By default, every definition has optional inputs that map to the full set
of defined global arguments of the definition. If a type specifies that a
particular global argument is required, but it is not present in the static
definition, then it is a required input. If it is present in the definition,
then it will be optional (and can be over-ridden by an input.)

Custom input values can be accessed through CEL expressions.

## Instance

A model is instantiated by feeding its definition to the models constructor. The
models definition is hashed to provide an instantiation id. From the
instantiation id and a record of the definition, a model can always be
re-instantiated.

We call this an instance of a model.

## Methods

Methods can be called on instantiated models. Each method declares a required
`arguments` Zod schema for its per-method arguments. At execution time, the
method's `execute` function receives the merged arguments (global arguments from
the definition combined with per-method arguments) as its first parameter, and a
`MethodContext` as its second. The `MethodContext` includes `globalArgs`,
`definition` metadata (id, name, version, tags), `methodName`, and an optional
`redactor` (`SecretRedactor`) for stripping vault secrets from output.

When the method's `arguments` schema is a `z.record()` (rather than
`z.object()`), global arguments are **not** merged into the method args — the
method receives only the per-method arguments. This prevents global argument
fields from leaking into the open-ended record. Global arguments remain
accessible via `context.globalArgs`.

Methods can write data, which is tracked by the method invocation and the
definition required to re-instantiate the object.

Each method invocation records its status in an output, which records any data
that was written in the invocation, status, and information about how it was
called.

Methods can also instantiate a model, from either an existing definition by name
or by supplying the definiton directly, then can invoke methods on those models.
This is implemented via `context.runModel()`.

### Cross-Model Invocation (`context.runModel`)

`context.runModel(options)` lets a model method invoke another model's method
during its own execution and use the result inline. Two calling conventions:

```typescript
// Call an existing definition by name
const result = await context.runModel({
  definition: "my-vpc",
  method: "read",
});

// Direct type execution (auto-creates definition)
const result = await context.runModel({
  modelType: "aws/ec2/vpc",
  name: "my-new-vpc",
  method: "create",
  arguments: { cidrBlock: "10.0.0.0/16" },
});
```

Returns a discriminated result:

- `{ ok: true, resources: DataHandle[] }` on success
- `{ ok: false, error: { message, stack? } }` on failure

**Argument routing:** The `arguments` object is routed between globalArguments
and method arguments using the target type's Zod schemas — the same mechanism as
CLI `--input`. Method arguments take precedence on ambiguous keys. Unknown keys
return `{ ok: false }`. For direct type execution, only global-arg values are
persisted in the auto-created definition; method-arg values are applied
ephemerally for that invocation.

**Data ownership:** When model X calls model Y, Y's data writes scope to Y's
definition, not X's. This is consistent regardless of whether Y was run
standalone, from a workflow, or from inside X.

**Failure semantics:** Y's failure surfaces as `{ ok: false }` to X. X decides
how to handle it. Already-persisted data from both X and Y stays.

**Depth and cycle limits:** Maximum 10 levels deep (matching workflow nesting).
Cycles are detected via an ancestor chain tracking `(modelType, method)` pairs.
Maximum 100 total `runModel` calls per top-level execution (matching follow-up
action limits).

**Vault isolation:** The caller's `VaultSecretBag` does not propagate to the
nested model. Each nested execution resolves its own vault expressions.

**Runtime authorization:** Extension models must declare dependencies in
`manifest.yaml` to invoke models from other extensions. Built-in types and
user-authored models are unrestricted. Same-extension calls are always allowed.
Unauthorized calls return `{ ok: false }` with an actionable error message.

**Remote execution:** `context.runModel()` is not available in remote worker
contexts. Models that need cross-model invocation should run locally or use a
workflow for orchestration.

**Output lineage:** Nested invocations produce `ModelOutput` records with
`triggeredBy: "model"`, `parentOutputId` pointing to the caller's output, and
`callerExtension` for provenance tracking.

### Execution Identity

Every method execution records `bundleFingerprint` on `ExecutionProvenance` —
the SHA-256 source fingerprint of the extension bundle that produced the output.
This is the one piece of execution identity that only core can provide:
`definitionHash` and `modelVersion` already cover the definition content and
type version, but neither proves which _code_ actually ran.

The field is optional — old outputs without it parse correctly, and built-in
model types (which have no extension bundle) leave it undefined. A lifecycle
consumer can persist the fingerprint alongside evidence and compare against the
current invocation to determine whether an interrupted run can safely resume.

### Workflow Gate Control (`context.approveWorkflowGate`, `context.rejectWorkflowGate`)

`context.approveWorkflowGate(options)` and `context.rejectWorkflowGate(options)`
let a model method programmatically approve or reject a suspended workflow's
`manual_approval` gate without shelling out to a child `swamp` process. This
enables webhook-driven approvals, scheduler-driven gates, and other in-process
automation.

```typescript
// Approve a suspended gate
const result = await context.approveWorkflowGate({
  workflowIdOrName: "deploy-pipeline",
  stepName: "prod-approval",
  reason: "Approved via Linear webhook",
});

// Reject a gate
const result = await context.rejectWorkflowGate({
  workflowIdOrName: "deploy-pipeline",
  stepName: "prod-approval",
  reason: "Reviewer rejected",
});
```

Returns a discriminated result:

- `{ ok: true, runId, workflowName, stepName, approved, decidedBy }` on success
- `{ ok: false, error: { message } }` on failure

**Approve** marks the step as succeeded and saves the run. The workflow remains
suspended until explicitly resumed via `swamp workflow resume`.

**Reject** marks the step as failed, fails the job, and completes the run as
failed. No resume is needed.

**`decidedBy` is auto-populated** from the calling model's definition name and
method name (e.g. `model:webhook-handler/on_comment`). Extensions cannot
override this value — it is enforced for audit integrity.

**Remote execution:** Not available in remote worker contexts. Returns
`{ ok: false }` with an actionable error message.

## Pre-flight Checks

Pre-flight checks are optional guards that run automatically before any
_mutating_ method invocation. A method's kind is its explicit `kind` field or,
when omitted, inferred from its name by `inferMethodKind()`
(`src/domain/models/model.ts`): `create`; `get`/`read`/`describe`/`show` →
`read`; `update`/`patch` → `update`; `delete`/`destroy`/`remove` → `delete`;
`list`/`search`/`find` → `list`. The `read` and `list` kinds do not trigger
checks; every other kind does. Method names not in the recognized list (e.g.
`sync`) infer no kind and therefore default to mutating — set `kind: "read"`
or `kind: "list"` explicitly to suppress checks for those.

Checks give models a way to enforce invariants — policy constraints, dependency
readiness, quota availability — before execution begins, avoiding
half-completed operations.

### CheckDefinition

Each check is declared as a named entry in the model's optional `checks` field
(`checks?: Record<string, CheckDefinition>`):

```typescript
interface CheckDefinition {
  description: string;
  labels?: string[];
  appliesTo?: string[];   // method names; if omitted, applies to all mutating methods
  execute: (context: MethodContext) => Promise<CheckResult>;
}

interface CheckResult {
  pass: boolean;
  errors?: string[];
}
```

The `execute` function receives the same `MethodContext` as a method's execute
function, with two differences:

- `writeResource` and `createFileWriter` are **not available**. Checks inspect
  state only — they do not produce data output.
- `unresolvedMethodArgs` **is populated** with the method's arguments merged over
  filtered global arguments (global args containing unresolved `${{ }}`
  expressions are excluded). This lets per-method checks validate that required
  arguments are present before execution begins.

```typescript
// Example: validate a method argument in a pre-flight check
checks: {
  "spec-required": {
    description: "Forward requires a spec argument",
    appliesTo: ["forward"],
    execute: async (context) => {
      if (!context.unresolvedMethodArgs?.spec) {
        return { pass: false, errors: ["forward requires a `spec`"] };
      }
      return { pass: true };
    },
  },
},
```

### isMutatingKind

The `isMutatingKind(kind: MethodKind | undefined)` helper
(`src/domain/models/model.ts:733`) takes the method's kind — not its name —
and returns `true` for everything except `"read"` and `"list"`, including
`undefined` (unrecognized names). This is used internally to decide whether to
run checks.

### Labels and appliesTo

**Labels** categorize checks for selective skipping. Common conventions:

- `policy` — business rules and constraints (value validation, allowed values)
- `live` — checks that make live API calls (quota, existence checks)
- `dependency` — cross-model dependency validation (required upstream state)

**appliesTo** limits a check to specific methods. If omitted, the check runs
before all mutating methods. Use this to scope expensive or irrelevant checks:

```typescript
// Only validate quota before create, not before update or delete
appliesTo: ["create"],
```

### Skip Options

Users can bypass checks at runtime using CLI flags on `model method run`:

| Flag                         | Behavior                                   |
| ---------------------------- | ------------------------------------------ |
| `--skip-checks`              | Skip all pre-flight checks                 |
| `--skip-check <name>`        | Skip a specific check by name (repeatable) |
| `--skip-check-label <label>` | Skip all checks with a label (repeatable)  |

### Three Common Patterns

1. **Value/policy validation** — inspect `context.globalArgs` for invalid or
   disallowed values. No I/O. Always fast.

2. **Cross-model validation** — use `context.readModelData(modelName)` to read
   stored state from another model instance by name and verify a dependency
   exists or is in the right state. Note: `context.dataRepository` methods
   (`findAllForModel`, `getContent`) require a UUID, not a model name.

3. **Live API checks** — call an external API to verify quota, existence, or
   reachability. Label these `live` so users can skip them in offline
   environments.

### Extension Checks

Extensions can add checks to existing model types via the optional third
parameter of `modelRegistry.extend()`:

```typescript
modelRegistry.extend("aws/ec2/vpc", {}, {
  "no-cidr-overlap": {
    description: "Ensure CIDR does not overlap",
    labels: ["policy"],
    execute: async (context) => { return { pass: true }; },
  },
});
```

Check name conflicts with checks already defined on the target type throw an
error at registration time. Extension checks follow the same `CheckDefinition`
interface and participate in all check selection mechanisms.

### Definition-Level Check Selection

Definition authors can control which checks run via a `checks` field in the
YAML definition:

```yaml
checks:
  require:
    - no-cidr-overlap
  skip:
    - slow-api-check
```

- **`require`** — checks listed here are immune to `--skip-checks`,
  `--skip-check <name>`, and `--skip-check-label <label>` CLI flags. They still
  respect `appliesTo` method scoping.
- **`skip`** — checks listed here are always skipped. `skip` wins over `require`
  if the same check appears in both.
- Validation (`model validate`) warns on require/skip overlap and errors if a
  referenced check does not exist on the model type.

### model validate Integration

`swamp model validate` runs checks as part of the validation pipeline. It runs
all checks regardless of `appliesTo` — ensuring validate surfaces the same
errors that method execution would. It honors definition-level `skip` lists in
addition to CLI flags. Two flags narrow check execution:

- `--label <label>` — only run checks matching this label
- `--method <method>` — only run checks that apply to this method (skips checks
  whose `appliesTo` excludes the given method)

## Data

Models produce two kinds of output data: **resources** and **files**.

### Resources

Resources are structured data with a Zod schema. They represent external
resource state, API responses, or any structured output. Resources are declared
in the model's `resources` field and written with `context.writeResource()`.

Resources are auto-tagged with `type: "resource"`.

### Files

Files are raw content with a content type (MIME type). They represent file
artifacts, logs, or any binary/text output. Files are declared in the model's
`files` field and written with `context.createFileWriter()`. Files can optionally
be marked as `streaming: true` for line-oriented output (replacing the old
dedicated log type).

Files are auto-tagged with `type: "file"`.

### Common Properties

Both resources and files share these properties:

- A unique name (the spec name, declared in `resources` or `files`)
- A unique id for the data
- The full definition of the model that wrote the data, so we can re-instantiate
  a model to operate on the data
- A lifetime, which defines how long the data should persist. Lifetimes can be
  expressed as a duration string (1h, 5m, 10d, 1mo, 10y). A lifetime of
  "ephemeral" means the data will only be stored for the duration of a method
  invocation or workflow execution. A lifetime of "infinite" will store the data
  forever. There are two special lifetimes, which are:
  - Job: the data persists only while the job that create it exists/is running
  - Workflow: The data persists until the workflow that created it exists/is
    running
- A garbage collection setting, which defines how many versions should be
  stored. This has the same values as lifetime, but can also accept a raw
  integer that specifies a specific number.
- A set of tags, which are used to mark data for human indexing and retrieval
  later.

Data is immutable. Each write to the same spec name creates a new version of
the data. The latest version can always be referred to as "latest". When used in
a CEL expression, "latest" is implied. Old versions can only be retrieved by a
CEL function. Versions will be auto-incrementing integers, starting at 1.

Data can only be written by a model instantiated from the same definition that
originally wrote the data. This is called the _owner_ of the data.

The raw data will be written to the datastore at
`data/{normalized-type}/{model-id}/{data-name}/{version}/raw` (default path:
`.swamp/data/{normalized-type}/{model-id}/{data-name}/{version}/raw`).

The metadata will be written to the datastore at
`data/{normalized-type}/{model-id}/{data-name}/{version}/metadata.yaml`.

The latest version is tracked by a plain text marker file at
`data/{normalized-type}/{model-id}/{data-name}/latest` containing the version
number (e.g. `2`).

See [datastores.md](../enablers/datastores.md) for how the datastore path is resolved.

## Data Output API

Methods write data during execution using two APIs on the method context:
`writeResource()` for structured resources and `createFileWriter()` for file
artifacts. Data is written directly to disk and the method returns lightweight
`DataHandle` references.

### Writing Resources

Use `context.writeResource(specName, name, data, overrides?)` to write structured
resource data. Returns a `Promise<DataHandle>`.

```typescript
execute: async (args, context) => {
  const handle = await context.writeResource("result", "result", {
    result: "processed value",
  });
  return { dataHandles: [handle] };
};
```

### Writing Files

Use `context.createFileWriter(specName, name, overrides?)` to get a `DataWriter` for
file output.

```typescript
execute: async (args, context) => {
  const writer = context.createFileWriter("execution-log", "execution-log");
  const handle = await writer.writeText("Step 1 completed\nStep 2 completed\n");
  return { dataHandles: [handle] };
};
```

### Writer Methods (for `createFileWriter`)

| Method                      | Description                                      |
| --------------------------- | ------------------------------------------------ |
| `writeAll(content)`         | Write complete binary content (`Uint8Array`)     |
| `writeText(text)`           | Write text content (encoded as UTF-8)            |
| `writeLine(line)`           | Append a single line (for streaming/incremental) |
| `writeStream(stream, opts)` | Pipe a `ReadableStream<Uint8Array>`              |
| `getFilePath()`             | Get the file path for direct I/O                 |
| `finalize()`                | Finalize after using `writeLine`/`getFilePath`   |

### DataHandle

Lightweight reference to data already persisted:

| Field      | Description                               |
| ---------- | ----------------------------------------- |
| `name`     | Data artifact name                        |
| `specName` | The spec name from `resources` or `files` |
| `kind`     | `"resource"` or `"file"`                  |
| `dataId`   | Unique ID for this data                   |
| `version`  | Version number of this write              |
| `size`     | Size of the written content in bytes      |
| `tags`     | Tags from the writer options              |
| `metadata` | Full metadata for the data artifact       |
| `attributes` | Top-level resource attributes (resource kind only, optional) |

### Write Atomicity (rollbackOnFailure)

By default, `writeResource()` and `createFileWriter()` commit each write
immediately — the `latest` marker advances and the data is visible to
`data.latest()` consumers. If a method fails midway, earlier writes persist.

Methods can opt into all-or-nothing write semantics by setting
`rollbackOnFailure: true` on the method definition:

```typescript
methods: {
  readAll: {
    description: "Read all 96 wells",
    rollbackOnFailure: true,
    arguments: z.object({}),
    execute: async (args, ctx) => {
      for (const well of wells) {
        await ctx.writeResource("reading", well, await instrument.read(well));
      }
      return {};
    },
  },
}
```

When `rollbackOnFailure` is true, writes use deferred-latest mode:

1. **During execution**: Data persists to disk but the `latest` marker is not
   advanced. The catalog row is written with `is_latest=0`. Concurrent readers
   calling `data.latest()` see the previous version (or nothing).
2. **On success**: All `latest` markers advance and catalog rows flip to
   `is_latest=1`. Data becomes visible atomically.
3. **On failure**: Version directories are deleted and catalog rows are removed.
   No trace of the failed writes remains.

The deferred-latest approach has no TOCTOU window — markers are never advanced
during execution, so there is nothing to roll back on failure.

**When NOT to use**: Methods that interact with external systems and write data
reflecting real-world state should not set this flag. Their writes may be the
most accurate picture of reality even if the method fails partway. Methods that
deliberately write-then-throw (e.g. a code-review model that writes results
then throws on verdict=FAIL) must also leave this flag unset.

## Output

Each method invocation produces an output record, which gets tracked in the
datastore `outputs/` directory (default `.swamp/outputs/`, not tracked in git).
The output record should track the state of the method execution, and the list
of artifacts produced by the method. It should track state as the method
executes. It should be structured as
`outputs/{normalized-type}/{method}/{definition-id}-{timestamp}.yaml`.

## Domain Events

The ModelRepository emits domain events when model data changes:

- `ModelCreated` - Emitted when a new model definition is created via
  `model create`
- `ModelUpdated` - Emitted when a model definition or data is modified
- `ModelDeleted` - Emitted when a model is deleted

A `NoopRepoIndexService` is instantiated but not wired to the event bus —
no handler currently receives these events. See [repo.md](../surfaces/repo.md) for
details on domain events.
