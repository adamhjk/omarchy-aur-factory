---
audience: maintainer
last-verified: 2026-08-28 @ 3d5955a9
---

# Skill Lifecycle

This document describes how skills are authored, tested, and shipped through CI.

## Overview

A skill gives Claude specialized knowledge about a specific domain. At runtime,
skills work through progressive disclosure:

- Claude always sees every skill's `name` and `description` in the system prompt
- When a user query matches a skill's description, Claude loads the full
  `SKILL.md` body into context
- If the skill references detailed docs in `references/`, Claude loads those on
  demand as needed

This means the `description` field is the single most important part of a
skill — it's the trigger mechanism that decides whether Claude engages the skill
at all.

Skills live in `.claude/skills/<skill-name>/` and follow a three-phase lifecycle:

1. **Author** — create the skill following skill-creator conventions
2. **Test** — validate quality (tessl) and trigger routing (promptfoo)
3. **Ship** — CI gates enforce quality before merge

Authoring and testing are iterative — after using a skill on real tasks, you
refine the description, body, or evals based on what worked and what didn't.

## Authoring a Skill

Always load the `skill-creator` skill before creating or modifying a skill — it
is the authoritative guide for structure and best practices.

### Directory Structure

```
.claude/skills/<skill-name>/
├── SKILL.md              # Required — uppercase, contains frontmatter + body
├── references/           # Optional — detailed docs loaded on demand
│   └── *.md
└── evals/                # Optional — evaluation test cases
    ├── trigger_evals.json           # Phase 1 — does this skill trigger?
    ├── routing_evals.json           # Phase 2 — which guide does it load?
    └── guide_sufficiency_evals.json # Phase 3 — is the guide enough?
```

Only gateway skills with a `references/<topic>/guide.md` tree (currently
`swamp`) need the phase 2 and phase 3 files.

### SKILL.md

**Frontmatter** (required YAML between `---` fences):

- `name` — hyphen-case identifier, must match directory name, max 64 chars
- `description` — what the skill does AND when to trigger it. This is the
  primary mechanism Claude uses to decide whether to load the skill, so include
  specific trigger phrases and contexts. Max 1024 chars.

No other frontmatter fields (except optional `license`).

**Body** guidelines:

- Keep under 500 lines — split detailed content into `references/` files
- Use imperative form ("Use this for…", "To create…")
- Do not duplicate "when to use" guidance that belongs in the description
- Run `deno fmt` after editing

### Progressive Disclosure

Skills load in three tiers to manage context efficiently:

1. **Metadata** (name + description) — always in context (~100 words)
2. **SKILL.md body** — loaded when the skill triggers (<5k words)
3. **References** — loaded on demand by Claude as needed (unlimited)

Keep only core workflow and selection guidance in SKILL.md. Move variant-specific
details, API references, and lengthy examples into `references/`.

## Writing Trigger Evals

Trigger evals define test cases that verify Claude routes user queries to the
correct skill. They live at
`.claude/skills/<skill-name>/evals/trigger_evals.json`.

### Format

```json
[
  {
    "query": "Search for model types that handle payments",
    "should_trigger": true,
    "note": "type search is a listed trigger keyword"
  },
  {
    "query": "List all the data I have stored",
    "should_trigger": false,
    "note": "Listing stored data routes to the swamp skill (data guide), not this skill"
  }
]
```

Each entry has:

- `query` — a realistic user request
- `should_trigger` — `true` if this query should route to this skill, `false` if
  it should route elsewhere
- `note` — optional explanation of the routing decision

Write both positive and negative cases. Negative cases are important — they
verify that similar-sounding queries route to the correct neighboring skill
rather than this one.

## Writing Routing Evals

Routing evals check the _second_ hop: once the gateway skill has triggered, does
Claude load the right guide from the SKILL.md routing table? They live at
`.claude/skills/<skill-name>/evals/routing_evals.json`.

### Format

```json
[
  {
    "query": "Show me the run history for the deployment workflow",
    "expected_guide": "workflow"
  }
]
```

Each entry has:

- `query` — a realistic user request that has already reached this skill
- `expected_guide` — the directory name under `references/` whose `guide.md`
  should be loaded

Every guide topic must have at least one case. `skill_routing_test.ts` derives
the topic list from the `references/` directory on disk, so adding a new guide
without adding routing evals fails the unit test — no promptfoo run needed.

## Writing Sufficiency Evals

Sufficiency evals check the _third_ hop: given only the short `guide.md`, can
Claude answer the query, or must it descend into `reference.md`? They live at
`.claude/skills/<skill-name>/evals/guide_sufficiency_evals.json`.

### Format

```json
[
  {
    "query": "Search for model types that handle payments",
    "guide": "model",
    "answerable_from_guide": true,
    "note": "Quick Reference table has the search command"
  }
]
```

Each entry has:

- `query` — a realistic user request
- `guide` — the topic whose `guide.md` is supplied as the only context
- `answerable_from_guide` — `true` if the guide alone suffices, `false` if the
  detail lives in `reference.md` or a deeper `references/` file
- `note` — where the answer lives, which makes failures diagnosable

Balance the two outcomes per topic: `true` cases catch guides that have gone too
thin, `false` cases catch guides that have absorbed reference material they
should have delegated. Self-contained guides with no `reference.md` carry only
`true` cases.

## Testing Locally

Both testing tools require **Node.js/npm** and **Deno** installed locally. They
test fundamentally different things:

- **Tessl** answers: _"Is this skill well-written?"_ — it scores the quality of
  the SKILL.md description and content.
- **Promptfoo** answers: _"Does the LLM actually route to this skill
  correctly?"_ — it sends real queries to a model and checks which skill gets
  called.

A skill can score perfectly on tessl but still fail promptfoo if its description
overlaps with another skill. Both must pass.

### Tessl — Skill Quality Review

Tessl evaluates the structural quality of a skill's SKILL.md by scoring its
description and content.

**Review a single skill:**

```bash
npx tessl skill review .claude/skills/<skill-name> --json
```

This returns three metrics:

- **Validation** — structural checks (frontmatter format, naming conventions)
- **Description Judge** — quality score for the frontmatter description (0–1.0)
- **Content Judge** — quality score for the SKILL.md body (0–1.0)

The average of description and content scores must be ≥ 90%.

**Review all skills at once:**

```bash
deno run review-skills
```

This runs tessl against every skill in `.claude/skills/` and prints a summary
table. In CI, it writes the table to the GitHub Actions step summary.

### Promptfoo — Routing Evaluation

Promptfoo tests whether an LLM actually navigates from a user query to the right
context. `deno run eval-skill-triggers` runs three phases in sequence against
the same model, then reports a combined pass rate:

| Phase | Eval file                      | Generator                        | Question                                          |
| ----- | ------------------------------ | -------------------------------- | ------------------------------------------------- |
| 1     | `trigger_evals.json`           | `generate_config.ts`             | Does the right skill trigger?                     |
| 2     | `routing_evals.json`           | `generate_routing_config.ts`     | Does the right guide get loaded?                  |
| 3     | `guide_sufficiency_evals.json` | `generate_sufficiency_config.ts` | Is the guide enough, or is `reference.md` needed? |

Generators live in `evals/promptfoo/` and turn each eval file into a promptfoo
config where every choice is a tool the model can call. The driver is
`scripts/eval_skill_triggers_promptfoo.ts`; each phase writes its raw results
to `evals/promptfoo/results.json` (phase 1), `routing_results.json` (phase
2), and `sufficiency_results.json` (phase 3) — generated artifacts that are
gitignored, not committed.

Phase 2 and 3 generators keep a topic map (`GUIDE_TOPICS` / `GUIDE_DIRS`) that
must list every directory under `references/`; a missing entry makes the
generator exit with an error naming the unknown topic.

**Run against the default model (opus):**

```bash
export ANTHROPIC_API_KEY=<your-key>
deno run eval-skill-triggers
```

The CLI default is `opus` (`default: { model: "opus" }` in
`scripts/eval_skill_triggers_promptfoo.ts`). The header comment in that script
and the generator headers in `evals/promptfoo/generate_*.ts` still say
"sonnet (default)" — that comment drift is stale; the parsed default is what
runs.

**Run against a specific model:**

```bash
export ANTHROPIC_API_KEY=<your-key>
deno run eval-skill-triggers --model sonnet

export OPENAI_API_KEY=<your-key>
deno run eval-skill-triggers --model gpt-5.4

export GOOGLE_API_KEY=<your-key>
deno run eval-skill-triggers --model gemini-2.5-pro
```

**Tune concurrency and threshold:**

```bash
deno run eval-skill-triggers --model sonnet --concurrency 10 --threshold 0.85
```

Defaults are concurrency 20 and threshold 90%. Each sonnet run costs ~$2 and
takes ~30 seconds.

If the required API key is missing, the script gracefully skips (exits 0) rather
than failing.

## CI Pipeline

CI runs skill checks automatically when relevant files change. The change
detection filter triggers on modifications to:

- `.claude/skills/**`
- `CLAUDE.md`
- `scripts/review_skills.ts`
- `evals/promptfoo/**`

### PR Checks

Two jobs run in parallel on every PR that touches skill files:

**skill-review** — runs `scripts/review_skills.ts` directly (the same script
behind `deno run review-skills`) with `TESSL_TOKEN` from repository secrets.
Fails the PR if any skill scores below 90%.

**skill-trigger-eval** — runs `deno run eval-skill-triggers` (promptfoo) with
the default opus model, covering all three phases. Fails the PR if the combined
pass rate drops below 90%.

Both jobs write detailed results to the GitHub Actions step summary for easy
review.

### Weekly Multi-Model Regression

A scheduled workflow (`multi-model-eval.yml`) runs every Saturday at 08:00 UTC.
It runs `deno run eval-skill-triggers --model <m> --concurrency <n>` — all
three phases — against six models in parallel, and uploads
`evals/promptfoo/results.json` and `routing_results.json` as a per-model
artifact (retained 14 days):

| Model          | Provider  | Concurrency | API Key Env        |
| -------------- | --------- | ----------- | ------------------ |
| opus           | Anthropic | 20          | `ANTHROPIC_API_KEY` |
| sonnet         | Anthropic | 20          | `ANTHROPIC_API_KEY` |
| gpt-5.4        | OpenAI    | 1           | `OPENAI_API_KEY`   |
| gemini-2.5-pro | Google    | 20          | `GOOGLE_API_KEY`   |
| gemini-3.1-pro | Google    | 20          | `GOOGLE_API_KEY`   |
| fable          | Anthropic | 20          | `ANTHROPIC_API_KEY` |

This catches model-specific regressions that the single-model PR check would
miss. It can also be triggered manually via `workflow_dispatch` with a model
filter.

### After CI

Once all checks pass (skill review, trigger eval, code review, and standard
tests), PRs are auto-merged unless the `hold` label is applied.

## Lifecycle Flow

```
                        ┌─────────────────────┐
                        │       Author        │
                        │                     │
                        │  Create skill dir   │
                        │  Write SKILL.md     │
                        │  Write trigger evals│
                        │  Add references     │
                        └─────────┬───────────┘
                                  │
                                  ▼
                     ┌────────────────────────┐
                     │     Test Locally        │
                     │                         │
                     │  tessl  → quality ok?   │
                     │  promptfoo → routing ok?│
                     └────────────┬────────────┘
                                  │
                          ┌───────┴───────┐
                          │ Pass?         │
                          │  no ──────────┼──── loop back to Author
                          │  yes          │
                          └───────┬───────┘
                                  │
                                  ▼
                     ┌────────────────────────┐
                     │      Open PR            │
                     │                         │
                     │  CI: skill-review       │
                     │  CI: skill-trigger-eval │
                     │  CI: code review        │
                     └────────────┬────────────┘
                                  │
                                  ▼
                     ┌────────────────────────┐
                     │      Merge              │
                     └────────────┬────────────┘
                                  │
                                  ▼
                     ┌────────────────────────┐
                     │  Use on real tasks      │
                     │                         │
                     │  Notice gaps or          │
                     │  mis-routes? Loop back   │
                     │  to Author.              │
                     └──────────────────────────┘

              Weekly: multi-model regression catches
              model-specific routing drift (Sat 08:00 UTC)
```
