#!/usr/bin/env sh
# shellcheck shell=sh disable=SC3043
set -eu

print_usage() {
  local program bin default_dest default_platform
  program="$1"
  bin="$2"
  default_dest="$3"
  default_platform="$4"

  cat <<-EOF
	$program

	Installs a binary release of $bin for supported platforms

	USAGE:
	    $program [OPTIONS] [--]

	OPTIONS:
	    -h, --help                Prints help information
	    -d, --destination=<DEST>  Destination directory for installation
	                              [default: $default_dest]
	    -p, --platform=<PLATFORM> Platform type to install
	                              [examples: linux-x86_64, linux-aarch64,
	                              darwin-x86_64, darwin-aarch64]
	                              [default: $default_platform]
	    -V, --version=<VERSION>   Release version to install
	                              [examples: stable,
	                              20250218.210911.0-sha.bda1ce6ea]
	                              [default: stable]

	EXAMPLES:
	    # Installs the latest release into \`\$HOME/bin\`
	    $program

	    # Installs the latest release for all users under \`/usr/local/bin\`
	    sudo $program

	    # Installs an old release into a temp directory
	    $program -V 20250214.193652.0-sha.0f9972a53 -d /tmp
	EOF
}

main() {
  if [ -n "${DEBUG:-}" ]; then set -v; fi
  if [ -n "${TRACE:-}" ]; then set -xv; fi

  local program bin
  program="install.sh"
  bin="swamp"

  INSTALL_DEST=""
  INSTALL_BIN=""

  setup_cleanups
  setup_traps trap_exit

  parse_cli_args "$program" "$bin" "$@"
  local dest os_type cpu_type platform version
  dest="$DEST"
  os_type="$OS_TYPE"
  cpu_type="$CPU_TYPE"
  platform="$PLATFORM"
  version="$VERSION"
  unset DEST OS_TYPE CPU_TYPE PLATFORM VERSION

  check_dynamic_linker "$os_type" "$cpu_type"

  section "Downloading and installing '$bin' release '$version' on '$platform'"

  local asset_url
  asset_url="$(
    asset_url "$bin" "$version" "$os_type" "$cpu_type" "$platform"
  )" || die "Unsupported platform '$platform' for '$bin' release '$version'"

  local tmpdir
  tmpdir="$(mktemp_directory)"
  cleanup_directory "$tmpdir"

  local asset checksum resolved_asset_url release_version release_asset
  local release_checksums
  asset="$(basename "$asset_url")"
  checksum="$asset.sha256"
  download "$asset_url" "$tmpdir/$asset"
  resolved_asset_url="$DOWNLOADED_URL"

  # Download the checksum from the resolved (version-pinned) URL, not the
  # alias URL. The alias tarball and alias .sha256 are separate S3 objects
  # updated non-atomically, so fetching both from the alias can race during
  # releases. The version-pinned checksum is immutable.
  download "$resolved_asset_url.sha256" "$tmpdir/$checksum"

  verify_sha256_resolved "$tmpdir/$asset" "$tmpdir/$checksum"
  validate_archive "$tmpdir/$asset" "$bin"

  release_version="$(release_version_from_url "$resolved_asset_url")"
  release_asset="$bin-$os_type-$cpu_type"
  release_checksums="checksums-$release_version.txt"
  download \
    "https://github.com/swamp-club/swamp/releases/download/v$release_version/checksums.txt" \
    "$tmpdir/$release_checksums"

  section "Extracting '$asset'"
  extract_archive "$tmpdir/$asset" "$tmpdir" "$bin"
  verify_release_binary \
    "$tmpdir/$bin" "$tmpdir/$release_checksums" "$release_asset"

  INSTALL_DEST="$dest"
  INSTALL_BIN="$bin"

  section "Installing '$bin'"
  install_bin "$tmpdir/$bin" "$dest/$bin" "$bin"

  section "Installation of '$bin' release '$version' complete"
  indent "$dest/$bin" --version
  echo

  info "By using Swamp you agree to its software license and extension"
  info "registry terms."
  info ""
  info "  Software License:     https://swamp-club.com/software-license-agreement"
  info "  Extension Registry:   https://swamp-club.com/extension-registry-terms"
  echo

  # Prompt to connect to SWAMP CLUB when running interactively
  # Skip in CI environments or when explicitly requested via SWAMP_NONINTERACTIVE
  if [ -z "${CI:-}" ] && [ -z "${SWAMP_NONINTERACTIVE:-}" ] && [ -e /dev/tty ] && [ -t 1 ]; then
    echo
    section "Swamp is better with SWAMP CLUB (swamp-club.com)"
    info ""
    info "Connect your account to unlock:"
    info "  - Submit bug reports and feature requests"
    info "  - Publish extensions to share with the community"
    info "  - Higher rate limits on CLI usage"
    info ""
    printf "  Set up your SWAMP CLUB account now? [Y/n] "
    read -r _answer </dev/tty || _answer=""
    case "$_answer" in
      [nN]*)
        info ""
        info "No problem! You can connect later: swamp auth login"
        ;;
      *)
        echo
        if ! "$dest/$bin" auth login </dev/tty; then
          warn ""
          warn "Account setup didn't finish — no worries!"
          warn "Run this when you're ready to pick up where you left off:"
          warn ""
          warn "    swamp auth login"
          warn ""
        fi
        ;;
    esac
    echo
  fi

  info "Next steps:"
  info ""
  info "  1. Initialize a swamp repository:"
  info "       cd your-project && swamp repo init"
  info ""
  info "  2. Set up shell completions (optional):"
  info "       swamp completions --help"
  info ""
  info "  3. Join the community:"
  info "       https://discord.gg/swamp-club"
  info ""
  info "Learn more: https://github.com/swamp-club/swamp"
}

parse_cli_args() {
  local program bin
  program="$1"
  shift
  bin="$1"
  shift

  need_cmd grep
  need_cmd id
  need_cmd uname
  need_cmd tr
  need_cmd curl

  local os_type cpu_type plat dest
  os_type="$(uname -s | tr '[:upper:]' '[:lower:]')"
  cpu_type="$(uname -m | tr '[:upper:]' '[:lower:]')"
  case "$cpu_type" in
    amd64 | x64 | x86_64 | x86-64) cpu_type=x86_64 ;;
    aarch64 | arm64 | arm64v8) cpu_type=aarch64 ;;
  esac
  plat="$os_type-$cpu_type"

  if [ "$(id -u)" -eq 0 ]; then
    dest="/usr/local/bin"
  else
    if echo "$PATH" | tr ':' '\n' | grep -q "^$HOME/.local/bin\$"; then
      dest="$HOME/.local/bin"
    elif echo "$PATH" | tr ':' '\n' | grep -q "^$HOME/bin\$"; then
      dest="$HOME/bin"
    else
      dest="$HOME/.$bin/bin"
    fi
  fi

  DEST="$dest"
  PLATFORM="$plat"
  VERSION="stable"

  OPTIND=1
  while getopts "d:hp:V:-:" arg; do
    case "$arg" in
      d)
        DEST="$OPTARG"
        ;;
      h)
        print_usage "$program" "$bin" "$dest" "$plat"
        exit 0
        ;;
      p)
        PLATFORM="$OPTARG"
        ;;
      V)
        VERSION="$OPTARG"
        ;;
      -)
        long_optarg="${OPTARG#*=}"
        case "$OPTARG" in
          destination=?*)
            DEST="$long_optarg"
            ;;
          destination*)
            print_usage "$program" "$bin" "$dest" "$plat" >&2
            die "missing required argument for --$OPTARG option"
            ;;
          help)
            print_usage "$program" "$bin" "$dest" "$plat"
            exit 0
            ;;
          platform=?*)
            PLATFORM="$long_optarg"
            ;;
          platform*)
            print_usage "$program" "$bin" "$dest" "$plat" >&2
            die "missing required argument for --$OPTARG option"
            ;;
          version=?*)
            VERSION="$long_optarg"
            ;;
          version*)
            print_usage "$program" "$bin" "$dest" "$plat" >&2
            die "missing required argument for --$OPTARG option"
            ;;
          '')
            # "--" terminates argument processing
            break
            ;;
          *)
            print_usage "$program" "$bin" "$dest" "$plat" >&2
            die "invalid argument --$OPTARG"
            ;;
        esac
        ;;
      \?)
        print_usage "$program" "$bin" "$dest" "$plat" >&2
        die "invalid argument; arg=-$OPTARG"
        ;;
    esac
  done
  shift "$((OPTIND - 1))"

  case "$PLATFORM" in
    linux-x86_64 | linux-aarch64 | darwin-x86_64 | darwin-aarch64) ;;
    *) die "Installation failed, unsupported platform: '$PLATFORM'" ;;
  esac

  OS_TYPE="${PLATFORM%%-*}"
  CPU_TYPE="${PLATFORM#*-}"
}

asset_url() {
  local bin version os_type cpu_type platform
  bin="$1"
  version="$2"
  os_type="$3"
  cpu_type="$4"
  platform="$5"

  local type asset_url extension
  type="binary"
  extension="tar.gz"

  asset_url="https://artifacts.swamp-club.com/$bin/$version/$type"
  asset_url="$asset_url/$os_type/$cpu_type/$bin-$version-$type-$platform.$extension"

  echo "$asset_url"
}

validate_artifact_url() {
  local url
  url="$1"

  case "$url" in
    https://artifacts.swamp-club.com/swamp/*) ;;
    *) die "Untrusted artifact URL: $url" ;;
  esac
}

release_version_from_url() {
  local url path version
  url="$1"

  validate_artifact_url "$url"
  path="${url#https://artifacts.swamp-club.com/swamp/}"
  version="${path%%/*}"

  if [ -z "$version" ] || [ "$version" = "stable" ]; then
    die "Could not determine the release version for checksum verification"
  fi
  case "$version" in
    *[!0-9A-Za-z._-]*) die "Invalid release version: $version" ;;
  esac

  echo "$version"
}

validate_archive() {
  local archive bin entries
  archive="$1"
  bin="$2"

  need_cmd tar
  entries="$(tar -tzf "$archive")" || die "Failed to inspect downloaded archive"
  if [ "$entries" != "$bin" ]; then
    die "Downloaded archive contains unexpected entries"
  fi
}

extract_archive() {
  local archive dest bin
  archive="$1"
  dest="$2"
  bin="$3"

  need_cmd tar

  info_start "Extracting archive"
  tar -xzf "$archive" -C "$dest"
  info_end

  # Verify the binary was extracted
  if [ ! -f "$dest/$bin" ]; then
    die "Failed to extract binary '$bin' from archive"
  fi
}

checksum_for_asset() {
  local checksum_file target checksum filename found
  checksum_file="$1"
  target="$2"
  found=""

  while IFS=' ' read -r checksum filename; do
    if [ "$filename" = "$target" ]; then
      if [ -n "$found" ]; then
        die "Duplicate checksum for '$target'"
      fi
      found="$checksum"
    fi
  done <"$checksum_file"

  if [ -z "$found" ]; then
    die "No checksum found for '$target'"
  fi
  validate_sha256 "$found" "$target"
  echo "$found"
}

validate_sha256() {
  local checksum label
  checksum="$1"
  label="$2"

  if [ "${#checksum}" -ne 64 ]; then
    die "Invalid SHA-256 checksum for '$label'"
  fi
  case "$checksum" in
    *[!0-9a-f]*) die "Invalid SHA-256 checksum for '$label'" ;;
  esac
}

compute_sha256() {
  local file actual
  file="$1"

  if check_cmd sha256sum; then
    actual="$(sha256sum "$file")"
  elif check_cmd shasum; then
    actual="$(shasum -a 256 "$file")"
  else
    die "SHA-256 verification requires 'sha256sum' or 'shasum'"
  fi

  echo "${actual%% *}"
}

verify_sha256_resolved() {
  local archive checksum expected actual
  archive="$1"
  checksum="$2"

  expected=""
  IFS=' ' read -r expected _ <"$checksum" || true
  validate_sha256 "$expected" "$(basename "$archive")"

  actual="$(compute_sha256 "$archive")"

  if [ "$expected" != "$actual" ]; then
    die "SHA-256 checksum verification failed for '$(basename "$archive")'"
  fi

  info "Verified SHA-256 checksum for '$(basename "$archive")'"
}

verify_sha256() {
  local archive checksum expected checksum_filename actual
  archive="$1"
  checksum="$2"

  expected=""
  IFS=' ' read -r expected checksum_filename <"$checksum" || true
  validate_sha256 "$expected" "$(basename "$archive")"
  if [ "$checksum_filename" != "$(basename "$archive")" ]; then
    die "SHA-256 checksum filename does not match '$(basename "$archive")'"
  fi

  actual="$(compute_sha256 "$archive")"

  if [ "$expected" != "$actual" ]; then
    die "SHA-256 checksum verification failed for '$(basename "$archive")'"
  fi

  info "Verified SHA-256 checksum for '$(basename "$archive")'"
}

verify_release_binary() {
  local binary checksums release_asset expected actual
  binary="$1"
  checksums="$2"
  release_asset="$3"

  expected="$(checksum_for_asset "$checksums" "$release_asset")"
  actual="$(compute_sha256 "$binary")"
  if [ "$expected" != "$actual" ]; then
    die "GitHub release checksum verification failed for '$release_asset'"
  fi

  info "Verified GitHub release checksum for '$release_asset'"
}

install_bin() {
  local src dest bin
  src="$1"
  dest="$2"
  bin="$3"

  need_cmd dirname
  need_cmd install
  need_cmd mkdir

  info_start "Installing '$dest'"
  mkdir -p "$(dirname "$dest")"
  install -p -m 755 "$src" "$dest"
  info_end

  if [ "$(dirname "$dest")" = "$HOME/.$bin/bin" ]; then
    symlink_to_system_path "$dest" "$bin"
  fi
}

check_dynamic_linker() {
  local os_type cpu_type linker
  os_type="$1"
  cpu_type="$2"

  if [ "$os_type" != "linux" ]; then
    return 0
  fi

  case "$cpu_type" in
    x86_64) linker="/lib64/ld-linux-x86-64.so.2" ;;
    aarch64) linker="/lib/ld-linux-aarch64.so.1" ;;
    *) return 0 ;;
  esac

  if [ ! -f "$linker" ]; then
    die "The glibc dynamic linker was not found at '$linker'. Swamp requires a glibc-based Linux system. Your system may use a non-standard library layout (e.g. musl libc or an immutable filesystem). No files have been modified."
  fi
}

symlink_to_system_path() {
  local dest bin
  dest="$1"
  bin="$2"

  need_cmd sudo

  local system_path=/usr/local/bin
  local prompt="[sudo required to link $bin under $system_path]"
  prompt="$prompt Password for %u: "

  if [ ! -d "$system_path" ]; then
    die "Directory '$system_path' does not exist. Create it with 'sudo mkdir -p $system_path' or re-run the installer with '-d <path>' to choose a different destination."
  fi

  info "Symlinking '$dest' to $system_path/$bin"
  sudo -p "$prompt" ln -snf "$dest" "$system_path/$bin"
}

trap_exit() {
  if [ $? -ne 0 ]; then
    local msg
    msg="We're sorry, but it looks like something might have gone wrong "
    msg="$msg during installation."
    {
      echo
      warn "$msg" >&2
      if [ -n "${INSTALL_DEST:-}" ] && [ -n "${INSTALL_BIN:-}" ]; then
        warn "" >&2
        warn "To clean up, you can remove the installed files:" >&2
        warn "    rm -f $INSTALL_DEST/$INSTALL_BIN" >&2
        warn "    sudo rm -f /usr/local/bin/$INSTALL_BIN" >&2
      fi
      warn "" >&2
      warn "If you need help, please join us on our discord!"
      warn ""
      warn "    https://discord.gg/swamp-club"
    } >&2
  fi
  trap_cleanups
}

# BEGIN: libsh.sh

#
# Copyright 2019 Fletcher Nichol and/or applicable contributors.
#
# Licensed under the Apache License, Version 2.0 <LICENSE-APACHE or
# http://www.apache.org/licenses/LICENSE-2.0> or the MIT license (see
# <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your option. This
# file may not be copied, modified, or distributed except according to those
# terms.
#
# libsh.sh
# --------
# project: https://github.com/fnichol/libsh
# author: Fletcher Nichol <fnichol@nichol.ca>
# version: 0.10.1
# distribution: libsh.full-minified.sh
# commit-hash: 46134771903ba66967666ca455f73ffc10dd0a03
# commit-date: 2021-05-08
# artifact: https://github.com/fnichol/libsh/releases/download/v0.10.1/libsh.full.sh
# source: https://github.com/fnichol/libsh/tree/v0.10.1
# archive: https://github.com/fnichol/libsh/archive/v0.10.1.tar.gz
#
if [ -n "${KSH_VERSION:-}" ]; then
  eval "local() { return 0; }"
fi
# shellcheck disable=SC2120
mktemp_directory() {
  need_cmd mktemp
  if [ -n "${1:-}" ]; then
    mktemp -d "$1/tmp.XXXXXX"
  else
    mktemp -d 2>/dev/null || mktemp -d -t tmp
  fi
}
# shellcheck disable=SC2120
mktemp_file() {
  need_cmd mktemp
  if [ -n "${1:-}" ]; then
    mktemp "$1/tmp.XXXXXX"
  else
    mktemp 2>/dev/null || mktemp -t tmp
  fi
}
trap_cleanup_files() {
  set +e
  if [ -n "${__CLEANUP_FILES__:-}" ] && [ -f "$__CLEANUP_FILES__" ]; then
    local _file
    while read -r _file; do
      rm -f "$_file"
    done <"$__CLEANUP_FILES__"
    unset _file
    rm -f "$__CLEANUP_FILES__"
  fi
}
need_cmd() {
  if ! check_cmd "$1"; then
    die "Required command '$1' not found on PATH"
  fi
}
trap_cleanups() {
  set +e
  trap_cleanup_directories
  trap_cleanup_files
}
print_version() {
  local _program _version _verbose _sha _long_sha _date
  _program="$1"
  _version="$2"
  _verbose="${3:-false}"
  _sha="${4:-}"
  _long_sha="${5:-}"
  _date="${6:-}"
  if [ -z "$_sha" ] || [ -z "$_long_sha" ] || [ -z "$_date" ]; then
    if check_cmd git \
      && git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
      if [ -z "$_sha" ]; then
        _sha="$(git show -s --format=%h)"
        if ! git diff-index --quiet HEAD --; then
          _sha="${_sha}-dirty"
        fi
      fi
      if [ -z "$_long_sha" ]; then
        _long_sha="$(git show -s --format=%H)"
        case "$_sha" in
          *-dirty) _long_sha="${_long_sha}-dirty" ;;
        esac
      fi
      if [ -z "$_date" ]; then
        _date="$(git show -s --format=%ad --date=short)"
      fi
    fi
  fi
  if [ -n "$_sha" ] && [ -n "$_date" ]; then
    echo "$_program $_version ($_sha $_date)"
  else
    echo "$_program $_version"
  fi
  if [ "$_verbose" = "true" ]; then
    echo "release: $_version"
    if [ -n "$_long_sha" ]; then
      echo "commit-hash: $_long_sha"
    fi
    if [ -n "$_date" ]; then
      echo "commit-date: $_date"
    fi
  fi
  unset _program _version _verbose _sha _long_sha _date
}
warn() {
  case "${TERM:-}" in
    *term | alacritty | rxvt | screen | screen-* | tmux | tmux-* | xterm-*)
      printf -- "\033[1;31;40m!!! \033[1;37;40m%s\033[0m\n" "$1"
      ;;
    *)
      printf -- "!!! %s\n" "$1"
      ;;
  esac
}
section() {
  case "${TERM:-}" in
    *term | alacritty | rxvt | screen | screen-* | tmux | tmux-* | xterm-*)
      printf -- "\033[1;36;40m--- \033[1;37;40m%s\033[0m\n" "$1"
      ;;
    *)
      printf -- "--- %s\n" "$1"
      ;;
  esac
}
setup_cleanup_directories() {
  if [ "${__CLEANUP_DIRECTORIES_SETUP__:-}" != "$$" ]; then
    unset __CLEANUP_DIRECTORIES__
    __CLEANUP_DIRECTORIES_SETUP__="$$"
    export __CLEANUP_DIRECTORIES_SETUP__
  fi
  if [ -z "${__CLEANUP_DIRECTORIES__:-}" ]; then
    __CLEANUP_DIRECTORIES__="$(mktemp_file)"
    if [ -z "$__CLEANUP_DIRECTORIES__" ]; then
      return 1
    fi
    export __CLEANUP_DIRECTORIES__
  fi
}
setup_cleanup_files() {
  if [ "${__CLEANUP_FILES_SETUP__:-}" != "$$" ]; then
    unset __CLEANUP_FILES__
    __CLEANUP_FILES_SETUP__="$$"
    export __CLEANUP_FILES_SETUP__
  fi
  if [ -z "${__CLEANUP_FILES__:-}" ]; then
    __CLEANUP_FILES__="$(mktemp_file)"
    if [ -z "$__CLEANUP_FILES__" ]; then
      return 1
    fi
    export __CLEANUP_FILES__
  fi
}
setup_cleanups() {
  setup_cleanup_directories
  setup_cleanup_files
}
setup_traps() {
  local _sig
  for _sig in HUP INT QUIT ALRM TERM; do
    trap "
      $1
      trap - $_sig EXIT
      kill -s $_sig "'"$$"' "$_sig"
  done
  if [ -n "${ZSH_VERSION:-}" ]; then
    eval "zshexit() { eval '$1'; }"
  else
    # shellcheck disable=SC2064
    trap "$1" EXIT
  fi
  unset _sig
}
trap_cleanup_directories() {
  set +e
  if [ -n "${__CLEANUP_DIRECTORIES__:-}" ] \
    && [ -f "$__CLEANUP_DIRECTORIES__" ]; then
    local _dir
    while read -r _dir; do
      rm -rf "$_dir"
    done <"$__CLEANUP_DIRECTORIES__"
    unset _dir
    rm -f "$__CLEANUP_DIRECTORIES__"
  fi
}
check_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    return 1
  fi
}
cleanup_directory() {
  setup_cleanup_directories
  echo "$1" >>"$__CLEANUP_DIRECTORIES__"
}
cleanup_file() {
  setup_cleanup_files
  echo "$1" >>"$__CLEANUP_FILES__"
}
die() {
  case "${TERM:-}" in
    *term | alacritty | rxvt | screen | screen-* | tmux | tmux-* | xterm-*)
      printf -- "\n\033[1;31;40mxxx \033[1;37;40m%s\033[0m\n\n" "$1" >&2
      ;;
    *)
      printf -- "\nxxx %s\n\n" "$1" >&2
      ;;
  esac
  exit 1
}
download() {
  local _url _dst _code _orig_flags _redirect_url _download_url
  local _effective_url _artifact_download
  _url="$1"
  _dst="$2"
  DOWNLOADED_URL="$_url"
  _download_url="$_url"
  _artifact_download=false
  case "$_url" in
    https://artifacts.swamp-club.com/swamp/*) _artifact_download=true ;;
  esac
  need_cmd sed
  if check_cmd curl; then
    info "Downloading $_url to $_dst (curl)"
    _orig_flags="$-"
    set +e

    if [ "$_artifact_download" = true ]; then
      # Stable artifacts use S3 website redirect metadata instead of a 3xx.
      _redirect_url="$(curl -sSI --proto '=https' "$_url" | grep -i "x-amz-meta-x-amz-website-redirect-location" | cut -d' ' -f2- | tr -d '\r\n')"
      if [ -n "$_redirect_url" ]; then
        validate_artifact_url "$_redirect_url"
        info "Following S3 redirect to $_redirect_url"
        _download_url="$_redirect_url"
      fi
    fi

    _effective_url="$(curl -sSfL --proto '=https' --proto-redir '=https' \
      "$_download_url" -o "$_dst" -w '%{url_effective}')"
    _code="$?"
    if [ $_code -eq 0 ] && [ "$_artifact_download" = true ]; then
      validate_artifact_url "$_effective_url"
    fi
    DOWNLOADED_URL="$_effective_url"
    set "-$(echo "$_orig_flags" | sed s/s//g)"
    if [ $_code -eq 0 ]; then
      unset _url _dst _code _orig_flags _redirect_url _download_url
      unset _effective_url _artifact_download
      return 0
    else
      local _e
      _e="curl failed to download file, perhaps curl doesn't have"
      _e="$_e SSL support and/or no CA certificates are present?"
      warn "$_e"
      unset _e
    fi
  fi
  if check_cmd wget; then
    info "Downloading $_url to $_dst (wget)"
    _orig_flags="$-"
    set +e
    wget -q -O "$_dst" "$_url"
    _code="$?"
    set "-$(echo "$_orig_flags" | sed s/s//g)"
    if [ $_code -eq 0 ]; then
      unset _url _dst _code _orig_flags
      return 0
    else
      local _e
      _e="wget failed to download file, perhaps wget doesn't have"
      _e="$_e SSL support and/or no CA certificates are present?"
      warn "$_e"
      unset _e
    fi
  fi
  if check_cmd ftp; then
    info "Downloading $_url to $_dst (ftp)"
    _orig_flags="$-"
    set +e
    ftp -o "$_dst" "$_url"
    _code="$?"
    set "-$(echo "$_orig_flags" | sed s/s//g)"
    if [ $_code -eq 0 ]; then
      unset _url _dst _code _orig_flags
      return 0
    else
      local _e
      _e="ftp failed to download file, perhaps ftp doesn't have"
      _e="$_e SSL support and/or no CA certificates are present?"
      warn "$_e"
      unset _e
    fi
  fi
  unset _url _dst _code _orig_flags _redirect_url _download_url
  unset _effective_url _artifact_download
  warn "Downloading requires SSL-enabled 'curl', 'wget', or 'ftp' on PATH"
  return 1
}
indent() {
  local _ecfile _ec _orig_flags
  need_cmd cat
  need_cmd rm
  need_cmd sed
  _ecfile="$(mktemp_file)"
  _orig_flags="$-"
  set +e
  {
    "$@" 2>&1
    echo "$?" >"$_ecfile"
  } | sed 's/^/       /'
  set "-$(echo "$_orig_flags" | sed s/s//g)"
  _ec="$(cat "$_ecfile")"
  rm -f "$_ecfile"
  unset _ecfile _orig_flags
  return "${_ec:-5}"
}
info() {
  case "${TERM:-}" in
    *term | alacritty | rxvt | screen | screen-* | tmux | tmux-* | xterm-*)
      printf -- "\033[1;36;40m  - \033[1;37;40m%s\033[0m\n" "$1"
      ;;
    *)
      printf -- "  - %s\n" "$1"
      ;;
  esac
}
info_end() {
  case "${TERM:-}" in
    *term | alacritty | rxvt | screen | screen-* | tmux | tmux-* | xterm-*)
      printf -- "\033[1;37;40m%s\033[0m\n" "done."
      ;;
    *)
      printf -- "%s\n" "done."
      ;;
  esac
}
info_start() {
  case "${TERM:-}" in
    *term | alacritty | rxvt | screen | screen-* | tmux | tmux-* | xterm-*)
      printf -- "\033[1;36;40m  - \033[1;37;40m%s ... \033[0m" "$1"
      ;;
    *)
      printf -- "  - %s ... " "$1"
      ;;
  esac
}

# END: libsh.sh

main "$@"
