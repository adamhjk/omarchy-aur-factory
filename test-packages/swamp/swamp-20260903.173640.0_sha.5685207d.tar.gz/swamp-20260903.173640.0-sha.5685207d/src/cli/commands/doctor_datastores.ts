// Swamp, an Automation Framework
// Copyright (C) 2026 Elder Swamp Club, Inc.
//
// This file is part of Swamp.
//
// Swamp is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License version 3
// as published by the Free Software Foundation, with the Swamp
// Extension and Definition Exception (found in the "COPYING-EXCEPTION"
// file).
//
// Swamp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with Swamp.  If not, see <https://www.gnu.org/licenses/>.

import { Command } from "@cliffy/command";
import {
  type CatalogCompletenessSummary,
  type CatalogShortfall,
  consumeStream,
  createLibSwampContext,
  doctorDatastores,
  type DoctorDatastoresData,
  type DoctorDatastoresDeps,
  repairCatalogDuplicateLatest,
  type RepairCatalogDuplicateLatestDeps,
  repairCatalogIndex,
  type RepairCatalogIndexDeps,
  repairDatastoreContamination,
  type RepairDatastoresDeps,
  repairUnmigratedData,
  type RepairUnmigratedDataDeps,
} from "../../libswamp/mod.ts";
import {
  createCatalogDuplicateLatestRepairRenderer,
  createCatalogIndexRepairRenderer,
  createDoctorDatastoresRenderer,
  createRepairDatastoresRenderer,
  createUnmigratedDataRepairRenderer,
} from "../../presentation/renderers/doctor_datastores.ts";
import {
  createContext,
  type GlobalOptions,
  resolveRepoDir,
} from "../context.ts";
import { resolveDatastoreForRepo } from "../repo_context.ts";
import {
  requestServerResponse,
  resolveServerToken,
  resolveServeUrl,
  withRemoteOptions,
} from "../remote_run.ts";
import type { DoctorDatastoresResponse } from "../../serve/protocol.ts";
import {
  type CustomDatastoreConfig,
  DEFAULT_DATASTORE_SUBDIRS,
  isCustomDatastoreConfig,
} from "../../domain/datastore/datastore_config.ts";
import { datastoreTypeRegistry } from "../../domain/datastore/datastore_type_registry.ts";
import type { DatastoreProvider } from "../../domain/datastore/datastore_provider.ts";
import { UserError } from "../../domain/errors.ts";
import { FilesystemDatastoreVerifier } from "../../infrastructure/persistence/filesystem_datastore_verifier.ts";
import { YamlVaultConfigRepository } from "../../infrastructure/persistence/yaml_vault_config_repository.ts";
import { RepoMarkerRepository } from "../../infrastructure/persistence/repo_marker_repository.ts";
import { RepoPath } from "../../domain/repo/repo_path.ts";
import { resolveDatastoreConfig } from "../resolve_datastore.ts";
import { RUNS_INDEX_FILENAME } from "../../infrastructure/persistence/workflow_run_index.ts";
import {
  catalogDbPath,
  createCatalogStore,
  createUnifiedDataRepository,
  namespaceFromResolver,
} from "../../infrastructure/persistence/repository_factory.ts";
import { DefaultDatastorePathResolver } from "../../infrastructure/persistence/default_datastore_path_resolver.ts";
import type { CatalogStore } from "../../infrastructure/persistence/catalog_store.ts";
import { computeLatestFlags } from "../../domain/data/data_query_service.ts";
import type { UnifiedDataRepository } from "../../domain/data/repositories.ts";
import type { Namespace } from "../../domain/data/namespace.ts";
import {
  SWAMP_SUBDIRS,
  swampPath,
} from "../../infrastructure/persistence/paths.ts";
import { join } from "@std/path";
import {
  compareFiles,
  dirHasFiles,
  removeEmptyDirs,
} from "../../infrastructure/persistence/directory_merge.ts";

// deno-lint-ignore no-explicit-any
type AnyOptions = any;

async function resolveProvider(
  config: CustomDatastoreConfig,
): Promise<DatastoreProvider> {
  await datastoreTypeRegistry.ensureTypeLoaded(config.type);
  const typeInfo = datastoreTypeRegistry.get(config.type);
  if (!typeInfo?.createProvider) {
    throw new Error(
      `No provider available for datastore type "${config.type}"`,
    );
  }
  return typeInfo.createProvider(config.config);
}

async function createDoctorDatastoresDeps(
  repoDir: string,
): Promise<DoctorDatastoresDeps> {
  await datastoreTypeRegistry.ensureLoaded();
  return {
    getDatastoreConfig: async () => {
      const markerRepo = new RepoMarkerRepository();
      const marker = await markerRepo.read(RepoPath.create(repoDir));
      return await resolveDatastoreConfig(marker, undefined, repoDir);
    },
    checkHealth: async (config) => {
      if (isCustomDatastoreConfig(config)) {
        await datastoreTypeRegistry.ensureTypeLoaded(config.type);
        const typeInfo = datastoreTypeRegistry.get(config.type);
        if (typeInfo?.createProvider) {
          const provider = typeInfo.createProvider(config.config);
          const verifier = provider.createVerifier();
          return await verifier.verify();
        }
        return {
          healthy: false,
          message: "No provider available for datastore type",
          latencyMs: 0,
        };
      } else {
        const verifier = new FilesystemDatastoreVerifier(config.path);
        return await verifier.verify();
      }
    },
    getVaultConfigs: async () => {
      const vaultRepo = new YamlVaultConfigRepository(repoDir);
      try {
        const vaultConfigs = await vaultRepo.findAll();
        return vaultConfigs.map((vc) => ({ name: vc.name, type: vc.type }));
      } catch {
        return [];
      }
    },
    checkUnmigratedData: async (config) => {
      if (!config.namespace) {
        return { unmigrated: false, directories: [] };
      }
      const basePath = isCustomDatastoreConfig(config) && config.cachePath
        ? config.cachePath
        : isCustomDatastoreConfig(config)
        ? config.datastorePath
        : config.path;
      const found: string[] = [];
      for (const subdir of DEFAULT_DATASTORE_SUBDIRS) {
        try {
          const stat = await Deno.stat(join(basePath, subdir));
          if (stat.isDirectory && await dirHasFiles(join(basePath, subdir))) {
            found.push(subdir);
          }
        } catch {
          // Directory doesn't exist — expected when migrated
        }
      }
      return { unmigrated: found.length > 0, directories: found };
    },
    checkNamespaceContamination: async (config) => {
      if (
        !config.namespace || !isCustomDatastoreConfig(config)
      ) {
        return null;
      }
      const provider = await resolveProvider(config);
      const cachePath = provider.resolveCachePath?.(repoDir) ??
        config.cachePath ?? config.datastorePath;
      const syncService = provider.createSyncService?.(repoDir, cachePath);
      if (!syncService?.repairNamespaceContamination) return null;

      return await syncService.repairNamespaceContamination({
        namespace: config.namespace,
        dryRun: true,
      });
    },
    checkCatalogCompleteness: () => checkCatalogCompleteness(repoDir),
  };
}

/**
 * Compares the local catalog index against the on-disk data walk, per model
 * type, counting only latest-version records on both sides.
 *
 * Reads the catalog directly rather than issuing a data query: a query would
 * trigger the catalog backfill, which repairs the exact condition being
 * measured — the diagnostic would then always report health. Exported so that
 * property can be tested against a real damaged catalog rather than a fake.
 *
 * Only shortfalls are reported. A type with more indexed rows than the walk
 * can see is not a shortfall — that is what foreign-namespace rows look like.
 */
export async function compareCatalogToDisk(
  catalogStore: CatalogStore,
  dataRepo: UnifiedDataRepository,
  namespace: Namespace,
): Promise<CatalogCompletenessSummary> {
  const diskByType = new Map<string, number>();
  for (const record of await dataRepo.findAllGlobal()) {
    const type = record.modelType.normalized;
    diskByType.set(type, (diskByType.get(type) ?? 0) + 1);
  }
  const catalogByType = catalogStore.latestRowCountsByType(namespace);

  const shortfalls: CatalogShortfall[] = [];
  let diskRecords = 0;
  let catalogRecords = 0;
  for (const [typeNormalized, onDisk] of diskByType) {
    const indexed = catalogByType.get(typeNormalized) ?? 0;
    diskRecords += onDisk;
    catalogRecords += indexed;
    if (indexed < onDisk) {
      shortfalls.push({
        typeNormalized,
        diskRecords: onDisk,
        catalogRecords: indexed,
      });
    }
  }

  return { diskRecords, catalogRecords, shortfalls };
}

async function checkCatalogCompleteness(
  repoDir: string,
): Promise<CatalogCompletenessSummary | null> {
  const markerRepo = new RepoMarkerRepository();
  const marker = await markerRepo.read(RepoPath.create(repoDir));
  const config = await resolveDatastoreConfig(marker, undefined, repoDir);
  const datastoreResolver = new DefaultDatastorePathResolver(repoDir, config);
  const catalogStore = createCatalogStore(repoDir, datastoreResolver);

  try {
    const namespace = namespaceFromResolver(datastoreResolver);
    const dataRepo = createUnifiedDataRepository(
      repoDir,
      catalogStore,
      datastoreResolver.localPath(SWAMP_SUBDIRS.data),
      undefined,
      namespace,
    );
    return await compareCatalogToDisk(catalogStore, dataRepo, namespace);
  } finally {
    // Release the SQLite handle before any repair removes the file — Windows
    // refuses to delete a database that still has an open connection.
    catalogStore.close();
  }
}

/**
 * Removes the catalog database and its SQLite sidecars, so the next data query
 * rebuilds the index from disk.
 */
async function removeCatalogDb(repoDir: string): Promise<void> {
  const dbPath = catalogDbPath(repoDir);
  for (const suffix of ["", "-journal", "-wal", "-shm"]) {
    try {
      await Deno.remove(dbPath + suffix);
    } catch (error) {
      if (!(error instanceof Deno.errors.NotFound)) throw error;
    }
  }
}

/**
 * Catalog repair deps.
 *
 * Deliberately free of the namespace and custom-datastore requirements the
 * other repairs carry: the catalog is a local index, and a plain local repo is
 * exactly where an incomplete one goes unnoticed.
 */
function createCatalogRepairDeps(repoDir: string): RepairCatalogIndexDeps {
  return {
    checkCompleteness: () => checkCatalogCompleteness(repoDir),
    invalidateCatalog: () => removeCatalogDb(repoDir),
  };
}

function createDuplicateLatestRepairDeps(
  repoDir: string,
): RepairCatalogDuplicateLatestDeps {
  const store = createCatalogStore(repoDir);
  return {
    countDuplicateLatest: () => store.countDuplicateLatest(),
    enforceUniqueLatest: () => store.enforceUniqueLatest(computeLatestFlags),
  };
}

async function createRepairDeps(
  repoDir: string,
): Promise<RepairDatastoresDeps> {
  await datastoreTypeRegistry.ensureLoaded();

  const markerRepo = new RepoMarkerRepository();
  const marker = await markerRepo.read(RepoPath.create(repoDir));
  const config = await resolveDatastoreConfig(marker, undefined, repoDir);

  if (!isCustomDatastoreConfig(config) || !config.namespace) {
    throw new UserError(
      "Repair is only available for custom datastores with a namespace configured.",
    );
  }

  const provider = await resolveProvider(config);
  const cachePath = provider.resolveCachePath?.(repoDir) ??
    config.cachePath ?? config.datastorePath;
  const syncService = provider.createSyncService?.(repoDir, cachePath);

  if (!syncService?.repairNamespaceContamination) {
    throw new UserError(
      `Datastore type "${config.type}" does not support namespace contamination repair.`,
    );
  }

  const namespace = config.namespace;

  return {
    getDatastoreConfig: () => Promise.resolve(config),
    detectContamination: () =>
      syncService.repairNamespaceContamination!({
        namespace,
        dryRun: true,
      }),
    deleteContamination: () =>
      syncService.repairNamespaceContamination!({
        namespace,
        dryRun: false,
      }),
    wipeLocalCache: async () => {
      for (const subdir of DEFAULT_DATASTORE_SUBDIRS) {
        const dir = join(cachePath, namespace, subdir);
        try {
          await Deno.remove(dir, { recursive: true });
        } catch (error) {
          if (!(error instanceof Deno.errors.NotFound)) throw error;
        }
      }
    },
    pullScoped: async () => {
      const count = await syncService.pullChanged({ namespace });
      return count ?? 0;
    },
    invalidateWorkflowRunIndexes: async () => {
      let invalidated = 0;
      const dirs = [
        swampPath(repoDir, "workflow-runs"),
        join(cachePath, namespace, "workflow-runs"),
      ];
      for (const workflowRunsDir of dirs) {
        try {
          for await (const entry of Deno.readDir(workflowRunsDir)) {
            if (entry.isDirectory) {
              const indexPath = join(
                workflowRunsDir,
                entry.name,
                RUNS_INDEX_FILENAME,
              );
              try {
                await Deno.remove(indexPath);
                invalidated++;
              } catch (error) {
                if (!(error instanceof Deno.errors.NotFound)) throw error;
              }
            }
          }
          const rootIndex = join(workflowRunsDir, RUNS_INDEX_FILENAME);
          try {
            await Deno.remove(rootIndex);
            invalidated++;
          } catch (error) {
            if (!(error instanceof Deno.errors.NotFound)) throw error;
          }
        } catch (error) {
          if (!(error instanceof Deno.errors.NotFound)) throw error;
        }
      }
      return invalidated;
    },
    invalidateCatalog: () => removeCatalogDb(repoDir),
  };
}

async function listFilesRecursive(
  dir: string,
  prefix = "",
): Promise<string[]> {
  const files: string[] = [];
  try {
    for await (const entry of Deno.readDir(dir)) {
      const relPath = prefix ? join(prefix, entry.name) : entry.name;
      if (entry.isDirectory && !entry.isSymlink) {
        files.push(
          ...await listFilesRecursive(join(dir, entry.name), relPath),
        );
      } else {
        files.push(relPath);
      }
    }
  } catch (error) {
    if (!(error instanceof Deno.errors.NotFound)) throw error;
  }
  return files;
}

async function createUnmigratedRepairDeps(
  repoDir: string,
): Promise<RepairUnmigratedDataDeps> {
  const markerRepo = new RepoMarkerRepository();
  const marker = await markerRepo.read(RepoPath.create(repoDir));
  const config = await resolveDatastoreConfig(marker, undefined, repoDir);

  if (!config.namespace) {
    throw new UserError(
      "Unmigrated data repair is only available when a namespace is configured.",
    );
  }

  const basePath = isCustomDatastoreConfig(config) && config.cachePath
    ? config.cachePath
    : isCustomDatastoreConfig(config)
    ? config.datastorePath
    : config.path;

  return {
    getBasePath: () => basePath,
    getNamespace: () => config.namespace!,
    listFiles: (dir: string) => listFilesRecursive(dir),
    compareFiles: (a: string, b: string) => compareFiles(a, b),
    removeFile: (path: string) => Deno.remove(path),
    removeEmptyDirs: (dir: string) => removeEmptyDirs(dir).then(() => {}),
    dirExists: async (path: string) => {
      try {
        const stat = await Deno.stat(path);
        return stat.isDirectory;
      } catch {
        return false;
      }
    },
  };
}

export const doctorDatastoresCommand = withRemoteOptions(
  new Command()
    .description(
      "Check that the configured datastore is healthy and flag any " +
        "vault compatibility issues.",
    )
    .example("Check this repo's datastore", "swamp doctor datastores")
    .example("Machine-readable output for CI", "swamp doctor datastores --json")
    .example(
      "Preview datastore repair",
      "swamp doctor datastores --repair",
    )
    .example(
      "Execute datastore repair",
      "swamp doctor datastores --repair -y",
    )
    .option(
      "--repo-dir <dir:string>",
      "Repository directory (env: SWAMP_REPO_DIR)",
    )
    .option(
      "--repair",
      "Preview and repair datastore issues: catalog index completeness, root-level unmigrated data, and foreign namespace contamination (add -y to execute).",
    )
    .option(
      "-y, --yes",
      "Execute the repair (without this, --repair shows a preview).",
    ),
).action(async function (options: AnyOptions) {
  const cliCtx = createContext(options as GlobalOptions, [
    "doctor",
    "datastores",
  ]);
  cliCtx.logger.debug("Executing doctor datastores command");

  const server = resolveServeUrl(options.server as string | undefined);
  if (server) {
    const token = await resolveServerToken(
      server,
      options.token as string | undefined,
    );
    const response = await requestServerResponse<DoctorDatastoresResponse>(
      { server, token },
      {
        type: "doctor.datastores",
        payload: {},
      },
    );
    const renderer = createDoctorDatastoresRenderer(cliCtx.outputMode);
    await consumeStream(
      (async function* () {
        yield {
          kind: "completed" as const,
          data: response.data as unknown as DoctorDatastoresData,
        };
      })(),
      renderer.handlers(),
    );
    if (renderer.overallStatus === "fail") {
      Deno.exit(1);
    }
    return;
  }

  if (options.yes && !options.repair) {
    throw new UserError("The --yes flag requires --repair.");
  }

  const repoDir = resolveRepoDir(options.repoDir);
  await resolveDatastoreForRepo(repoDir);
  const libCtx = createLibSwampContext();

  if (options.repair) {
    let exitCode = 0;

    let unmigratedDeps: RepairUnmigratedDataDeps | null = null;
    try {
      unmigratedDeps = await createUnmigratedRepairDeps(repoDir);
    } catch (error) {
      if (error instanceof UserError) {
        cliCtx.logger.debug`Skipping unmigrated data repair: ${error.message}`;
      } else {
        throw error;
      }
    }

    if (unmigratedDeps) {
      const unmigratedRenderer = createUnmigratedDataRepairRenderer(
        cliCtx.outputMode,
      );

      await consumeStream(
        repairUnmigratedData(libCtx, unmigratedDeps, {
          confirm: Boolean(options.yes),
        }),
        unmigratedRenderer.handlers(),
      );

      if (unmigratedRenderer.overallStatus === "fail") {
        exitCode = 1;
      }
    }

    // Catalog repair runs before contamination repair: contamination repair
    // ends by invalidating the catalog itself, so running it first would leave
    // the completeness check comparing against a catalog that no longer exists.
    const catalogRenderer = createCatalogIndexRepairRenderer(cliCtx.outputMode);
    await consumeStream(
      repairCatalogIndex(libCtx, createCatalogRepairDeps(repoDir), {
        confirm: Boolean(options.yes),
      }),
      catalogRenderer.handlers(),
    );
    if (catalogRenderer.overallStatus === "fail") {
      exitCode = 1;
    }

    const dupLatestRenderer = createCatalogDuplicateLatestRepairRenderer(
      cliCtx.outputMode,
    );
    await consumeStream(
      repairCatalogDuplicateLatest(
        libCtx,
        createDuplicateLatestRepairDeps(repoDir),
        { confirm: Boolean(options.yes) },
      ),
      dupLatestRenderer.handlers(),
    );
    if (dupLatestRenderer.overallStatus === "fail") {
      exitCode = 1;
    }

    let contaminationDeps: RepairDatastoresDeps | null = null;
    try {
      contaminationDeps = await createRepairDeps(repoDir);
    } catch (error) {
      if (error instanceof UserError) {
        cliCtx.logger
          .debug`Skipping namespace contamination repair: ${error.message}`;
      } else {
        throw error;
      }
    }

    if (!contaminationDeps) {
      if (exitCode !== 0) Deno.exit(1);
      return;
    }

    const deps = contaminationDeps;
    const renderer = createRepairDatastoresRenderer(cliCtx.outputMode);

    await consumeStream(
      repairDatastoreContamination(libCtx, deps, {
        confirm: Boolean(options.yes),
      }),
      renderer.handlers(),
    );

    cliCtx.logger.debug("doctor datastores repair completed");

    if (renderer.overallStatus === "fail" || exitCode !== 0) {
      Deno.exit(1);
    }
    return;
  }

  const deps = await createDoctorDatastoresDeps(repoDir);
  const renderer = createDoctorDatastoresRenderer(cliCtx.outputMode);

  await consumeStream(
    doctorDatastores(libCtx, deps),
    renderer.handlers(),
  );

  cliCtx.logger.debug("doctor datastores command completed");

  if (renderer.overallStatus === "fail") {
    Deno.exit(1);
  }
});
