// Swamp, an Automation Framework
// Copyright (C) 2026 Elder Swamp Club, Inc.
//
// This file is part of Swamp.
//
// Swamp is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License version 3
// as published by the Free Software Foundation, with the Swamp
// Extension and Definition Exception (found in the "COPYING-EXCEPTION"
// file).
//
// Swamp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with Swamp.  If not, see <https://www.gnu.org/licenses/>.

import { Command } from "@cliffy/command";
import { relative } from "@std/path";
import {
  createContext,
  type GlobalOptions,
  resolveRepoDir,
} from "../context.ts";
import { requireRepoMarker } from "../repo_context.ts";
import { resolveManagedConfigPaths } from "../repo_context.ts";
import { createInstallContext, parseExtensionRef } from "./extension_pull.ts";
import {
  consumeStream,
  createExtensionUpdateDeps,
  createLibSwampContext,
  extensionUpdate,
  type ExtensionUpdateResult,
  UpgradeExtensionService,
  warnLegacyExtensionLayout,
} from "../../libswamp/mod.ts";
import { ExtensionRepository } from "../../infrastructure/persistence/extension_repository.ts";
import { ExtensionCatalogStore } from "../../infrastructure/persistence/extension_catalog_store.ts";
import { EmbeddedDenoRuntime } from "../../infrastructure/runtime/embedded_deno_runtime.ts";
import { swampPath } from "../../infrastructure/persistence/paths.ts";
import { createExtensionUpdateRenderer } from "../../presentation/renderers/extension_update.ts";
import { resolveUniqueLocalSkillsDirs } from "../../domain/repo/skill_dirs.ts";
import { DEFAULT_SWAMP_CLUB_URL } from "../../domain/auth/auth_credentials.ts";
import { loadIdentity } from "../load_identity.ts";
import {
  requestServerResponse,
  resolveServerToken,
  resolveServeUrl,
  warnServerReloadNeeded,
  withRemoteOptions,
} from "../remote_run.ts";
import type { ExtensionUpdateResponse } from "../../serve/protocol.ts";

// deno-lint-ignore no-explicit-any
type AnyOptions = any;

function resolveServerUrl(): string {
  return Deno.env.get("SWAMP_CLUB_URL") ?? DEFAULT_SWAMP_CLUB_URL;
}

export const extensionUpdateCommand = withRemoteOptions(
  new Command()
    .name("update")
    .description("Update installed extensions to latest versions")
    .example("Update all extensions", "swamp extension update")
    .example("Update one extension", "swamp extension update @stack72/aws-ec2")
    .example("Check for updates", "swamp extension update --check")
    .arguments("[extension:string]")
    .option(
      "--repo-dir <dir:string>",
      "Repository directory (env: SWAMP_REPO_DIR)",
    )
    .option("--check", "Show what's outdated without pulling"),
).action(async function (options: AnyOptions, extensionArg?: string) {
  const cliCtx = createContext(options as GlobalOptions, [
    "extension",
    "update",
  ]);
  cliCtx.logger.debug`Starting extension update`;

  const server = resolveServeUrl(options.server as string | undefined);
  if (server) {
    const token = await resolveServerToken(
      server,
      options.token as string | undefined,
    );
    const response = await requestServerResponse<ExtensionUpdateResponse>(
      { server, token, timeoutMs: 300_000 },
      {
        type: "extension.update",
        payload: {
          extensionName: extensionArg
            ? parseExtensionRef(extensionArg).name
            : undefined,
          checkOnly: !!options.check,
        },
      },
    );
    const renderer = createExtensionUpdateRenderer(cliCtx.outputMode);
    const mode = options.check ? "check" : "update";
    await consumeStream(
      (async function* () {
        yield {
          kind: "completed" as const,
          data: response.data as unknown as ExtensionUpdateResult,
          mode: mode as "check" | "update",
        };
      })(),
      renderer.handlers(),
    );
    if (!options.check) {
      warnServerReloadNeeded(server);
    }
    return;
  }

  // 1. Validate repo (lightweight — no datastore resolution, so updating
  // the repo's own datastore extension doesn't circular-fail; see #445)
  const { repoDir, marker } = await requireRepoMarker(
    resolveRepoDir(options.repoDir),
  );
  const { lockfilePath } = resolveManagedConfigPaths(repoDir, marker);

  // Per-extension models/workflows/vaults/datastores/reports
  // destinations are derived inside installExtension from the
  // extension's scoped name. Only skillsDir is tool-dependent.
  const tools = marker?.tools?.length ? marker.tools : ["claude"];
  const skillsDirs = resolveUniqueLocalSkillsDirs(repoDir, tools);

  const primarySkillsDirRelative = relative(repoDir, skillsDirs[0]);
  await warnLegacyExtensionLayout(
    lockfilePath,
    (msg) => cliCtx.logger.warn(msg),
    primarySkillsDirRelative,
  );

  // 4. Parse extension name if given
  let extensionName: string | undefined;
  if (extensionArg) {
    const ref = parseExtensionRef(extensionArg);
    extensionName = ref.name;
  }

  // 4. Wire deps — inject installExtension from CLI layer
  const serverUrl = resolveServerUrl();

  const ctx = createLibSwampContext({ logger: cliCtx.logger });
  // W2 (commit 3): construct shared denoRuntime + repository so each
  // upgrade routes through InstallExtensionService and phase 8 fires
  // (catalog populated synchronously, I-Repo-1 fires on collision,
  // FS rollback). The catalog stays open for the duration of the
  // bulk update — closed in the finally block.
  const denoRuntime = new EmbeddedDenoRuntime();
  const catalog = new ExtensionCatalogStore(
    swampPath(repoDir, "_extension_catalog.db"),
  );
  try {
    const identity = await loadIdentity();
    const deps = await createExtensionUpdateDeps({
      lockfilePath,
      serverUrl,
      identity,
      installExtension: async (
        name: string,
        version: string,
        channel?: string,
      ) => {
        // Construct a fresh InstallContext per upgrade — captures a
        // current snapshot of the lockfile per the
        // InstallContext.lockfileRepository single-use rule. Reusing one
        // context across multiple installs would expose stale state.
        const installCtx = await createInstallContext(serverUrl, {
          logger: cliCtx.logger,
          lockfilePath,
          skillsDirs,
          repoDir,
          force: true,
          identity,
          channel,
        });
        // Build a fresh ExtensionRepository per upgrade so its lockfile
        // snapshot lines up with the InstallContext's. Catalog is
        // shared across the bulk run for atomicity-of-each-upgrade.
        const repository = new ExtensionRepository({
          catalog,
          lockfileRepository: installCtx.lockfileRepository,
          repoRoot: repoDir,
        });
        // W2 (commit 5): route through UpgradeExtensionService for
        // explicit upgrade-intent at the call site. Internally this
        // delegates to InstallExtensionService whose phase 8
        // tombstones the prior version atomically (saveAll is one
        // SQLite txn).
        return await new UpgradeExtensionService({
          denoRuntime,
          repository,
        })
          .execute(name, version, installCtx);
      },
    });

    // 5. Execute and render
    const renderer = createExtensionUpdateRenderer(cliCtx.outputMode);
    await consumeStream(
      extensionUpdate(ctx, deps, {
        extensionName,
        checkOnly: !!options.check,
      }),
      renderer.handlers(),
    );
  } finally {
    catalog.close();
  }
});
