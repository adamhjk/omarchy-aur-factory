// Swamp, an Automation Framework
// Copyright (C) 2026 Elder Swamp Club, Inc.
//
// This file is part of Swamp.
//
// Swamp is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License version 3
// as published by the Free Software Foundation, with the Swamp
// Extension and Definition Exception (found in the "COPYING-EXCEPTION"
// file).
//
// Swamp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with Swamp.  If not, see <https://www.gnu.org/licenses/>.

import { Command } from "@cliffy/command";
import { groupCommandAction } from "../group_action.ts";
import {
  createContext,
  type GlobalOptions,
  resolveRepoDir,
  resolveTraceparent,
  resolveTracestate,
} from "../context.ts";
import {
  acquireModelLocks,
  requireInitializedRepoUnlocked,
} from "../repo_context.ts";
import { RepoMarkerRepository } from "../../infrastructure/persistence/repo_marker_repository.ts";
import { RepoPath } from "../../domain/repo/repo_path.ts";
import { UserError } from "../../domain/errors.ts";
import { findDefinitionByIdOrName } from "../../domain/models/model_lookup.ts";
import { resolveModelType } from "../../domain/extensions/extension_auto_resolver.ts";
import { getAutoResolver } from "../auto_resolver_context.ts";
import { DefaultMethodExecutionService } from "../../domain/models/method_execution_service.ts";
import { modelRegistry } from "../../domain/models/model.ts";
import { vaultTypeRegistry } from "../../domain/vaults/vault_type_registry.ts";
import { reportRegistry } from "../../domain/reports/report_registry.ts";
import { VaultService } from "../../domain/vaults/vault_service.ts";
import { ExpressionEvaluationService } from "../../domain/expressions/expression_evaluation_service.ts";
import { runFileSink } from "../../infrastructure/logging/logger.ts";
import { GIT_SHA } from "./version.ts";
import {
  deepMerge,
  mergeInputArgs,
  parseInputs,
  parseStdinContent,
} from "../input_parser.ts";
import { readStdin } from "../../infrastructure/io/stdin_reader.ts";
import { parseTags } from "../../libswamp/mod.ts";
import { join } from "@std/path";
import {
  SWAMP_SUBDIRS,
  swampPath,
} from "../../infrastructure/persistence/paths.ts";
import { YamlDefinitionRepository } from "../../infrastructure/persistence/yaml_definition_repository.ts";
import { SecretRedactor } from "../../domain/secrets/mod.ts";
import { DataQueryService } from "../../domain/data/data_query_service.ts";
import { modelMethodHistoryCommand } from "./model_method_history.ts";
import { modelMethodDescribeCommand } from "./model_method_describe.ts";
import { unknownCommandErrorHandler } from "../unknown_command_handler.ts";
import {
  consumeStream,
  createLibSwampContext,
  modelMethodRun,
  type ModelMethodRunDeps,
  type ModelMethodRunEvent,
} from "../../libswamp/mod.ts";
import { createModelMethodRunRenderer } from "../../presentation/renderers/model_method_run.ts";
import {
  resolveServerToken,
  resolveServeUrl,
  runModelMethodOverServer,
} from "../remote_run.ts";
import { registerShutdownHandler } from "../../infrastructure/process/shutdown_handlers.ts";
import { suppressSyncExitOnSignal } from "../../infrastructure/persistence/datastore_sync_coordinator.ts";
import { parseTimeout } from "../duration_parser.ts";
import { isAuthenticated, resolveCliInitiatedBy } from "../auth_context.ts";
import {
  DEFAULT_STALE_TTL_MS,
  RunTrackerStore,
} from "../../infrastructure/persistence/run_tracker_store.ts";

// Cliffy's custom type system returns `unknown` for custom types like `model_name`,
// but we need to pass `options` to functions expecting specific types. Using `any`
// here is the pragmatic workaround for Cliffy's type inference limitations.
// deno-lint-ignore no-explicit-any
type AnyOptions = any;

export const modelMethodRunCommand = new Command()
  .name("run")
  .description("Execute a method on a model")
  .example("Run a method", "swamp model method run my-server getSystemInfo")
  .example(
    "Run with inputs",
    "swamp model method run my-server deploy --input env=prod",
  )
  .example(
    "Direct type execution",
    "swamp model @swamp/aws/ec2/vpc method run create my-vpc --input region=us-east-1",
  )
  .example(
    "Pass an array or object input (JSON-typed via :json suffix)",
    'swamp model method run my-server search --input \'keywords:json=["a","b"]\'',
  )
  .example(
    "Pipe inputs from stdin",
    'echo \'{"env":"prod"}\' | swamp model method run my-server deploy --stdin',
  )
  .example(
    "Batch run via NDJSON from stdin",
    'printf \'{"env":"dev"}\\n{"env":"prod"}\' | swamp model method run my-server deploy --stdin',
  )
  .description(
    `Execute a method on a model. With @type prefix, auto-creates the definition if needed.

When --json is set, errors are written to stderr as a JSON envelope:

    { "error": "<message>", "code": "<error_code>" }

The "code" field is a stable, machine-readable identifier. Callers should match on "code" rather than parsing the error message. Known codes for this command:

    lock_timeout             Another invocation holds the model lock (exit 75)
    model_not_found          No model matches the given name
    unknown_model_type       The @type prefix does not match any installed type
    unknown_method           The model does not define the requested method
    no_evaluated_definition  No evaluated definition exists (use --last-evaluated)
    missing_deps             Required extension dependencies are not installed
    method_execution_failed  The method's execution driver returned an error
    not_authenticated        Not signed in (run 'swamp auth login')
    cancelled                Operation was cancelled (e.g. Ctrl+C)

Exit codes: 0 = success, 1 = general error, 75 = lock contention (temporary — retry with backoff).`,
  )
  .arguments(
    "<model_or_type:model_name> <method_name:string> [definition_name:string]",
  )
  .option(
    "--repo-dir <dir:string>",
    "Repository directory (env: SWAMP_REPO_DIR)",
  )
  .option(
    "--last-evaluated",
    "Skip CEL evaluation, use previously evaluated definition",
    { default: false },
  )
  .option("--input <value:string>", "Input values (key=value or JSON)", {
    collect: true,
  })
  .option("--arg <value:string>", "Alias for --input", {
    collect: true,
    hidden: true,
  })
  .option(
    "--input-file <file:string>",
    "Input values from YAML file (cannot combine with --stdin)",
  )
  .option("--stdin", "Read inputs from stdin (piped data)", { default: false })
  .option(
    "--tag <tag:string>",
    "Add tag to produced data (KEY=VALUE, repeatable)",
    { collect: true },
  )
  .option(
    "--skip-check <name:string>",
    "Skip a specific pre-flight check by name",
    { collect: true },
  )
  .option(
    "--skip-check-label <label:string>",
    "Skip pre-flight checks with this label",
    { collect: true },
  )
  .option("--skip-checks", "Skip all pre-flight checks", { default: false })
  .option("--skip-reports", "Skip all post-run reports", { default: false })
  .option(
    "--skip-report <name:string>",
    "Skip a specific post-run report by name",
    { collect: true },
  )
  .option(
    "--skip-report-label <label:string>",
    "Skip post-run reports with this label",
    { collect: true },
  )
  .option(
    "--report <name:string>",
    "Run only this report (inclusion filter)",
    { collect: true },
  )
  .option(
    "--report-label <label:string>",
    "Run only reports with this label (inclusion filter)",
    { collect: true },
  )
  .option(
    "--timeout <duration:string>",
    "Cancellation deadline — seconds (e.g. 30, 1800) or duration string (e.g. 30s, 5m, 1h). Cooperative — only honored by methods that check AbortSignal.",
  )
  .option(
    "--server <url:string>",
    "Run through a 'swamp serve' server (ws:// or http://) instead of locally; no local repo required (env: SWAMP_SERVE_URL).",
  )
  .option(
    "--token <token:string>",
    "Server token in <name>.<secret> format; only applies with --server (overrides stored credentials and SWAMP_SERVER_TOKEN)",
  )
  .option(
    "--traceparent <value:string>",
    "W3C traceparent for per-invocation trace context (env: TRACEPARENT)",
  )
  .option(
    "--tracestate <value:string>",
    "W3C tracestate for per-invocation trace context (env: TRACESTATE)",
  )
  .action(
    // @ts-expect-error - Cliffy custom type returns unknown instead of string
    async function (
      options: AnyOptions,
      modelOrType: string,
      methodName: string,
      definitionNameArg?: string,
    ) {
      const isDirectExecution = modelOrType.startsWith("@");

      if (isDirectExecution && !definitionNameArg) {
        throw new UserError(
          "Direct type execution requires a definition name: " +
            `swamp model ${modelOrType} method run ${methodName} <name>`,
        );
      }

      const typeArg = isDirectExecution ? modelOrType : undefined;
      const modelIdOrName = isDirectExecution
        ? definitionNameArg!
        : modelOrType;
      const definitionName = isDirectExecution ? definitionNameArg : undefined;

      const server = resolveServeUrl(options.server as string | undefined);
      if (server) {
        await runMethodViaServer(
          { ...options, server },
          modelIdOrName,
          methodName,
          { typeArg, definitionName },
        );
        return;
      }
      const ctx = createContext(options as GlobalOptions, [
        "model",
        "method",
        "run",
      ]);
      const { repoDir, repoContext, datastoreConfig, syncService } =
        await requireInitializedRepoUnlocked({
          repoDir: resolveRepoDir(options.repoDir),
          outputMode: ctx.outputMode,
        });

      const runTracker = RunTrackerStore.fromSwampDir(swampPath(repoDir));
      try {
        runTracker.reapStaleRuns(DEFAULT_STALE_TTL_MS);

        const marker = await new RepoMarkerRepository().read(
          RepoPath.create(repoDir),
        );
        const autoGc = marker?.autoGc === true;

        ctx.logger
          .debug`Running method '${methodName}' on model: ${modelIdOrName}`;

        const stdinContent = options.stdin ? await readStdin() : null;
        let stdinItems: Record<string, unknown>[] | null = null;
        if (stdinContent !== null) {
          if (options.inputFile) {
            throw new UserError(
              "Cannot combine --stdin with --input-file.",
            );
          }
          stdinItems = parseStdinContent(stdinContent);
        }

        const { inputs: cliInputs } = await parseInputs({
          input: mergeInputArgs(options),
          inputFile: stdinItems
            ? undefined
            : options.inputFile as string | undefined,
        });

        // Parse runtime tags
        const runtimeTags = options.tag
          ? parseTags(options.tag as string[])
          : undefined;

        // Load all extension registries needed for method execution in parallel
        await Promise.all([
          modelRegistry.ensureLoaded(),
          vaultTypeRegistry.ensureLoaded(),
          reportRegistry.ensureLoaded(),
        ]);

        const deps: ModelMethodRunDeps = {
          repoDir,
          lookupDefinition: (idOrName) =>
            findDefinitionByIdOrName(repoContext.definitionRepo, idOrName),
          getModelDef: (type) => resolveModelType(type, getAutoResolver()),
          createEvaluationService: () => {
            const dqs = new DataQueryService(
              repoContext.catalogStore,
              repoContext.unifiedDataRepo,
            );
            return new ExpressionEvaluationService(
              repoContext.definitionRepo,
              repoDir,
              {
                dataRepo: repoContext.unifiedDataRepo,
                dataQueryService: dqs,
              },
            );
          },
          loadEvaluatedDefinition: (type, name) =>
            repoContext.evaluatedDefinitionRepo.findByName(type, name),
          saveEvaluatedDefinition: (type, definition) =>
            repoContext.evaluatedDefinitionRepo.save(type, definition),
          createExecutionService: () => new DefaultMethodExecutionService(),
          createVaultService: () =>
            VaultService.fromRepository(repoDir, {
              defaultVaultName: marker?.defaultVault,
            }),
          dataRepo: repoContext.unifiedDataRepo,
          definitionRepo: repoContext.definitionRepo,
          outputRepo: repoContext.outputRepo,
          dataQueryService: new DataQueryService(
            repoContext.catalogStore,
            repoContext.unifiedDataRepo,
          ),
          createRunLog: async (modelType, method, definitionId) => {
            const redactor = new SecretRedactor();
            const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
            const logFilePath = join(
              swampPath(repoDir, SWAMP_SUBDIRS.outputs),
              modelType.normalized,
              method,
              `${definitionId}-${timestamp}.log`,
            );
            const logHandle = await runFileSink.register(
              [],
              logFilePath,
              redactor,
              swampPath(repoDir),
            );
            return {
              logFilePath,
              redactor,
              cleanup: () => runFileSink.unregister(logHandle),
            };
          },
          createAndSaveDefinition: isDirectExecution
            ? async (type, definition) => {
              const autoDefRepo = new YamlDefinitionRepository(
                repoDir,
                undefined,
                repoContext.autoDefinitionsDir,
                false,
              );
              await autoDefRepo.save(type, definition);
            }
            : undefined,
          getDefinitionPath: isDirectExecution
            ? (type, id) => {
              return join(
                repoContext.autoDefinitionsDir,
                type.toDirectoryPath(),
                `${id}.yaml`,
              );
            }
            : undefined,
          autoDefinitionsDir: isDirectExecution
            ? repoContext.autoDefinitionsDir
            : undefined,
          runTracker,
          workflowRepo: repoContext.workflowRepo,
          workflowRunRepo: repoContext.workflowRunRepo,
        };

        const timeoutMs = options.timeout
          ? parseTimeout(options.timeout as string)
          : undefined;
        const abort = new AbortController();
        const exitSuppress = suppressSyncExitOnSignal();
        const shutdownHandle = registerShutdownHandler({
          handler: () => abort.abort(),
          forceExitOnRepeat: true,
        });
        const baseLibCtx = createLibSwampContext({ signal: abort.signal });
        const libCtx = timeoutMs !== undefined
          ? baseLibCtx.withTimeout(timeoutMs)
          : baseLibCtx;

        // Pre-lookup for per-model lock acquisition (reads YAML — no lock needed)
        const preResult = await findDefinitionByIdOrName(
          repoContext.definitionRepo,
          modelIdOrName,
        );
        let flushModelLocks: (() => Promise<void>) | null = null;
        if (preResult) {
          const lockResult = await acquireModelLocks(
            datastoreConfig,
            [
              {
                modelType: preResult.type.normalized,
                modelId: preResult.definition.id,
              },
            ],
            repoDir,
            syncService,
            repoContext.catalogStore,
          );
          if (lockResult.synced) repoContext.catalogStore.invalidate();
          flushModelLocks = lockResult.flush;
        }

        const initiatedBy = await resolveCliInitiatedBy();

        // Build the list of input sets to iterate over
        const inputSets: Record<string, unknown>[] = stdinItems
          ? stdinItems.map((item) =>
            Object.keys(cliInputs).length > 0
              ? deepMerge(item, cliInputs)
              : item
          )
          : [cliInputs];

        try {
          for (let i = 0; i < inputSets.length; i++) {
            if (inputSets.length > 1) {
              ctx.logger
                .info`Running method ${methodName} [${
                i + 1
              }/${inputSets.length}]`;
            }

            const renderer = createModelMethodRunRenderer(ctx.outputMode, {
              modelName: modelIdOrName,
              methodName,
              isAuthenticated: isAuthenticated(),
              quiet: ctx.verbosity === "quiet",
            });

            await consumeStream(
              modelMethodRun(libCtx, deps, {
                modelIdOrName,
                methodName,
                inputs: inputSets[i],
                lastEvaluated: options.lastEvaluated as boolean,
                typeArg,
                definitionName,
                runtimeTags,
                skipCheckNames: options.skipCheck as string[] | undefined,
                skipCheckLabels: options.skipCheckLabel as string[] | undefined,
                skipAllChecks: options.skipChecks as boolean | undefined,
                skipReportNames: options.skipReport as string[] | undefined,
                skipReportLabels: options.skipReportLabel as
                  | string[]
                  | undefined,
                skipAllReports: options.skipReports as boolean | undefined,
                reportNames: options.report as string[] | undefined,
                reportLabels: options.reportLabel as string[] | undefined,
                swampSha: GIT_SHA || undefined,
                autoGc,
                traceparent: resolveTraceparent(
                  options.traceparent as string | undefined,
                ),
                tracestate: resolveTracestate(
                  options.tracestate as string | undefined,
                ),
                initiatedBy,
              }),
              renderer.handlers(),
            );

            if (abort.signal.aborted) {
              Deno.exitCode = 1;
              return;
            }

            if (renderer.runFailed()) {
              Deno.exitCode = 1;
              return;
            }
          }
        } catch (error) {
          if (error instanceof UserError) {
            throw error;
          }
          const message = error instanceof Error
            ? error.message
            : String(error);
          throw new UserError(`Method execution failed: ${message}`);
        } finally {
          shutdownHandle.dispose();
          exitSuppress.dispose();
          if (flushModelLocks) {
            try {
              await flushModelLocks();
            } catch (releaseError) {
              ctx.logger.warn(
                "Failed to release locks during cleanup: {error}",
                {
                  error: releaseError instanceof Error
                    ? releaseError.message
                    : String(releaseError),
                },
              );
            }
          }
        }

        ctx.logger.debug("Method run command completed");
      } finally {
        runTracker.close();
      }
    },
  );

export const modelMethodCommand = new Command()
  .name("method")
  .description("Execute model methods")
  .error(unknownCommandErrorHandler)
  .action(groupCommandAction)
  .command("run", modelMethodRunCommand)
  .command("describe", modelMethodDescribeCommand)
  .command("history", modelMethodHistoryCommand);

/**
 * The --server branch: dispatch the method run through a `swamp serve`
 * server and render the streamed events with the same renderer a local run
 * uses. No local repository is required.
 */
async function runMethodViaServer(
  options: AnyOptions,
  modelIdOrName: string,
  methodName: string,
  info: { typeArg?: string; definitionName?: string },
): Promise<void> {
  const ctx = createContext(options as GlobalOptions, [
    "model",
    "method",
    "run",
  ]);
  const stdinContent = options.stdin ? await readStdin() : null;
  let stdinItems: Record<string, unknown>[] | null = null;
  if (stdinContent !== null) {
    if (options.inputFile) {
      throw new UserError("Cannot combine --stdin with --input-file.");
    }
    stdinItems = parseStdinContent(stdinContent);
  }
  const { inputs: cliInputs } = await parseInputs({
    input: mergeInputArgs(options),
    inputFile: stdinItems ? undefined : options.inputFile as string | undefined,
  });
  const runtimeTags = options.tag
    ? parseTags(options.tag as string[])
    : undefined;

  const abort = new AbortController();
  if (options.timeout) {
    const timeoutMs = parseTimeout(options.timeout as string);
    setTimeout(() => abort.abort(), timeoutMs);
  }
  const shutdown = registerShutdownHandler({
    handler: () => abort.abort(),
    forceExitOnRepeat: true,
  });

  const inputSets: Record<string, unknown>[] = stdinItems
    ? stdinItems.map((item) =>
      Object.keys(cliInputs).length > 0 ? deepMerge(item, cliInputs) : item
    )
    : [cliInputs];

  const token = await resolveServerToken(
    options.server as string,
    options.token as string | undefined,
  );

  try {
    for (let i = 0; i < inputSets.length; i++) {
      if (inputSets.length > 1) {
        ctx.logger
          .info`Running method ${methodName} [${
          i + 1
        }/${inputSets.length}] via ${options.server}`;
      }
      const renderer = createModelMethodRunRenderer(ctx.outputMode, {
        modelName: modelIdOrName,
        methodName,
        isAuthenticated: isAuthenticated(),
        quiet: ctx.verbosity === "quiet",
      });
      await consumeStream(
        runModelMethodOverServer({
          server: options.server as string,
          token,
          signal: abort.signal,
          payload: {
            modelIdOrName,
            methodName,
            inputs: inputSets[i],
            lastEvaluated: options.lastEvaluated as boolean,
            runtimeTags,
            typeArg: info.typeArg,
            definitionName: info.definitionName,
            skipAllReports: options.skipReports as boolean | undefined,
            skipReportNames: options.skipReport as string[] | undefined,
            skipReportLabels: options.skipReportLabel as
              | string[]
              | undefined,
            reportNames: options.report as string[] | undefined,
            reportLabels: options.reportLabel as string[] | undefined,
            skipAllChecks: options.skipChecks as boolean | undefined,
            skipCheckNames: options.skipCheck as string[] | undefined,
            skipCheckLabels: options.skipCheckLabel as
              | string[]
              | undefined,
            traceparent: resolveTraceparent(
              options.traceparent as string | undefined,
            ),
            tracestate: resolveTracestate(
              options.tracestate as string | undefined,
            ),
          },
        }) as AsyncIterable<ModelMethodRunEvent>,
        renderer.handlers(),
      );
      if (renderer.runFailed()) {
        Deno.exitCode = 1;
        return;
      }
    }
  } finally {
    shutdown.dispose();
  }
}
