// Swamp, an Automation Framework
// Copyright (C) 2026 Elder Swamp Club, Inc.
//
// This file is part of Swamp.
//
// Swamp is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License version 3
// as published by the Free Software Foundation, with the Swamp
// Extension and Definition Exception (found in the "COPYING-EXCEPTION"
// file).
//
// Swamp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with Swamp.  If not, see <https://www.gnu.org/licenses/>.

import { Command } from "@cliffy/command";
import { relative } from "@std/path";
import {
  createContext,
  type GlobalOptions,
  interactiveOutputMode,
} from "../context.ts";
import { requireRepoMarker } from "../repo_context.ts";
import { resolveManagedConfigPaths } from "../repo_context.ts";
import { UserError } from "../../domain/errors.ts";
import { ReleaseChannel } from "../../domain/extensions/release_channel.ts";
import {
  ExtensionApiClient,
} from "../../infrastructure/http/extension_api_client.ts";
import {
  LockfileRepository,
  type PullContext,
  pullExtension,
} from "./extension_pull.ts";
import {
  consumeStream,
  createLibSwampContext,
  extensionSearch,
  type ExtensionSearchData,
  type ExtensionSearchDeps,
  warnLegacyExtensionLayout,
} from "../../libswamp/mod.ts";
import { createExtensionSearchRenderer } from "../../presentation/renderers/extension_search.tsx";
import { resolveUniqueLocalSkillsDirs } from "../../domain/repo/skill_dirs.ts";
import { DEFAULT_SWAMP_CLUB_URL } from "../../domain/auth/auth_credentials.ts";
import { loadIdentity } from "../load_identity.ts";
import {
  requestServerResponse,
  resolveServerToken,
  resolveServeUrl,
  withRemoteOptions,
} from "../remote_run.ts";
import type { ExtensionSearchResponse } from "../../serve/protocol.ts";

/**
 * Resolves the registry server URL.
 * Priority: SWAMP_CLUB_URL env var > DEFAULT_SWAMP_CLUB_URL
 */
function resolveServerUrl(): string {
  return Deno.env.get("SWAMP_CLUB_URL") ?? DEFAULT_SWAMP_CLUB_URL;
}

// deno-lint-ignore no-explicit-any
type AnyOptions = any;

export const extensionSearchCommand = withRemoteOptions(
  new Command()
    .name("search")
    .description("Search the swamp extension registry")
    .arguments("[query:string]")
    .option("--collective <collective:string>", "Filter by collective")
    .option("--platform <platform:string>", "Filter by platform", {
      collect: true,
    })
    .option("--label <label:string>", "Filter by label", { collect: true })
    .option(
      "--content-type <contentType:string>",
      "Filter by content type (models, workflows, vaults, datastores, reports)",
      { collect: true },
    )
    .option(
      "--sort <sort:string>",
      "Sort order: relevance, new, updated, name",
    )
    .option(
      "--channel <channel:string>",
      "Filter by release channel: 'beta', 'rc', or 'stable' (default: stable only)",
      { collect: true },
    )
    .option("--per-page <perPage:number>", "Results per page", { default: 20 })
    .option("--page <page:number>", "Page number", { default: 1 })
    .example("Browse all extensions", "swamp extension search")
    .example("Search by keyword", "swamp extension search aws")
    .example(
      "Filter by collective",
      "swamp extension search --collective stack72",
    )
    .example(
      "Filter by platform and label",
      "swamp extension search --platform aws --label networking",
    )
    .example(
      "Filter by content type",
      "swamp extension search --content-type models",
    )
    .example(
      "Sort by newest",
      "swamp extension search --sort new",
    ),
).action(async function (options: AnyOptions, query?: string) {
  const ctx = createContext(options as GlobalOptions, [
    "extension",
    "search",
  ]);

  // Validate sort + query combination
  if (options.sort === "relevance" && !query) {
    throw new UserError(
      'Sort by "relevance" requires a search query.',
    );
  }

  // Validate content type values
  const validContentTypes = [
    "models",
    "workflows",
    "vaults",
    "datastores",
    "reports",
  ];
  for (const ct of options.contentType ?? []) {
    if (!validContentTypes.includes(ct)) {
      throw new UserError(
        `Invalid content type: "${ct}". Must be one of: ${
          validContentTypes.join(", ")
        }`,
      );
    }
  }

  // Validate channel values
  for (const ch of options.channel ?? []) {
    if (!ReleaseChannel.isValid(ch)) {
      throw new UserError(
        `Invalid channel: "${ch}". Must be one of: beta, rc, stable.`,
      );
    }
  }
  if (options.channel) {
    const hasNonStable = options.channel.some((ch: string) => ch !== "stable");
    if (!hasNonStable) {
      options.channel = [];
    }
  }

  // Validate sort option value
  const validSorts = ["relevance", "new", "updated", "name"];
  if (options.sort && !validSorts.includes(options.sort)) {
    throw new UserError(
      `Invalid sort option: "${options.sort}". Must be one of: ${
        validSorts.join(", ")
      }`,
    );
  }

  const remoteServer = resolveServeUrl(
    options.server as string | undefined,
  );
  if (remoteServer) {
    const token = await resolveServerToken(
      remoteServer,
      options.token as string | undefined,
    );
    const response = await requestServerResponse<ExtensionSearchResponse>(
      { server: remoteServer, token },
      {
        type: "extension.search",
        payload: {
          query,
          collective: options.collective,
          platform: options.platform,
          label: options.label,
          contentType: options.contentType,
          channel: options.channel,
          sort: options.sort,
          perPage: options.perPage,
          page: options.page,
        },
      },
    );
    const effectiveMode = interactiveOutputMode(ctx);
    const renderer = createExtensionSearchRenderer(effectiveMode);
    await consumeStream(
      (async function* () {
        yield {
          kind: "completed" as const,
          data: response.data as unknown as ExtensionSearchData,
        };
      })(),
      renderer.handlers(),
    );
    return;
  }

  const identity = await loadIdentity();
  const serverUrl = resolveServerUrl();
  const client = new ExtensionApiClient(serverUrl, identity);
  const effectiveMode = interactiveOutputMode(ctx);
  const libCtx = createLibSwampContext();

  ctx.logger.debug`Searching extensions with query: ${query ?? "(none)"}`;

  const deps: ExtensionSearchDeps = {
    searchExtensions: (params) =>
      client.searchExtensions(
        {
          ...params,
          sort: params.sort as
            | "name"
            | "relevance"
            | "new"
            | "updated"
            | undefined,
        },
        identity.bearerToken,
      ),
  };

  const renderer = createExtensionSearchRenderer(effectiveMode);
  await consumeStream(
    extensionSearch(
      libCtx,
      deps,
      {
        query,
        collective: options.collective,
        platform: options.platform,
        label: options.label,
        contentType: options.contentType,
        channel: options.channel,
        sort: options.sort,
        perPage: options.perPage,
        page: options.page,
      },
    ),
    renderer.handlers(),
  );

  const selected = renderer.selectedItem();
  const action = renderer.selectedAction();

  if (selected && action === "install") {
    // Extension install writes to local files only (pulled-extensions/,
    // lockfile) — no datastore needed; see #445.
    const { repoDir, marker } = await requireRepoMarker(".");
    const { lockfilePath } = resolveManagedConfigPaths(repoDir, marker);

    const tools = marker?.tools?.length ? marker.tools : ["claude"];
    const skillsDirs = resolveUniqueLocalSkillsDirs(repoDir, tools);
    const primarySkillsDirRelative = relative(repoDir, skillsDirs[0]);
    await warnLegacyExtensionLayout(
      lockfilePath,
      (msg) => ctx.logger.warn(msg),
      primarySkillsDirRelative,
    );

    const lockfileRepository = await LockfileRepository.create(lockfilePath);
    const apiKey = identity.bearerToken;
    const pullCtx: PullContext = {
      getExtension: (name) => client.getExtension(name, apiKey),
      downloadArchive: (name, version, channel) =>
        client.downloadArchive(name, version, apiKey, channel),
      getChecksum: (name, version, channel) =>
        client.getChecksum(name, version, apiKey, channel),
      logger: ctx.logger,
      lockfileRepository,
      skillsDirs,
      repoDir,
      force: false,
      outputMode: ctx.outputMode,
      alreadyPulled: new Set(),
      depth: 0,
    };

    await pullExtension(
      { name: selected.name, version: null },
      pullCtx,
    );
  }
});
