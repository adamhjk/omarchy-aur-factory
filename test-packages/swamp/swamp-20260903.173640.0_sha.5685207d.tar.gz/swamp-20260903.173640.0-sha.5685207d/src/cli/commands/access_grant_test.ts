// Swamp, an Automation Framework
// Copyright (C) 2026 Elder Swamp Club, Inc.
//
// This file is part of Swamp.
//
// Swamp is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License version 3
// as published by the Free Software Foundation, with the Swamp
// Extension and Definition Exception (found in the "COPYING-EXCEPTION"
// file).
//
// Swamp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with Swamp.  If not, see <https://www.gnu.org/licenses/>.

import { assertEquals } from "@std/assert";
import { Command } from "@cliffy/command";
import { initializeLogging } from "../../infrastructure/logging/logger.ts";

// Import models barrel to trigger self-registration
import "../../domain/models/models.ts";

// Initialize logging for tests
await initializeLogging({});

/**
 * In-process serve endpoint streaming the given run events followed by a
 * `done` frame — enough to drive the command's streaming --server path
 * without a subprocess.
 */
function runEventServer(
  events: Record<string, unknown>[],
): { url: string; shutdown: () => Promise<void> } {
  const server = Deno.serve(
    { port: 0, hostname: "127.0.0.1", onListen: () => {} },
    (req) => {
      const { socket, response } = Deno.upgradeWebSocket(req);
      socket.onmessage = (message) => {
        const request = JSON.parse(message.data as string) as { id: string };
        for (const event of events) {
          socket.send(
            JSON.stringify({ type: "event", id: request.id, event }),
          );
        }
        socket.send(JSON.stringify({ type: "done", id: request.id }));
      };
      return response;
    },
  );
  return {
    url: `ws://127.0.0.1:${server.addr.port}`,
    shutdown: () => server.shutdown(),
  };
}

/** Runs `access grant create` against a scripted run result; returns Deno.exitCode. */
async function runGrantCreateAgainst(
  run: Record<string, unknown>,
): Promise<number> {
  const server = runEventServer([{ kind: "completed", run }]);
  const previousExitCode = Deno.exitCode;
  Deno.exitCode = 0;
  try {
    const { accessGrantCommand } = await import("./access_grant.ts");
    const root = new Command()
      .globalOption("--json", "JSON output")
      .command("grant", accessGrantCommand);
    await root.parse([
      "grant",
      "create",
      "--subject",
      "user:adam",
      "--allow",
      "run",
      "--on",
      "workflow:@acme/deploy",
      "--json",
      "--server",
      server.url,
      "--token",
      "test.token",
    ]);
    return Deno.exitCode;
  } finally {
    Deno.exitCode = previousExitCode;
    await server.shutdown();
  }
}

Deno.test("accessGrantCommand: module loads", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  assertEquals(accessGrantCommand.getName(), "grant");
});

Deno.test("accessGrantCommand: has policy alias", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  assertEquals(accessGrantCommand.getAliases().includes("policy"), true);
});

Deno.test("accessGrantCommand: has correct description", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  assertEquals(
    accessGrantCommand.getDescription(),
    "Manage authorization grants",
  );
});

Deno.test("accessGrantCommand: has create subcommand", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const createCmd = commands.find((c) => c.getName() === "create");
  assertEquals(createCmd !== undefined, true);
});

Deno.test("accessGrantCommand: has list subcommand", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const listCmd = commands.find((c) => c.getName() === "list");
  assertEquals(listCmd !== undefined, true);
});

Deno.test("accessGrantCommand: has revoke subcommand", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const revokeCmd = commands.find((c) => c.getName() === "revoke");
  assertEquals(revokeCmd !== undefined, true);
});

Deno.test("accessGrantCommand: create has --subject option", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const createCmd = commands.find((c) => c.getName() === "create")!;
  const options = createCmd.getOptions();
  const subjectOpt = options.find((o) => o.name === "subject");
  assertEquals(subjectOpt !== undefined, true);
});

Deno.test("accessGrantCommand: create has --allow option", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const createCmd = commands.find((c) => c.getName() === "create")!;
  const options = createCmd.getOptions();
  const allowOpt = options.find((o) => o.name === "allow");
  assertEquals(allowOpt !== undefined, true);
});

Deno.test("accessGrantCommand: create has --deny option", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const createCmd = commands.find((c) => c.getName() === "create")!;
  const options = createCmd.getOptions();
  const denyOpt = options.find((o) => o.name === "deny");
  assertEquals(denyOpt !== undefined, true);
});

Deno.test("accessGrantCommand: create has --on option", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const createCmd = commands.find((c) => c.getName() === "create")!;
  const options = createCmd.getOptions();
  const onOpt = options.find((o) => o.name === "on");
  assertEquals(onOpt !== undefined, true);
});

Deno.test("accessGrantCommand: create has --when option", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const createCmd = commands.find((c) => c.getName() === "create")!;
  const options = createCmd.getOptions();
  const whenOpt = options.find((o) => o.name === "when");
  assertEquals(whenOpt !== undefined, true);
});

Deno.test("accessGrantCommand: create has --server option", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const createCmd = commands.find((c) => c.getName() === "create")!;
  const options = createCmd.getOptions();
  const serverOpt = options.find((o) => o.name === "server");
  assertEquals(serverOpt !== undefined, true);
});

Deno.test("accessGrantCommand: list has --server option", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const listCmd = commands.find((c) => c.getName() === "list")!;
  const options = listCmd.getOptions();
  const serverOpt = options.find((o) => o.name === "server");
  assertEquals(serverOpt !== undefined, true);
});

Deno.test("accessGrantCommand: revoke has --server option", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const revokeCmd = commands.find((c) => c.getName() === "revoke")!;
  const options = revokeCmd.getOptions();
  const serverOpt = options.find((o) => o.name === "server");
  assertEquals(serverOpt !== undefined, true);
});

Deno.test("accessGrantCommand: revoke accepts grant_id argument", async () => {
  const { accessGrantCommand } = await import("./access_grant.ts");
  const commands = accessGrantCommand.getCommands();
  const revokeCmd = commands.find((c) => c.getName() === "revoke")!;
  const args = revokeCmd.getArguments();
  assertEquals(args.length, 1);
});

Deno.test({
  name: "accessGrantCommand: create sets Deno.exitCode 1 when the run fails",
  sanitizeOps: false,
  sanitizeResources: false,
  fn: async () => {
    assertEquals(await runGrantCreateAgainst({ status: "failed" }), 1);
  },
});

Deno.test({
  name:
    "accessGrantCommand: create leaves Deno.exitCode 0 when the run succeeds",
  sanitizeOps: false,
  sanitizeResources: false,
  fn: async () => {
    assertEquals(await runGrantCreateAgainst({ status: "succeeded" }), 0);
  },
});
