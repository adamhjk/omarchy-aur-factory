// Swamp, an Automation Framework
// Copyright (C) 2026 Elder Swamp Club, Inc.
//
// This file is part of Swamp.
//
// Swamp is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License version 3
// as published by the Free Software Foundation, with the Swamp
// Extension and Definition Exception (found in the "COPYING-EXCEPTION"
// file).
//
// Swamp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with Swamp.  If not, see <https://www.gnu.org/licenses/>.

import { Command } from "@cliffy/command";
import { groupCommandAction } from "../group_action.ts";
import {
  createContext,
  type GlobalOptions,
  resolveRepoDir,
} from "../context.ts";
import {
  acquireModelLocks,
  requireInitializedRepoReadOnly,
  requireInitializedRepoUnlocked,
} from "../repo_context.ts";
import { UserError } from "../../domain/errors.ts";
import { findDefinitionByIdOrName } from "../../domain/models/model_lookup.ts";
import { modelRegistry } from "../../domain/models/model.ts";
import { vaultTypeRegistry } from "../../domain/vaults/vault_type_registry.ts";
import { reportRegistry } from "../../domain/reports/report_registry.ts";
import { GIT_SHA } from "./version.ts";
import type { RepositoryContext } from "../../infrastructure/persistence/repository_factory.ts";
import {
  consumeStream,
  createLibSwampContext,
  modelMethodRun,
} from "../../libswamp/mod.ts";
import { createModelMethodRunRenderer } from "../../presentation/renderers/model_method_run.ts";
import { isAuthenticated } from "../auth_context.ts";
import {
  type Group,
  GROUP_MODEL_TYPE,
  GroupSchema,
} from "../../domain/models/access/group_model.ts";
import type { DataRecord } from "../../domain/data/data_record.ts";
import {
  createAccessGroupIdpRenderer,
  createAccessGroupListRenderer,
} from "../../presentation/renderers/access_group.ts";
import {
  buildModelMethodRunDeps,
  LOCAL_PRINCIPAL,
  validateServerRepoExclusivity,
} from "./access_helpers.ts";
import type { ModelMethodRunEvent } from "../../libswamp/mod.ts";
import { isCustomDatastoreConfig } from "../../domain/datastore/datastore_config.ts";
import {
  requestServerResponse,
  resolveServerToken,
  resolveServeUrl,
  runModelMethodOverServer,
} from "../../cli/remote_run.ts";
import type {
  AccessGroupListIdpResponse,
  AccessGroupListResponse,
} from "../../serve/protocol.ts";

// deno-lint-ignore no-explicit-any
type AnyOptions = any;

async function queryGroups(
  repoContext: RepositoryContext,
): Promise<{ group: Group; instanceName: string }[]> {
  const records = await repoContext.dataQueryService.query(
    `modelType == "${GROUP_MODEL_TYPE.normalized}"`,
    { loadAttributes: true },
  );
  const orphanedRecords = await repoContext.dataQueryService.query(
    `modelType == "@${GROUP_MODEL_TYPE.normalized}"`,
    { loadAttributes: true },
  );

  const results: { group: Group; instanceName: string }[] = [];
  for (const record of [...records, ...orphanedRecords]) {
    const dataRecord = record as DataRecord;
    const parsed = GroupSchema.safeParse(dataRecord.attributes);
    if (parsed.success) {
      results.push({
        group: parsed.data,
        instanceName: dataRecord.modelName ?? "",
      });
    }
  }
  return results;
}

async function runGroupMethod(
  options: AnyOptions,
  instanceName: string,
  methodName: string,
  inputs: Record<string, unknown>,
  loggerCategory: string[],
  isDirectExecution: boolean,
): Promise<void> {
  const ctx = createContext(options as GlobalOptions, loggerCategory);
  const { repoDir, repoContext, datastoreConfig, syncService } =
    await requireInitializedRepoUnlocked({
      repoDir: resolveRepoDir(options.repoDir),
      outputMode: ctx.outputMode,
    });

  await Promise.all([
    modelRegistry.ensureLoaded(),
    vaultTypeRegistry.ensureLoaded(),
    reportRegistry.ensureLoaded(),
  ]);

  const deps = buildModelMethodRunDeps(repoDir, repoContext, isDirectExecution);

  const preResult = await findDefinitionByIdOrName(
    repoContext.definitionRepo,
    instanceName,
  );
  let flushModelLocks: (() => Promise<void>) | null = null;
  if (preResult) {
    const lockResult = await acquireModelLocks(
      datastoreConfig,
      [
        {
          modelType: preResult.type.normalized,
          modelId: preResult.definition.id,
        },
      ],
      repoDir,
      syncService,
      repoContext.catalogStore,
    );
    if (lockResult.synced) repoContext.catalogStore.invalidate();
    flushModelLocks = lockResult.flush;
  }

  try {
    const renderer = createModelMethodRunRenderer(ctx.outputMode, {
      modelName: instanceName,
      methodName,
      isAuthenticated: isAuthenticated(),
      quiet: ctx.verbosity === "quiet",
    });

    const typeArg = isDirectExecution
      ? `@${GROUP_MODEL_TYPE.normalized}`
      : undefined;
    const definitionName = isDirectExecution ? instanceName : undefined;

    await consumeStream(
      modelMethodRun(createLibSwampContext(), deps, {
        modelIdOrName: isDirectExecution
          ? `@${GROUP_MODEL_TYPE.normalized}`
          : instanceName,
        methodName,
        inputs,
        lastEvaluated: false,
        typeArg,
        definitionName,
        skipAllReports: true,
        swampSha: GIT_SHA || undefined,
      }),
      renderer.handlers(),
    );

    if (renderer.runFailed()) {
      Deno.exitCode = 1;
    }
  } catch (error) {
    if (error instanceof UserError) throw error;
    const message = error instanceof Error ? error.message : String(error);
    throw new UserError(`Group operation failed: ${message}`);
  } finally {
    if (flushModelLocks) {
      try {
        await flushModelLocks();
      } catch (releaseError) {
        ctx.logger.warn(
          "Failed to release locks during cleanup: {error}",
          {
            error: releaseError instanceof Error
              ? releaseError.message
              : String(releaseError),
          },
        );
      }
    } else if (syncService) {
      const namespace = isCustomDatastoreConfig(datastoreConfig)
        ? datastoreConfig.namespace
        : undefined;
      try {
        await syncService.markDirty();
        await syncService.pushChanged({ namespace });
      } catch (pushError) {
        ctx.logger.warn(
          "Failed to push changes to remote datastore: {error}",
          {
            error: pushError instanceof Error
              ? pushError.message
              : String(pushError),
          },
        );
      }
    }
  }
}

const accessGroupCreateCommand = new Command()
  .name("create")
  .description("Create a local group")
  .example("Create a group", "swamp access group create release-managers")
  .arguments("<name:string>")
  .option(
    "--repo-dir <dir:string>",
    "Repository directory (env: SWAMP_REPO_DIR)",
  )
  .option(
    "--server <url:string>",
    "Create a group on a 'swamp serve' server instead of locally (env: SWAMP_SERVE_URL)",
  )
  .option(
    "--token <token:string>",
    "Server token; only applies with --server (falls back to stored credential or SWAMP_SERVER_TOKEN)",
  )
  .action(async function (options: AnyOptions, name: string) {
    const server = resolveServeUrl(options.server as string | undefined);

    validateServerRepoExclusivity(
      server,
      options.repoDir as string | undefined,
    );

    if (server) {
      const ctx = createContext(options as GlobalOptions, [
        "access",
        "group",
        "create",
      ]);
      const token = await resolveServerToken(
        server,
        options.token as string | undefined,
      );
      const renderer = createModelMethodRunRenderer(ctx.outputMode, {
        modelName: name,
        methodName: "create",
        isAuthenticated: isAuthenticated(),
      });
      await consumeStream(
        runModelMethodOverServer({
          server,
          token,
          payload: {
            modelIdOrName: `@${GROUP_MODEL_TYPE.normalized}`,
            methodName: "create",
            inputs: { createdBy: LOCAL_PRINCIPAL },
            typeArg: `@${GROUP_MODEL_TYPE.normalized}`,
            definitionName: name,
          },
        }) as AsyncIterable<ModelMethodRunEvent>,
        renderer.handlers(),
      );
      if (renderer.runFailed()) {
        Deno.exitCode = 1;
      }
      return;
    }

    await runGroupMethod(
      options,
      name,
      "create",
      { createdBy: LOCAL_PRINCIPAL },
      ["access", "group", "create"],
      true,
    );
  });

const accessGroupAddMemberCommand = new Command()
  .name("add-member")
  .description("Add a principal to a group")
  .example(
    "Add a user",
    "swamp access group add-member release-managers user:adam",
  )
  .arguments("<group:string> <principal:string>")
  .option(
    "--repo-dir <dir:string>",
    "Repository directory (env: SWAMP_REPO_DIR)",
  )
  .option(
    "--server <url:string>",
    "Add a member on a 'swamp serve' server instead of locally (env: SWAMP_SERVE_URL)",
  )
  .option(
    "--token <token:string>",
    "Server token; only applies with --server (falls back to stored credential or SWAMP_SERVER_TOKEN)",
  )
  .action(async function (
    options: AnyOptions,
    group: string,
    principal: string,
  ) {
    const server = resolveServeUrl(options.server as string | undefined);

    validateServerRepoExclusivity(
      server,
      options.repoDir as string | undefined,
    );

    if (server) {
      const ctx = createContext(options as GlobalOptions, [
        "access",
        "group",
        "add-member",
      ]);
      const token = await resolveServerToken(
        server,
        options.token as string | undefined,
      );
      const renderer = createModelMethodRunRenderer(ctx.outputMode, {
        modelName: group,
        methodName: "add-member",
        isAuthenticated: isAuthenticated(),
      });
      await consumeStream(
        runModelMethodOverServer({
          server,
          token,
          payload: {
            modelIdOrName: group,
            methodName: "add-member",
            inputs: { principal },
          },
        }) as AsyncIterable<ModelMethodRunEvent>,
        renderer.handlers(),
      );
      if (renderer.runFailed()) {
        Deno.exitCode = 1;
      }
      return;
    }

    await runGroupMethod(
      options,
      group,
      "add-member",
      { principal },
      ["access", "group", "add-member"],
      false,
    );
  });

const accessGroupRemoveMemberCommand = new Command()
  .name("remove-member")
  .description("Remove a principal from a group")
  .example(
    "Remove a user",
    "swamp access group remove-member release-managers user:adam",
  )
  .arguments("<group:string> <principal:string>")
  .option(
    "--repo-dir <dir:string>",
    "Repository directory (env: SWAMP_REPO_DIR)",
  )
  .option(
    "--server <url:string>",
    "Remove a member on a 'swamp serve' server instead of locally (env: SWAMP_SERVE_URL)",
  )
  .option(
    "--token <token:string>",
    "Server token; only applies with --server (falls back to stored credential or SWAMP_SERVER_TOKEN)",
  )
  .action(async function (
    options: AnyOptions,
    group: string,
    principal: string,
  ) {
    const server = resolveServeUrl(options.server as string | undefined);

    validateServerRepoExclusivity(
      server,
      options.repoDir as string | undefined,
    );

    if (server) {
      const ctx = createContext(options as GlobalOptions, [
        "access",
        "group",
        "remove-member",
      ]);
      const token = await resolveServerToken(
        server,
        options.token as string | undefined,
      );
      const renderer = createModelMethodRunRenderer(ctx.outputMode, {
        modelName: group,
        methodName: "remove-member",
        isAuthenticated: isAuthenticated(),
      });
      await consumeStream(
        runModelMethodOverServer({
          server,
          token,
          payload: {
            modelIdOrName: group,
            methodName: "remove-member",
            inputs: { principal },
          },
        }) as AsyncIterable<ModelMethodRunEvent>,
        renderer.handlers(),
      );
      if (renderer.runFailed()) {
        Deno.exitCode = 1;
      }
      return;
    }

    await runGroupMethod(
      options,
      group,
      "remove-member",
      { principal },
      ["access", "group", "remove-member"],
      false,
    );
  });

const accessGroupListCommand = new Command()
  .name("list")
  .description("List all groups")
  .example("List groups", "swamp access group list")
  .option(
    "--repo-dir <dir:string>",
    "Repository directory (env: SWAMP_REPO_DIR)",
  )
  .option(
    "--server <url:string>",
    "List groups on a 'swamp serve' server instead of locally (env: SWAMP_SERVE_URL)",
  )
  .option(
    "--token <token:string>",
    "Server token; only applies with --server (falls back to stored credential or SWAMP_SERVER_TOKEN)",
  )
  .action(async function (options: AnyOptions) {
    const server = resolveServeUrl(options.server as string | undefined);

    validateServerRepoExclusivity(
      server,
      options.repoDir as string | undefined,
    );

    if (server) {
      const ctx = createContext(options as GlobalOptions, [
        "access",
        "group",
        "list",
      ]);
      const token = await resolveServerToken(
        server,
        options.token as string | undefined,
      );
      const response = await requestServerResponse<AccessGroupListResponse>(
        { server, ...(token ? { token } : {}) },
        { type: "access.group.list" },
      );
      const groups: Group[] = [];
      for (const raw of response.groups) {
        const parsed = GroupSchema.safeParse(raw);
        if (parsed.success) {
          groups.push(parsed.data);
        }
      }
      const renderer = createAccessGroupListRenderer(ctx.outputMode);
      renderer.renderList(groups);
      return;
    }

    const ctx = createContext(options as GlobalOptions, [
      "access",
      "group",
      "list",
    ]);
    const { repoContext } = await requireInitializedRepoReadOnly({
      repoDir: resolveRepoDir(options.repoDir),
      outputMode: ctx.outputMode,
    });

    await modelRegistry.ensureLoaded();

    const results = await queryGroups(repoContext);
    const groups = results.map((r) => r.group);
    const renderer = createAccessGroupListRenderer(ctx.outputMode);
    renderer.renderList(groups);
  });

const accessGroupMembersCommand = new Command()
  .name("members")
  .description("List members of a group")
  .example("Show members", "swamp access group members release-managers")
  .arguments("<name:string>")
  .option(
    "--repo-dir <dir:string>",
    "Repository directory (env: SWAMP_REPO_DIR)",
  )
  .option(
    "--server <url:string>",
    "List members on a 'swamp serve' server instead of locally (env: SWAMP_SERVE_URL)",
  )
  .option(
    "--token <token:string>",
    "Server token; only applies with --server (falls back to stored credential or SWAMP_SERVER_TOKEN)",
  )
  .action(async function (options: AnyOptions, name: string) {
    const server = resolveServeUrl(options.server as string | undefined);

    validateServerRepoExclusivity(
      server,
      options.repoDir as string | undefined,
    );

    if (server) {
      const ctx = createContext(options as GlobalOptions, [
        "access",
        "group",
        "members",
      ]);
      const token = await resolveServerToken(
        server,
        options.token as string | undefined,
      );
      const response = await requestServerResponse<AccessGroupListResponse>(
        { server, ...(token ? { token } : {}) },
        { type: "access.group.list", payload: { name } },
      );
      const groups: Group[] = [];
      for (const raw of response.groups) {
        const parsed = GroupSchema.safeParse(raw);
        if (parsed.success) {
          groups.push(parsed.data);
        }
      }
      const match = groups.find((g) => g.name === name);
      if (!match) {
        throw new UserError(`Group not found: ${name}`);
      }
      const renderer = createAccessGroupListRenderer(ctx.outputMode);
      renderer.renderMembers(match);
      return;
    }

    const ctx = createContext(options as GlobalOptions, [
      "access",
      "group",
      "members",
    ]);
    const { repoContext } = await requireInitializedRepoReadOnly({
      repoDir: resolveRepoDir(options.repoDir),
      outputMode: ctx.outputMode,
    });

    await modelRegistry.ensureLoaded();

    const results = await queryGroups(repoContext);
    const match = results.find((r) => r.group.name === name);
    if (!match) {
      throw new UserError(`Group not found: ${name}`);
    }

    const renderer = createAccessGroupListRenderer(ctx.outputMode);
    renderer.renderMembers(match.group);
  });

const accessGroupListIdpCommand = new Command()
  .name("list-idp")
  .description(
    "List IdP groups observed from authenticated users on a server",
  )
  .example(
    "List IdP groups",
    "swamp access group list-idp --server wss://swamp.example.com",
  )
  .option(
    "--server <url:string>",
    "Server to query (required; env: SWAMP_SERVE_URL)",
  )
  .option(
    "--token <token:string>",
    "Server token (falls back to stored credential or SWAMP_SERVER_TOKEN)",
  )
  .action(async function (options: AnyOptions) {
    const server = resolveServeUrl(options.server as string | undefined);
    if (!server) {
      throw new UserError(
        "--server is required: IdP groups only exist on a swamp serve instance",
      );
    }

    const ctx = createContext(options as GlobalOptions, [
      "access",
      "group",
      "list-idp",
    ]);
    const token = await resolveServerToken(
      server,
      options.token as string | undefined,
    );
    const response = await requestServerResponse<AccessGroupListIdpResponse>(
      { server, ...(token ? { token } : {}) },
      { type: "access.group.list-idp" },
    );
    const renderer = createAccessGroupIdpRenderer(ctx.outputMode);
    renderer.renderList(response.groups);
  });

export const accessGroupCommand = new Command()
  .name("group")
  .description("Manage local groups")
  .action(groupCommandAction)
  .command("create", accessGroupCreateCommand)
  .command("add-member", accessGroupAddMemberCommand)
  .command("remove-member", accessGroupRemoveMemberCommand)
  .command("list", accessGroupListCommand)
  .command("list-idp", accessGroupListIdpCommand)
  .command("members", accessGroupMembersCommand);
