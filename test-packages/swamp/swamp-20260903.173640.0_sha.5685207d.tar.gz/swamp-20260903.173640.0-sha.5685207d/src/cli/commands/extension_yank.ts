// Swamp, an Automation Framework
// Copyright (C) 2026 Elder Swamp Club, Inc.
//
// This file is part of Swamp.
//
// Swamp is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License version 3
// as published by the Free Software Foundation, with the Swamp
// Extension and Definition Exception (found in the "COPYING-EXCEPTION"
// file).
//
// Swamp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with Swamp.  If not, see <https://www.gnu.org/licenses/>.

import { Command } from "@cliffy/command";
import {
  consumeStream,
  createExtensionYankDeps,
  createLibSwampContext,
  extensionYank,
  extensionYankPreview,
} from "../../libswamp/mod.ts";
import {
  createExtensionYankRenderer,
  renderExtensionYankCancelled,
} from "../../presentation/renderers/extension_yank.ts";
import { createContext, type GlobalOptions } from "../context.ts";
import { UserError } from "../../domain/errors.ts";
import { parseExtensionRef } from "./extension_pull.ts";
import { loadIdentity } from "../load_identity.ts";
import { ReleaseChannel } from "../../domain/extensions/release_channel.ts";
import { promptConfirmation } from "../prompt_helpers.ts";

// deno-lint-ignore no-explicit-any
type AnyOptions = any;

export const extensionYankCommand = new Command()
  .name("yank")
  .description(
    "Yank an extension or specific version from the registry. Use `swamp extension unyank` to reverse.",
  )
  .example(
    "Yank every version (blocks all future pushes until unyanked)",
    `swamp extension yank @stack72/aws-ec2 --reason "security issue"`,
  )
  .example(
    "Yank one version (future versions can still be pushed)",
    `swamp extension yank @stack72/aws-ec2 2026.3.1 --reason "broken release"`,
  )
  .example(
    "Yank only the stable channel (beta/rc remain available)",
    `swamp extension yank @stack72/aws-ec2 --channel stable --reason "withdrawing from stable"`,
  )
  .arguments("<extension:string> [version:string]")
  .option("--reason <reason:string>", "Reason for yanking", { required: true })
  .option(
    "--channel <channel:string>",
    "Release channel to yank: 'stable', 'beta', or 'rc' (default: all channels)",
  )
  .option("-y, --yes", "Skip confirmation prompt")
  .option("-f, --force", "Skip confirmation prompt (alias for --yes)")
  .action(async function (
    options: AnyOptions,
    extension: string,
    version?: string,
  ) {
    const cliCtx = createContext(options as GlobalOptions, [
      "extension",
      "yank",
    ]);
    cliCtx.logger.debug`Starting extension yank`;

    // Parse extension reference
    const ref = parseExtensionRef(extension);
    const resolvedVersion = version ?? ref.version ?? null;

    // Validate --channel if provided
    const channel = (options.channel as string | undefined) ?? null;
    if (
      channel !== null &&
      !ReleaseChannel.isValid(channel)
    ) {
      throw new UserError(
        `Invalid channel: "${channel}". Must be one of: stable, beta, rc.`,
      );
    }

    const ctx = createLibSwampContext({ logger: cliCtx.logger });
    const identity = await loadIdentity();
    const deps = createExtensionYankDeps(identity);
    const input = {
      extensionName: ref.name,
      version: resolvedVersion,
      channel,
      reason: options.reason as string,
    };

    // Phase 1: Preview — validate credentials and extension name
    let preview;
    try {
      preview = await extensionYankPreview(ctx, deps, input);
    } catch (error) {
      if ("code" in (error as Record<string, unknown>)) {
        throw new UserError((error as { message: string }).message);
      }
      throw error;
    }

    // Phase 2: Confirmation prompt (log mode only, unless --yes)
    if (cliCtx.outputMode === "log" && !options.yes && !options.force) {
      const prompt = preview.version
        ? `Yank ${preview.extensionName}@${preview.version}? This will mark it yanked.`
        : preview.channel
        ? `Yank all ${preview.channel} versions of ${preview.extensionName}?`
        : `Yank ALL versions of ${preview.extensionName}? Future pushes will be blocked until you run \`swamp extension unyank\`.`;
      const confirmed = await promptConfirmation(prompt);
      if (!confirmed) {
        renderExtensionYankCancelled(cliCtx.outputMode);
        return;
      }
    }

    // Phase 3: Execute mutation
    const renderer = createExtensionYankRenderer(cliCtx.outputMode);
    await consumeStream(
      extensionYank(ctx, deps, input),
      renderer.handlers(),
    );

    cliCtx.logger.debug("Extension yank command completed");
  });
