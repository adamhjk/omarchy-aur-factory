// Swamp, an Automation Framework
// Copyright (C) 2026 Elder Swamp Club, Inc.
//
// This file is part of Swamp.
//
// Swamp is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License version 3
// as published by the Free Software Foundation, with the Swamp
// Extension and Definition Exception (found in the "COPYING-EXCEPTION"
// file).
//
// Swamp is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with Swamp.  If not, see <https://www.gnu.org/licenses/>.

import { assertEquals } from "@std/assert";
import { Command } from "@cliffy/command";
import { initializeLogging } from "../../infrastructure/logging/logger.ts";

// Import models barrel to trigger self-registration
import "../../domain/models/models.ts";

// Initialize logging for tests
await initializeLogging({});

/**
 * In-process serve endpoint streaming the given run events followed by a
 * `done` frame — enough to drive the command's streaming --server path
 * without a subprocess.
 */
function runEventServer(
  events: Record<string, unknown>[],
): { url: string; shutdown: () => Promise<void> } {
  const server = Deno.serve(
    { port: 0, hostname: "127.0.0.1", onListen: () => {} },
    (req) => {
      const { socket, response } = Deno.upgradeWebSocket(req);
      socket.onmessage = (message) => {
        const request = JSON.parse(message.data as string) as { id: string };
        for (const event of events) {
          socket.send(
            JSON.stringify({ type: "event", id: request.id, event }),
          );
        }
        socket.send(JSON.stringify({ type: "done", id: request.id }));
      };
      return response;
    },
  );
  return {
    url: `ws://127.0.0.1:${server.addr.port}`,
    shutdown: () => server.shutdown(),
  };
}

/** Runs `access group create` against a scripted run result; returns Deno.exitCode. */
async function runGroupCreateAgainst(
  run: Record<string, unknown>,
): Promise<number> {
  const server = runEventServer([{ kind: "completed", run }]);
  const previousExitCode = Deno.exitCode;
  Deno.exitCode = 0;
  try {
    const { accessGroupCommand } = await import("./access_group.ts");
    const root = new Command()
      .globalOption("--json", "JSON output")
      .command("group", accessGroupCommand);
    await root.parse([
      "group",
      "create",
      "release-managers",
      "--json",
      "--server",
      server.url,
      "--token",
      "test.token",
    ]);
    return Deno.exitCode;
  } finally {
    Deno.exitCode = previousExitCode;
    await server.shutdown();
  }
}

Deno.test("accessGroupCommand: module loads", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  assertEquals(accessGroupCommand.getName(), "group");
});

Deno.test("accessGroupCommand: has correct description", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  assertEquals(
    accessGroupCommand.getDescription(),
    "Manage local groups",
  );
});

Deno.test("accessGroupCommand: has create subcommand", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const cmd = commands.find((c) => c.getName() === "create");
  assertEquals(cmd !== undefined, true);
});

Deno.test("accessGroupCommand: has add-member subcommand", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const cmd = commands.find((c) => c.getName() === "add-member");
  assertEquals(cmd !== undefined, true);
});

Deno.test("accessGroupCommand: has remove-member subcommand", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const cmd = commands.find((c) => c.getName() === "remove-member");
  assertEquals(cmd !== undefined, true);
});

Deno.test("accessGroupCommand: has list subcommand", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const cmd = commands.find((c) => c.getName() === "list");
  assertEquals(cmd !== undefined, true);
});

Deno.test("accessGroupCommand: has members subcommand", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const cmd = commands.find((c) => c.getName() === "members");
  assertEquals(cmd !== undefined, true);
});

Deno.test("accessGroupCommand: create accepts name argument", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const createCmd = commands.find((c) => c.getName() === "create")!;
  const args = createCmd.getArguments();
  assertEquals(args.length, 1);
});

Deno.test("accessGroupCommand: add-member accepts group and principal arguments", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const addCmd = commands.find((c) => c.getName() === "add-member")!;
  const args = addCmd.getArguments();
  assertEquals(args.length, 2);
});

Deno.test("accessGroupCommand: members accepts name argument", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const membersCmd = commands.find((c) => c.getName() === "members")!;
  const args = membersCmd.getArguments();
  assertEquals(args.length, 1);
});

Deno.test("accessGroupCommand: create has --server option", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const createCmd = commands.find((c) => c.getName() === "create")!;
  const options = createCmd.getOptions();
  const serverOpt = options.find((o) => o.name === "server");
  assertEquals(serverOpt !== undefined, true);
});

Deno.test("accessGroupCommand: add-member has --server option", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const addCmd = commands.find((c) => c.getName() === "add-member")!;
  const options = addCmd.getOptions();
  const serverOpt = options.find((o) => o.name === "server");
  assertEquals(serverOpt !== undefined, true);
});

Deno.test("accessGroupCommand: remove-member has --server option", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const removeCmd = commands.find((c) => c.getName() === "remove-member")!;
  const options = removeCmd.getOptions();
  const serverOpt = options.find((o) => o.name === "server");
  assertEquals(serverOpt !== undefined, true);
});

Deno.test("accessGroupCommand: list has --server option", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const listCmd = commands.find((c) => c.getName() === "list")!;
  const options = listCmd.getOptions();
  const serverOpt = options.find((o) => o.name === "server");
  assertEquals(serverOpt !== undefined, true);
});

Deno.test("accessGroupCommand: members has --server option", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const membersCmd = commands.find((c) => c.getName() === "members")!;
  const options = membersCmd.getOptions();
  const serverOpt = options.find((o) => o.name === "server");
  assertEquals(serverOpt !== undefined, true);
});

Deno.test("accessGroupCommand: has list-idp subcommand", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const cmd = commands.find((c) => c.getName() === "list-idp");
  assertEquals(cmd !== undefined, true);
});

Deno.test("accessGroupCommand: list-idp has --server option", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const listIdpCmd = commands.find((c) => c.getName() === "list-idp")!;
  const options = listIdpCmd.getOptions();
  const serverOpt = options.find((o) => o.name === "server");
  assertEquals(serverOpt !== undefined, true);
});

Deno.test("accessGroupCommand: list-idp has --token option", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const listIdpCmd = commands.find((c) => c.getName() === "list-idp")!;
  const options = listIdpCmd.getOptions();
  const tokenOpt = options.find((o) => o.name === "token");
  assertEquals(tokenOpt !== undefined, true);
});

Deno.test("accessGroupCommand: list-idp has no --repo-dir option", async () => {
  const { accessGroupCommand } = await import("./access_group.ts");
  const commands = accessGroupCommand.getCommands();
  const listIdpCmd = commands.find((c) => c.getName() === "list-idp")!;
  const options = listIdpCmd.getOptions();
  const repoDirOpt = options.find((o) => o.name === "repo-dir");
  assertEquals(repoDirOpt, undefined);
});

Deno.test({
  name: "accessGroupCommand: create sets Deno.exitCode 1 when the run fails",
  sanitizeOps: false,
  sanitizeResources: false,
  fn: async () => {
    assertEquals(await runGroupCreateAgainst({ status: "failed" }), 1);
  },
});

Deno.test({
  name:
    "accessGroupCommand: create leaves Deno.exitCode 0 when the run succeeds",
  sanitizeOps: false,
  sanitizeResources: false,
  fn: async () => {
    assertEquals(await runGroupCreateAgainst({ status: "succeeded" }), 0);
  },
});
