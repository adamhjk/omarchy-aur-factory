package hosting_service

import "regexp"

// if you want to make a custom regex for a given service feel free to test it out
// at https://regex101.com using the flavor Golang
var defaultUrlRegexps = []*regexp.Regexp{
	regexp.MustCompile(`^(?:https?|ssh)://[^/]+/(?P<owner>.*)/(?P<repo>.*?)(?:\.git)?$`),
	regexp.MustCompile(`^(.*?@)?.*:/*(?P<owner>.*)/(?P<repo>.*?)(?:\.git)?$`),
}

var (
	defaultRepoURLTemplate  = "https://{{.webDomain}}/{{.owner}}/{{.repo}}"
	defaultRepoNameTemplate = "{{.owner}}/{{.repo}}"
)

// we've got less type safety using go templates but this lends itself better to
// users adding custom service definitions in their config
var githubServiceDef = ServiceDefinition{
	provider:                        "github",
	pullRequestURLIntoDefaultBranch: "/compare/{{.From}}?expand=1",
	pullRequestURLIntoTargetBranch:  "/compare/{{.To}}...{{.From}}?expand=1",
	commitURL:                       "/commit/{{.CommitHash}}",
	urlRegexps:                      defaultUrlRegexps,
	repoURLTemplate:                 defaultRepoURLTemplate,
	repoNameTemplate:                defaultRepoNameTemplate,
}

var bitbucketServiceDef = ServiceDefinition{
	provider:                        "bitbucket",
	pullRequestURLIntoDefaultBranch: "/pull-requests/new?source={{.From}}&t=1",
	pullRequestURLIntoTargetBranch:  "/pull-requests/new?source={{.From}}&dest={{.To}}&t=1",
	commitURL:                       "/commits/{{.CommitHash}}",
	urlRegexps: []*regexp.Regexp{
		regexp.MustCompile(`^(?:https?|ssh)://.*/(?P<owner>.*)/(?P<repo>.*?)(?:\.git)?$`),
		regexp.MustCompile(`^.*@.*:/*(?P<owner>.*)/(?P<repo>.*?)(?:\.git)?$`),
	},
	repoURLTemplate:  defaultRepoURLTemplate,
	repoNameTemplate: defaultRepoNameTemplate,
}

var gitLabServiceDef = ServiceDefinition{
	provider:                        "gitlab",
	pullRequestURLIntoDefaultBranch: "/-/merge_requests/new?merge_request%5Bsource_branch%5D={{.From}}",
	pullRequestURLIntoTargetBranch:  "/-/merge_requests/new?merge_request%5Bsource_branch%5D={{.From}}&merge_request%5Btarget_branch%5D={{.To}}",
	commitURL:                       "/-/commit/{{.CommitHash}}",
	urlRegexps:                      defaultUrlRegexps,
	repoURLTemplate:                 defaultRepoURLTemplate,
	repoNameTemplate:                defaultRepoNameTemplate,
}

var azdoServiceDef = ServiceDefinition{
	provider:                        "azuredevops",
	pullRequestURLIntoDefaultBranch: "/pullrequestcreate?sourceRef={{.From}}",
	pullRequestURLIntoTargetBranch:  "/pullrequestcreate?sourceRef={{.From}}&targetRef={{.To}}",
	commitURL:                       "/commit/{{.CommitHash}}",
	urlRegexps: []*regexp.Regexp{
		regexp.MustCompile(`^.+@vs-ssh\.visualstudio\.com[:/](?:v3/)?(?P<org>[^/]+)/(?P<project>[^/]+)/(?P<repo>[^/]+?)(?:\.git)?$`),
		regexp.MustCompile(`^git@ssh.dev.azure.com.*/(?P<org>.*)/(?P<project>.*)/(?P<repo>.*?)(?:\.git)?$`),
		regexp.MustCompile(`^https://.*@dev.azure.com/(?P<org>.*?)/(?P<project>.*?)/_git/(?P<repo>.*?)(?:\.git)?$`),
		regexp.MustCompile(`^https://.*/(?P<org>.*?)/(?P<project>.*?)/_git/(?P<repo>.*?)(?:\.git)?$`),
	},
	repoURLTemplate:  "https://{{.webDomain}}/{{.org}}/{{.project}}/_git/{{.repo}}",
	repoNameTemplate: "{{.org}}/{{.project}}/{{.repo}}",
}

var bitbucketServerServiceDef = ServiceDefinition{
	provider:                        "bitbucketServer",
	pullRequestURLIntoDefaultBranch: "/pull-requests?create&sourceBranch={{.From}}",
	pullRequestURLIntoTargetBranch:  "/pull-requests?create&targetBranch={{.To}}&sourceBranch={{.From}}",
	commitURL:                       "/commits/{{.CommitHash}}",
	urlRegexps: []*regexp.Regexp{
		regexp.MustCompile(`^ssh://git@.*/(?P<project>.*)/(?P<repo>.*?)(?:\.git)?$`),
		regexp.MustCompile(`^https://.*/scm/(?P<project>.*)/(?P<repo>.*?)(?:\.git)?$`),
	},
	repoURLTemplate:  "https://{{.webDomain}}/projects/{{.project}}/repos/{{.repo}}",
	repoNameTemplate: "{{.project}}/{{.repo}}",
}

var giteaServiceDef = ServiceDefinition{
	provider:                        "gitea",
	pullRequestURLIntoDefaultBranch: "/compare/{{.From}}",
	pullRequestURLIntoTargetBranch:  "/compare/{{.To}}...{{.From}}",
	commitURL:                       "/commit/{{.CommitHash}}",
	urlRegexps:                      defaultUrlRegexps,
	repoURLTemplate:                 defaultRepoURLTemplate,
}

var codebergServiceDef = ServiceDefinition{
	provider:                        "codeberg",
	pullRequestURLIntoDefaultBranch: "/compare/{{.From}}",
	pullRequestURLIntoTargetBranch:  "/compare/{{.To}}...{{.From}}",
	commitURL:                       "/commit/{{.CommitHash}}",
	urlRegexps:                      defaultUrlRegexps,
	repoURLTemplate:                 defaultRepoURLTemplate,
}

var serviceDefinitions = []ServiceDefinition{
	githubServiceDef,
	bitbucketServiceDef,
	gitLabServiceDef,
	azdoServiceDef,
	bitbucketServerServiceDef,
	giteaServiceDef,
	codebergServiceDef,
}

var defaultServiceDomains = []ServiceDomain{
	{
		serviceDefinition: githubServiceDef,
		gitDomain:         "github.com",
		webDomain:         "github.com",
	},
	{
		serviceDefinition: bitbucketServiceDef,
		gitDomain:         "bitbucket.org",
		webDomain:         "bitbucket.org",
	},
	{
		serviceDefinition: gitLabServiceDef,
		gitDomain:         "gitlab.com",
		webDomain:         "gitlab.com",
	},
	{
		serviceDefinition: azdoServiceDef,
		gitDomain:         "dev.azure.com",
		webDomain:         "dev.azure.com",
	},
	{
		serviceDefinition: giteaServiceDef,
		gitDomain:         "try.gitea.io",
		webDomain:         "try.gitea.io",
	},
	{
		serviceDefinition: codebergServiceDef,
		gitDomain:         "codeberg.org",
		webDomain:         "codeberg.org",
	},
}
