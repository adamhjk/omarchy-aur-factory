package controllers

import (
	"github.com/jesseduffield/lazygit/pkg/gui/context"
	"github.com/jesseduffield/lazygit/pkg/gui/types"
)

type MenuController struct {
	baseController
	*ListControllerTrait[*types.MenuItem]
	c *ControllerCommon
}

var _ types.IController = &MenuController{}

func NewMenuController(
	c *ControllerCommon,
) *MenuController {
	return &MenuController{
		baseController: baseController{},
		ListControllerTrait: NewListControllerTrait(
			c,
			c.Contexts().Menu,
			c.Contexts().Menu.GetSelected,
			c.Contexts().Menu.GetSelectedItems,
		),
		c: c,
	}
}

// NOTE: if you add a new keybinding here, you'll also need to add it to
// `reservedKeys` in `pkg/gui/context/menu_context.go`
func (self *MenuController) GetKeybindings(opts types.KeybindingsOpts) []*types.Binding {
	bindings := []*types.Binding{
		{
			Keys:              opts.GetKeys(opts.Config.Universal.Select),
			Handler:           self.withItem(self.press),
			GetDisabledReason: self.require(self.singleItemSelected()),
		},
		{
			Keys:              opts.GetKeys(opts.Config.Universal.ConfirmMenu),
			Handler:           self.withItem(self.press),
			GetDisabledReason: self.require(self.singleItemSelected()),
			Description:       self.c.Tr.Execute,
			DisplayOnScreen:   true,
		},
		{
			Keys:            opts.GetKeys(opts.Config.Universal.Return),
			Handler:         self.close,
			Description:     self.c.Tr.CloseCancel,
			DisplayOnScreen: true,
		},
	}

	return bindings
}

func (self *MenuController) GetOnDoubleClick() func() error {
	return self.withItemGraceful(self.press)
}

func (self *MenuController) GetOnFocus() func(types.OnFocusOpts) {
	return func(types.OnFocusOpts) {
		selectedMenuItem := self.context().GetSelected()
		if selectedMenuItem != nil {
			self.c.Views().Tooltip.SetContent(self.c.Helpers().Confirmation.TooltipForMenuItem(selectedMenuItem))
		}
	}
}

func (self *MenuController) press(selectedItem *types.MenuItem) error {
	return self.context().OnMenuPress(selectedItem)
}

func (self *MenuController) close() error {
	if self.context().IsFiltering() {
		self.c.Helpers().Search.Cancel()
		return nil
	}

	return self.context().OnMenuPress(nil)
}

func (self *MenuController) context() *context.MenuContext {
	return self.c.Contexts().Menu
}
